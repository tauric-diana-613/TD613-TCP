#!/usr/bin/env node
/**
 * TD613 Experiment A · Flight-R1 Native Dollhouse Execution Script
 *
 * Runs native /dollhouse-design and /dollhouse-audit (--strict-provenance) from
 * repoRoot using validated stdout streaming, preserving separate machine-parseable
 * JSON (.json) and human-readable (.md) receipts.
 */

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = 'C:\\Users\\timst\\OneDrive\\Desktop\\tcp-repository';

console.log('[Flight-R1 Dollhouses] Running Flight-R1 Native Dollhouses...');

// 1. Run /dollhouse-design
const designCommPath = path.join(__dirname, 'FLIGHT_R1_DESIGN_COMMISSION.json');
const designRun = spawnSync(
  process.execPath,
  ['scripts/run-dollhouse-design.mjs', '--input', designCommPath, '--format', 'both'],
  { cwd: repoRoot, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
);
if (designRun.error) throw designRun.error;
const designSplit = '\n\n======================================================';
const dSplitIdx = designRun.stdout.indexOf(designSplit);
if (dSplitIdx < 0) throw new Error('Expected delimiter in run-dollhouse-design stdout.');
const parsedDesignJson = JSON.parse(designRun.stdout.slice(0, dSplitIdx).trim());
fs.writeFileSync(path.join(__dirname, 'FLIGHT_R1_DESIGN_MACHINE_RECEIPT.json'), JSON.stringify(parsedDesignJson, null, 2) + '\n', 'utf8');
fs.writeFileSync(path.join(__dirname, 'FLIGHT_R1_DESIGN_HUMAN_RECEIPT.md'), designRun.stdout.slice(dSplitIdx + 2), 'utf8');
console.log('[Flight-R1 Dollhouses] Flight-R1 Design completed successfully.');

// 2. Run /dollhouse-audit (--strict-provenance)
const auditInputPath = path.join(__dirname, 'FLIGHT_R1_AUDIT_INPUT.json');
const auditInputRaw = fs.readFileSync(auditInputPath, 'utf8');
const auditRun = spawnSync(
  process.execPath,
  ['scripts/run-dollhouse-skill-audit.mjs', '--strict-provenance', '--format', 'both'],
  { cwd: repoRoot, input: auditInputRaw, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
);
if (auditRun.error) throw auditRun.error;
const splitMarker = '\n--- MACHINE RECEIPT JSON ---\n';
const markerIdx = auditRun.stdout.indexOf(splitMarker);
if (markerIdx < 0) throw new Error('Expected delimiter in run-dollhouse-skill-audit stdout.');
const humanMd = auditRun.stdout.slice(0, markerIdx).trimEnd() + '\n';
const machineJson = JSON.parse(auditRun.stdout.slice(markerIdx + splitMarker.length).trim());
fs.writeFileSync(path.join(__dirname, 'FLIGHT_R1_AUDIT_HUMAN_RECEIPT.md'), humanMd, 'utf8');
fs.writeFileSync(path.join(__dirname, 'FLIGHT_R1_AUDIT_MACHINE_RECEIPT.json'), JSON.stringify(machineJson, null, 2) + '\n', 'utf8');
console.log(`[Flight-R1 Dollhouses] Flight-R1 Audit completed: status=${machineJson.status || machineJson.overall_status}`);
