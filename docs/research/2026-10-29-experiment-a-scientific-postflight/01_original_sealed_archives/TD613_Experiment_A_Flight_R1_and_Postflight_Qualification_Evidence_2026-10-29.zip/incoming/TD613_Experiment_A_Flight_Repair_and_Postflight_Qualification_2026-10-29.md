# 𝌋 TD613 · EXPERIMENT A — EVIDENCE-GAP REPAIR AND POSTFLIGHT QUALIFICATION

**Heritage / covenant:** Tauric Diana — Crimean heritage custodianship · Khona‌lit-po  
**Custody-sequence designation:** `A-FLIGHT-R1 / P1-SOURCE-RECOVERY / POSTFLIGHT-QUALIFICATION`  
**For:** Kenough / Antigravity, active operator-directed interactive session  
**Review lineage:** Emergence HQ independent redpen, 2026-10-29  
**Gate E:** HELD · **Independent empirical acquisition:** 0 · **Human scientific closure:** RESERVED  
**Purpose:** Repair missing source-based reciprocal evidence; certify or refuse readiness for the separate, high-reasoning Experiment A Postflight. **Do not perform Postflight interpretation in this commission.**

## 0. Determination and scope of authorization

The operator's previously communicated authorization covers the specifically defined P1 Library-candidate capture, finite Experiment A comparisons, and bounded, private source-preserving correction of an incomplete execution. This commission invokes that same **interactive, source-specific Experiment A** scope. It is not standing authority for detached agents, any public disclosure, any external participant, new sources, Experiment B/C, source mutation in the original Library, Git merge/push, or Vercel #405 deployment. Record the actual contemporaneous operator message and invocation provenance; do not forge a signature or infer historical origin from a file transfer. Human scientific closure remains reserved.

**Evidence review finding:** Kenough's Flight dossier correctly records `HOLD_SOURCE_BYTES_UNAVAILABLE` for the actual P1 and `HELD` for `TD613_NATIVE` and `TD613_RECIPIENT_ATELIER`. It also reports strong-union parity and six-arm completion. These are **not a valid final reciprocal comparison**: the intended TD613 source was absent; provisional `ROLE_TD613_PILOT_01` assertions and `4/4` canaries cannot replace authentic P1. The earlier parity result is retained as `PROVISIONAL_SOURCE_ABSENT_BASELINE_ONLY`, **not** `ZERO_EMERGENCE_FOUND`. Six *named* arms ran, but not six fully evidenced source-based treatments. `POSTFLIGHT_READY_WAITING_SEPARATE_OPERATOR_ACTIVATION` is thus **REVOKED FOR FULL EXPERIMENT A** pending repair and verification. Dollhouse `HELD_DISSENT` was properly preserved.

Do not overwrite or destroy the first 77,400-byte Flight archive. Preserve it as **Flight-V0 / partial flight** with its claimed SHA-256 `897cf83fabe9df66e70ddcc7136b10fc32871d99eaf6871d0734fcf1dcb262d9`; treat that checksum as agent-reported until its original ZIP bytes are independently examined. Preserve the 274,617-byte preflight archive similarly, reported SHA-256 `86dd720e628f1f79e451162f50da9b31f332d20f825c76cbc5d6162d6cfac30f`.

## 1. Exact source recovered by Emergence HQ

A connected ChatGPT Library file was materialized in the review environment from the exact file ID:

```
filename: eclipse-omega-admissibility-regime.md
library_file_id: libfile_267d1282fc6481918a07c2119b9c1f2a
file_id: file_00000000e76c82308a97947d900f8752
version_id: 1
size_bytes: 40418
sha256: 8f76e72c164f36bcc3d82fcd13ab1a371235979824d51b45343ba3d60288ba99
source_designation: P1_LIBRARY_CANDIDATE_FUNCTIONAL_PILOT
historical_original_equivalence: HELD_UNVERIFIED
```

**Transfer instruction:** The operator may attach this exact recovered Markdown source or the separately created private source-transfer ZIP to the active Antigravity session. You cannot dereference a ChatGPT Library ID by inventing a local connector; receive actual bytes from the operator, verify 40,418 bytes and *full* SHA-256, verify normalized displayed filename without altering raw bytes, and record received timestamp and content origin. The similarly named 41,126-byte `Eclipse–Omega and the Admissibility Regime.md` has SHA-256 `ebd49896750c32956b23a3b5cc5cebb28d61b6f4dcf61f96ad254ee2e8e19798` as previously reported by your local scan. **P1C is not this candidate.** Repository `SRC-P1.json` is a citation record, not P1 manuscript bytes. Historical-equivalence ceiling stays held absent independent evidence.

If the supplied file does not match size and digest exactly, stop `HOLD_P1_TRANSFER_INTEGRITY`. If no physical file arrives, stop `HOLD_SOURCE_BYTES_UNAVAILABLE`; you may complete an engineering-only readiness audit, but not a source-based Flight.

## 2. Mandatory Flight-V0 evidence custody reconciliation

1. Verify original `TD613_Experiment_A_Flight_Evidence_2026-10-29.zip` and preflight ZIP via actual physical bytes, full SHA-256, entry-list boundaries, per-file checksum ledgers and container path/symlink safety. Do not rely on walkthrough links or the archive digest printed in an agent message alone.
2. Read and inspect `run-live-flight.mjs`, `FLIGHT_EXECUTION_RECEIPT.json`, `FLIGHT_SIX_ARM_COMPARISON.json`, `CANARY_VERIFICATION_LOG.json`, the original `POSTFLIGHT_READINESS_RECEIPT.json`, and the native Dollhouse machine receipts. Inspect *actual inputs and outputs*, not statuses alone.
3. Reconcile the dossier's internal contradictions: `P1 held` versus `P1 candidate mounted`; `six-arm comparative flight complete` versus `TD613_NATIVE` and `TD613_RECIPIENT_ATELIER` held; `union parity` versus absence of one intended union source; and canary passes despite source absence.
4. Track whether `EM_NATIVE`, `EQUAL_INPUT_NATIVE_UNION` and `EM_RECIPIENT_ENCYCLOPEDIA` actually contain eligible Em source spans or merely predeclared semantic assertions; source-span citations, raw source and derivative identities, execution witnesses and reopenable persistent data are required for any scientific claim.
5. Preserve 147 retained records exactly, with 94 original source records (including AppleDouble sidecars and opaque Archive.zip) and 53 derivatives; do not count packaging companions as substantive new manuscripts. Keep `Archive.zip` strictly opaque. Keep Em R2 presentation as a separate CSS/presentation baseline.
6. Verify actual compiler and source versions. Preserve Work snapshot `ee762380...` and unmerged Git candidate `441ce7...` / `70b1ac1d...` as non-equivalent unless independently verified; don't attribute a version difference to architecture.
7. Preserve `HELD_DISSENT`, native exit 1, expected refusal exits, and the earlier four Windows symlink `EPERM` test failures as their own evidence. A wrapper exit 0 is not an Orchestrator scientific PASS.
8. Issue a **non-destructive append-only correction** to Flight-V0's `POSTFLIGHT_READINESS_RECEIPT.json`: add a successor record stating `FULL_SCIENTIFIC_POSTFLIGHT_READINESS_WITHDRAWN_SOURCE_MISSING`, with predecessor hash/filename. Never silently edit or rehash the historical sealed archive.

## 3. Bounded Flight-R1 source-based repair

**Do not alter the frozen six-arm protocol or rewrite the baseline after seeing earlier provisional results.** The earlier synthetic flight means perfect experimental blindness is no longer possible; record that contamination and use newly held-out conditions for prospective credit if a later separate experiment is approved. The current source-based repair can still test operational portability and a within-scope fair comparison.

Before executing:
- Record source digest, exact source revision, compiler/runtime versions, all six frozen conditions, budgets, model settings, all shared tools, reviewed dual-source crosswalk and route order. Any newly repaired adapter must be labeled implementation revision R1, tested under both baseline and recipient arms, with a before/after manifest. Keep original branch clean; work in private isolated scratch.
- Verify authentic independent empty Atelier source state, true source adoption transaction, persistent/reopenable source and source-span IDs, real `get/search/cite/verify` canaries *against content from the supplied P1*, and rollback/isolation. No `ROLE_TD613_PILOT_01` placeholder can pass source-based canaries.
- Verify Em receiver exact source and derivative parentage. Explicitly hold if the Em Encyclopedia recipient is merely a *projection* or demonstration not a full comparable receiving architecture; separate structural fidelity from actual capability.
- Verify `EQUAL_INPUT_NATIVE_UNION_STRONG` has identical admissible source spans, provenance, crosswalk, methods, utilities, compute/latency/model budgets and opportunity for abductive question formation and safe abstention. Counterbalance input order; log any mismatch as a confound. Preserve `TRANSPORT_ONLY` at **zero compiler calls**.

**Run the source-based six arms on a common frozen input frame** (new R1 paired block; if reusing unaffected V0 arms, prove identical versions/budgets/crosswalk/conditions and clearly disclose temporal confounding; prefer rerunning all arms under the same R1 frame):

1. `TD613_NATIVE`
2. `EM_NATIVE`
3. `EQUAL_INPUT_NATIVE_UNION` (strong baseline)
4. `TD613_RECIPIENT_ATELIER`
5. `EM_RECIPIENT_ENCYCLOPEDIA`
6. `TRANSPORT_ONLY`

Preserve the six original conditions verbatim:
`REVIEWED_CANDIDATE`, `RIVAL_INTERPRETATION`, `REQUIRED_WITNESS_WITHDRAWN_CALLER_FLAGS_TRUE`, `DIGEST_VALID_IRRELEVANT_SPAN`, `UNREVIEWED_EQUAL_LABEL_JOIN`, `CONTEXTUAL_UNCERTAINTY_PRESERVED`.

For every arm/condition, capture immutable real input spans, exact emitted citations, actual outputs, refusals, candidate relationships, question proposals, rival interpretations, source-origin witness status, budget consumption, time, process exit, software versions, and state transitions. Verify the capability each tested operation purported to exercise. `get/search/cite/verify` on a synthetic placeholder is an *engineering test*, not an actual scientific source-recovery witness. Include active leak tests and state isolation. For human-in-the-loop or LLM-powered qualitative probes, capture exact prompts and outputs, model IDs, stochastic seeds where available, sampling settings and rerun variance; do not falsely imply deterministic reproducibility of nondeterministic inference.

**Interpretation ceiling during R1:** compute frozen mechanical statistics and classify provenance only. Do **not** proclaim novelty, scientific emergence, historical fidelity, or ZERO surplus. Unexpected findings become *sealed questions for Postflight*, not explanations or new interventions. Optional 7th arm only if already prospectively specified **before** any six-arm result was examined; the existing V0 results make a newly added seventh arm exploratory rather than blinded confirmatory.

If any authentic source read, adoption, recipient comparison, strong-union fairness or required custody test cannot execute, stop with a precise hold. A valid hold is a better outcome than simulated completion.

## 4. Postflight is an analysis program, not a checklist file

The largest remaining challenge is not generating a `POSTFLIGHT_READINESS_RECEIPT.json`; it is making each scientific claim independently auditable. A defensible Postflight must support the following distinct analysis layers **before** the interpreter is activated:

### A. Evidence admissibility and coverage
- Exactly which source-authenticated input/output pair and receiving state supports each claim? What controls were genuinely observed, which were simulated, and which remained held?
- Document immutable custody, reviewable ZIP bytes, hash manifests, origin boundaries, native source tests, lineage and route-specific timestamps.
- Report missingness, version drift, partial coverage and consequential limitations; define a completeness matrix, not a binary PASS.

### B. Causal and counterfactual comparator fairness
- Was source information, model/tool access, compute, human intervention, reviewed crosswalk and opportunity to form new questions truly equal across the strong union and recipient routes?
- Can a difference be attributed to architecture rather than corpus, version, context budget, source selection, order, cue leakage, prompt framing or nondeterministic variance?
- Use within-source, paired, cross-order and negative control analyses; identify confounders that prevent attribution.

### C. Non-scalar scientific capability analysis
- Distinguish **transport**, **retrieval**, **typed provenance**, **relation formation**, **reparative/warrant-aware abstention**, **new testable question formation**, **new discriminatory operation**, and **new validated relationship**.
- Preserve original prompts and sources and human-readable/rubric-coded candidate questions; numeric `emergence_score` is not a substitute for independently evaluated structure.
- Use predeclared `fiber_split`, `conditioning_stability`, `positive_and_hostile_witnesses`, `abstention_boundary` as *structural diagnostics*, not post-hoc proof of discovery.

### D. Robustness, falsification and null interpretations
- Independent adversarial review of strongest claim, matched alternative model, crosswalk removal, withheld witness, source-order reversal, claim-without-source, underbudget and missing-coordinate tests. Avoid exploring held-out B corpus during Experiment A.
- Define distinct acceptable conclusions: architecture **SUPPORTED in finite scope**, **PARITY**, **SUPERIORITY under matched budget but unreplicated**, **HELD by missing source**, **INCONCLUSIVE**, **FAILED**, or **NOVEL HYPOTHESIS requiring new independent empirical study**.
- Treat previous Alpha/Beta synthetic parity as pilot engineering evidence only. Do not retroactively call post-hoc cases preregistered.

### E. Mathematical and prior-art audit
- Check all candidate equalities, rank/conditioning calculations, definitions of synergy and emergence against explicit constructions and counterexamples; do not turn metaphors into theorems.
- Latifa leads L1–L4 are candidate questions, not the scientific purpose of A; preserve them for a separately scoped Wild Field appendix after the primary comparison is adjudicated.
- If browsing or research is undertaken at Postflight, date external prior-art sources and distinguish them from original input evidence. External literature may **challenge novelty**, never retroactively supply missing experimental observations.

### F. Independent adversarial adjudication
- Produce raw-evidence packet for a reviewer *not given Kenough's preferred conclusion first*, including versioned judgments, disagreements, alternative explanations and vetoes.
- For `/dollhouse-design` and `/dollhouse-audit`, preserve actual native inputs/outputs, strict provenance, explicit Orchestrator, Temporal Custodian, independent reviewer conclusions and vetoes. Native five-role findings cannot transform an unobserved reciprocal arm into a witnessed one.
- Separate analyst-generated interpretation, peer agreement, operator human scientific closure and new empirical acquisition. None should be inferred from the others.

## 5. Readiness gates — all evidence must pass before interpretive Postflight

| Gate | Required proof | Failure posture |
|---|---|---|
| `PF-A` | Flight-V0 physical ZIP checks and append-only correction | `HELD_UNVERIFIED_EVIDENCE_PACKET` |
| `PF-B` | Exact transferred 40,418-byte P1 with full `8f76e72c...` SHA-256 | `HELD_SOURCE_TRANSFER` |
| `PF-C` | Real P1 adopted into authentic independent empty Atelier; reopen/get/search/cite/verify; rollback | `HELD_RECIPROCAL_ADOPTION` |
| `PF-D` | All six source-based arms available under one fair matched frame, input/output traceability | `HELD_INCOMPLETE_SIX_ARM_EVIDENCE` |
| `PF-E` | Strong union is unhandicapped; all source, model, order, time and tool confounds disclosed | `HELD_CAUSAL_COMPARATOR` |
| `PF-F` | Controls, negative and hostile cases verified against actual sources; no retrospective prediction claim | `HELD_WARRANT_OR_CHRONOLOGY` |
| `PF-G` | Native design/audit evidence and independent dissent preserved; no self-certification | `HELD_INDEPENDENT_REVIEW` |
| `PF-H` | Actual Postflight analytic method, blind review design, null/alternative outcomes and reproducibility criteria specified **before interpretation** | `HELD_POSTFLIGHT_ANALYTIC_INFRASTRUCTURE` |

These are **readiness conditions**, not additional operator permission requests. The operator already authorized the bounded R1 remedy. If any condition cannot be satisfied, issue the corresponding hold and a finite remediation receipt. **Do not silently change gate definitions to obtain `READY`.**

`POSTFLIGHT_READY` can be asserted only if PF-A through PF-H have evidence-backed dispositions, and original `HELD_DISSENT` is addressed by actual new source observations or kept as independently explained, rather than overwritten. Even then, Postflight analysis requires its **separate activation** in a subsequent session with Argon High / highest available reasoning effort. Human scientific closure stays reserved.

## 6. Required deliverables and final stop

Deliver **one** immutable sealed `Experiment_A_Flight_R1_and_Postflight_Qualification` review package (ZIP) containing:

1. Source transfer/custody manifest, SHA-256, metadata, historic-original versus Library-candidate identity statement; avoid publicly bundling the confidential full P1 without explicit controlled transfer.
2. Original Flight-V0 hashes, machine receipts, corrected append-only source-absence/union-claim ledger, and precise genealogy linking V0 to R1.
3. R1 six-arm frozen input manifests and executable source-backed transcripts, canaries, citations, native-state screenshots or state logs when relevant, outputs, failures, control witnesses and strong union comparison; exact model and tool versions.
4. Predeclared controls and results with source-native versus provisional classification; all fair comparator deviations and negative outcomes.
5. Native Dollhouse design/audit real inputs and complete outputs, `HELD_DISSENT` history and adjudicator findings.
6. Postflight rubric, primary/null/rival hypothesis register, blinded review protocol, susceptibility to prompt/seed/context/version drift, and readiness gate machine + human receipts. No scientific Postflight interpretation yet.
7. Source-inclusive **private** package manifest, checksums and source-referenced pointers; no Git push, deployment, public release, B/C execution or new empirical exteriority claims.
8. Explicit list of files accessible to Emergence HQ and a practical operator transfer method; `file:///C:/...` links in a walkthrough are not remotely accessible here. Transfer the actual ZIP bytes as an attachment when requesting independent final adjudication.

If PF-A through PF-H pass: `POSTFLIGHT_READY_FOR_SEPARATE_ARGON_ACTIVATION` with `GATE_E_HELD` and `HUMAN_SCIENTIFIC_CLOSURE_RESERVED`.

If any fail: `POSTFLIGHT_READINESS_HELD_<specific_condition>` and a truthful finite repair ledger.

**Hard stop**:

`𝄐 EXPERIMENT_A_FLIGHT_R1_COMPLETE_OR_EVIDENCED_HOLD · REAL_P1_CANDIDATE_IDENTITY_CHECKED · ORIGINAL_V0_PRESERVED · POSTFLIGHT_READINESS_ADJUDICATED_NOT_ASSUMED · INTERPRETATION_NOT_STARTED · GATE_E_HELD · HUMAN_CLOSURE_RESERVED`

Tauric Diana · Khona‌lit-po · Sealed ⟐
