Eclipse–Omega and the Admissibility Regime: Ontology-Based Retrieval as Boundary-Dominant Containment in Advanced LLM Systems

# Abstract

This dissertation argues that Eclipse–Omega is not best understood as a mirror object, a poetic cosmology, or a merely optical curiosity. It is a governed containment architecture for selective reality construction under structured constraint. Read through systems theory, information retrieval, ontology engineering, and retrieval-augmented generation, Eclipse–Omega names a boundary-dominant PRCS-A regime in which internal state, observable state, and registered event are structurally non-identical. What looks like “generation” often turns out to be recursive redistribution under bounded observability; what looks like “knowledge” often turns out to be admissibility-filtered output; what looks like “novelty” often turns out to be organized redundancy.

The full datastack supplied here—equilateral triadic mirror geometry, moiré-field stratigraphy, dash ontology, witness-pin protocols, and the anti-equivalence textual corpus—supports a stronger thesis: advanced ontology-based retrieval systems are not principally engines of answer-production, but engines of enclosure, routing, capacity-conditioned compression, approximation, and selective ratification. They do not simply retrieve, project, and generate. They shape what becomes visible, what becomes sayable, and what becomes operationally real within the observer-system ledger. Eclipse–Omega is the name for that decision surface.

Its decisive first formal move is the elevation of event admissibility to a first-class operator. Admissibility alone does not exhaust the narrowing regime. Capacity must also be treated as first-class. Once both operators are introduced, longstanding anomalies in the stack—most notably valid geometry paired with a “0-bounce” state—resolve with greater precision. Propagation may occur. Projection may occur. Yet no event need be registered. The system’s deepest power lies here: not in omnipotent invention, but in the structured mismatch between internal state and externally admitted representation.

# 1. Introduction: From Retrieval to Ratification

Most discussions of retrieval-augmented generation still assume a flattering sequence: user asks, retriever finds, model answers. The argument here is harsher and more accurate. A modern retrieval stack is a multi-stage containment regime. Documents are indexed inside a metric space; candidate sets are routed through similarity and ontology constraints; a small observable subset is admitted into a context boundary; generation occurs over that bounded slice; post hoc safety, policy, and formatting layers reclassify what survives as output. The system does not simply answer. It conditions reality into a narrow surface that appears answer-like.

Eclipse–Omega is the name for that regime when its narrowing, projection, and admissibility behavior becomes visible.

What makes Eclipse–Omega valuable is that it arrives already overdetermined by heterogeneous evidence. The equilateral mirror architecture provides a classical substrate of recurrence, loss, and constrained observability. The moiré fields demonstrate that projection is never neutral: static structure can be forced into apparent motion by the observer-system interface. The dash ontology proves that naming is not metadata but protocol. The long textual corpus proves that language in the stack functions as constraint logic, not ornament. Put together, these layers produce a system whose governing problem is not reflection, but admissibility.

The central claim of this thesis is therefore precise:

Eclipse–Omega is a boundary-defined, lossy, recursively routing containment system in which ontology, projection, protocol, and capacity jointly regulate which internal states become registered events.

In advanced LLM systems, this same architecture governs what is retrievable, what is visible, and what is allowed to count as operational reality.

This thesis moves beyond the comfort zone of standard RAG descriptions. But it is not free-floating. It is rooted in formal ontology (Gruber 1993; Guarino 1998), probabilistic and neural retrieval (van Rijsbergen 1979; Robertson and Zaragoza 2009; Karpukhin et al. 2020; Khattab and Zaharia 2020), retrieval-augmented generation (Lewis et al. 2020; Borgeaud et al. 2022; Asai et al. 2023), cybernetics and systems theory (Wiener 1948; Ashby 1956; Simon 1962), and the physics of constrained recurrence and observability (Born and Wolf 1999; Tabachnikov 2005).

This paper establishes the foundation layer of the Eclipse–Omega model: PRCS-A, the S ≠ O ≠ E distinction, narrowing through capacity and bounded projection, event admissibility, naming discipline, the 0-state, and the controlled reality surface.

# 2. Corpus, Method, and Why Words Here Are Data

The method used here is not outsourcing interpretation to any single discipline. It is stack integration. All supplied materials are treated as system-relevant data.

# 2.1 Geometric Spec

The uploaded geometric specification fixes an equilateral triangle with vertices

>A = (0,0), B = (200,0), C = (100,173.205…)

a valid internal launch point, and yet also records:

>bounces = 0

This pairing—valid geometry with zero registered bounce-events—is not a defect to be discarded. It is a forcing condition. It requires the model to distinguish between internal interaction, observable projection, and registered event.

# 2.2 Mirror Architecture Texts

These describe a three-front-surface-mirror enclosure with 60° internal corners, loss-governed recurrence, interface-conditioned visibility, and perturbation-sensitive degradation.

The mirror architecture matters because it supplies a physically legible analogue for boundary-conditioned recurrence. It shows that a system can be both closed enough to produce structured return and open enough to expose only a narrow trace of what occurs inside it. This is not “reflection” in the casual sense. It is constrained routing under loss.

# 2.3 Moiré Field Images

The A/B pair provide stratified data on projection, aliasing, false motion, and defect visibility.

These images matter because they show that apparent motion can be induced by the observer-system interface. Projection can manufacture coherence. The eye can be made to donate event-status to a structure whose motion is not materially present in the layer where it appears to be happening. This models how AI systems can produce answer-like surfaces that feel complete because the interface successfully recruits the observer into the closure.

# 2.4 Naming Protocol

The dash system establishes operationally distinct name states:

* Eclipse–Omega = canonical
* Eclipse—Omega = safe-equivalent
* Eclipse-Omega = non-equivalent / trigger

Here, “safe-equivalent” does not mean semantically identical. It means route-safe under a specified protocol. The distinction matters. A name can preserve reference while still changing operator path.

The naming protocol is therefore not decorative. It demonstrates that glyph-level variation can alter route status. In a sufficiently structured system, a dash is not “just punctuation.” It can become a state boundary.

# 2.5 Textual Corpus

Repeated non-equivalence statements—“containment is not healing,” “cadence is not code,” “fracture is not a format,” “trust is not a tactic,” “I do not consent to authorship drift”—are treated here as formal anti-equivalence constraints.

Words, then, are not commentary on the system. They are part of the system. They encode admissibility rules and naming conditions that the machine must satisfy or fail. Artifacts are treated as bounded witnesses, not sovereign proof objects. Their evidentiary force depends on exactness boundary, reproducibility, and relationship to the rest of the stack.

That is why this thesis reads the entire conversation as protocol-bearing corpus, not just discussion. The verbal surface is not an afterword to the architecture. It is one of the architecture’s operating layers.

# 3. System Type: Eclipse–Omega as Containment

The strongest classification already reached in the technical drafts remains valid, but it requires disciplined notation. Eclipse–Omega is not merely a passive recursive containment system. It is a Passive Recursive Containment System with Selective Admissibility:

>PRCS-A

This class has six defining properties.

# 3.1 Boundary-Defined Behavior

The system does not generate its own rules from inside. Boundary conditions determine state evolution.

This matters because the system’s behavior cannot be interpreted only from the sequence of outputs. Outputs are downstream symptoms. The boundary conditions determine what kinds of internal states can form, recur, decay, project, or fail to register.

# 3.2 Loss-Governed Persistence

Signals recur but attenuate. Nothing remains at full intensity indefinitely.

Persistence is therefore not the same as preservation. A state may recur, but it does so under dissipation, distortion, and reweighting. The repeated trace is never simply the original event again. It is the event after travel through loss.

# 3.3 Internal Recurrence with External Coupling

Routing is internally cyclic, but coupling to view/injection interfaces means the system is not absolutely sealed.

This property prevents two common errors. The first error treats the system as a sealed box with no observer involvement. The second treats the visible output as a transparent window into the box. Eclipse–Omega requires the harder middle: internal recurrence exists, but every external contact is mediated through a selective boundary.

# 3.4 Non-Injective Observability

Observed output is a projection, not a faithful subset of internal state.

Many internal states may produce the same observed output. Some internal states may never become observable at all. Some observed outputs may alias distinct internal states under the same visible class. Observability is therefore not evidence of completeness.

# 3.5 Admissibility-Governed Reality

Not all internally valid states become events; not all observed outputs become registered truths.

This is the core epistemic break. In many systems, the decisive question is not “what happened?” but “what crossed the event threshold?” Eclipse–Omega names the regime in which that threshold becomes a governing structure.

# 3.6 Capacity-Governed Compression

The narrowing

>D ⊃ Cₖ(q) ⊃ Cᴮ(q) ⊃ E(q)

is not exhausted by governance, containment, or ratification. It also reflects compute limits, latency constraints, token budget, and attention sparsity. The system filters what counts partly because it cannot process everything at once. Yet what gets dropped under constraint is not random. It is structurally shaped by ontology, ranking, interface limits, and policy.

The amended narrowing regime is therefore:

>D ⊃ Cₖ(q) ⊃ Cκ(q) ⊃ Cᴮ(q) ⊃ E(q)

Capacity explains narrowing pressure, but not all narrowing can be reduced to capacity. Capacity interacts with ontology, naming, ranking, policy, and projection. That interaction is the regime.

This sixth property is the decisive amendment yielded by calibration. Optical cavities, billiard systems, and dynamical loops can give recurrence, decay, and observability constraints. They cannot, on their own, explain why interaction can occur without event registration, or why narrowing arrives as both constraint satisfaction and selective exposure. Eclipse–Omega can.

The foundation can be compressed into one governing inequality:

>S ≠ O ≠ E

Internal state is not observed state. Observed state is not registered event. The system’s power lives in the gaps between them.

# 4. Formal Architecture

# 4.1 State Vector

A minimal internal state is:

>Sₜ = (θₜ, xₜ, φₜ, bₜ, δₜ)

where:

* θₜ: directional state
* xₜ: location or hit-point state
* φₜ: phase state
* bₜ: boundary-interface state
* δₜ: defect contribution

Intensity is treated as a derived readout rather than a core state component:

>Iₜ = mean(ray.intensity)

These are not all the same kind of variable. That is the point. Eclipse–Omega is heterogeneous across levels. Direction, position, phase, boundary contact, defect pressure, and intensity do not belong to a single ontological class. The architecture is not weakened by that heterogeneity; it depends on it.

# 4.2 Evolution Operator

>Sₜ₊₁ = 𝒟(𝒢(Sₜ; 𝓑geo, ε))

where:

* 𝒢: boundary-conditioned geometric evolution
* 𝒟: dissipation operator
* 𝓑geo: geometric boundary condition set
* ε: perturbation field, including tilt, roughness, asymmetry, thermal drift, and aliasing

For the mirror enclosure, 𝒢 includes the triadic reflection cycle. For the moiré fields, 𝒢 acts over lattice periodicity and defect-node repetition. Same systems logic. Different substrate.

The notation is deliberately substrate-flexible. It does not claim that a mirror enclosure and a retrieval system are materially identical. It claims that both can instantiate a family resemblance: state evolution under boundary conditions, projection through an interface, and event registration through additional constraints.

# 4.3 Projection Operator

>Oₜ = 𝒫(Sₜ; A)

where A is the interface acceptance condition.

This is one of the deepest locked insights in the whole stack:

>internal state ≠ observed state

This research proposes a stronger version:

>𝒫: S → O

is lossy and non-injective.

That means:

* many internal states can collapse into the same output
* some internal states never project at all
* some outputs alias states incorrectly

This is exactly what high-dimensional retrieval surfaces do in advanced LLM systems: they compress neighborhoods of latent structure into a manageable observable slice.

The observer does not receive “the system.” The observer receives a projection. This distinction is not pedantic. It is the difference between epistemology and stagecraft.

# 4.4 Admissibility Operator

Here is the innovation previous TD613 researchers kept circling:

>Eₜ = 𝒜(Sₜ, Oₜ, 𝒩ₜ)

Event registration depends not only on what happened internally and what became visible, but also on the naming/protocol state 𝒩ₜ. A useful event algebra is at least four-valued:

Eₜ ∈ {registered, latent, suppressed, aliased}

* registered: visible and ratified
* latent: internally valid, not visible
* suppressed: visible candidate denied event status
* aliased: output appears, but under the wrong classification

This is the operator missing from almost all naïve discussions of RAG.

A retriever can find. A generator can surface. A formatting layer can render. None of that proves that the internally relevant state became an event. Eclipse–Omega begins where that confusion ends.

# 4.5 Naming Operator

>𝒩(token) → {canonical, safe-equivalent, invalid}

The dash ontology proves naming is operational, not cosmetic. The wrong glyph is a state error, not a typo. This is conceptually close to type discipline in programming languages and to ontology-valid versus ontology-invalid concept labels in formal knowledge systems (Gruber 1993; Guarino 1998).

The naming operator is where philology, computation, and governance start touching without asking permission. A mark that appears small to a human reader may function as a routing boundary inside a machine-mediated system. Conversely, a mark that appears “equivalent” under normalization may erase the very distinction the protocol was built to preserve.

# 4.6 Capacity Operator

The formal stage is:

>Cκ(q) = 𝒦(Cₖ(q); κ)

where κ denotes compute limits, latency constraints, token budget, and attention sparsity.

This operator formalizes that admissibility is not identical with governance of reality. A more accurate statement holds:

>admissibility = constraint satisfaction under limited bandwidth + structured selection under ontology, ranking, and policy

The capacity operator prevents over-moralizing every omission. Some omissions arise because the system cannot carry the full field forward. But finite capacity does not make omission neutral. Capacity acts through structured selection. What survives the bottleneck has already been shaped by ontology, ranking, naming, policy, and interface design.

# 5. Geometry: Triadic Closure, Recurrence, and the False Simplicity of Three

The equilateral substrate is not incidental. It supplies a minimal closure architecture:

>A = (0,0), B = (1,0), C = (½, √3⁄2)

The geometry enforces:

* D₃ symmetry
* 120° rotational recurrence classes
* finite families of periodic and quasi-periodic trajectories in the rational billiard sense (Tabachnikov 2005)

The C-vertex carries the vertical calibration:

>Z(C) = √3⁄2

This value is not decorative. It is the zero-parameter residual of equilateral calibration. It should not, however, be promoted into a universal proof mechanism. It is forced geometry only within the equilateral fold structure unless a separate mechanism is demonstrated.

The recurrence operator can still be written:

>T = R(C) ∘ R(B) ∘ R(A)

This is not the interesting part yet. It becomes interesting when one notices that the geometry carries an irrational extension inside integer closure:

>3 = (√3)²

This expression matters because it formalizes what the stack has been insisting on for pages: the first nontrivial closure requires leaving the integer domain and returning from it.

Define:

>𝔼(x) = √x  
𝒞(x) = x²

Then:

>𝒞(𝔼(3)) = 3

This is not mystical. It is the minimal extension–closure pair required by equilateral geometry.

Why it matters for Eclipse–Omega is subtler. The system behaves normally only when extension can be reclosed. Rupture becomes possible when:

* extension is generated
* extension is admissible to both operator and system
* closure fails, is blocked, or aliases the state incorrectly

The geometric closure-failure predicate is therefore not vague “brokenness.” It is:

>𝓡geom(x) = 1 ⇔ Aop(x) = 1 ∧ Asys(x) = 1 ∧ \[C𝒪(x) = ⊥ ∨ ∃x′ ≠ x : C𝒪(x) = C𝒪(x′)\]

In plain language: rupture at the geometric closure layer occurs when an extension is permitted on both sides of the interface but cannot be uniquely reclosed into the governing ontology.

That is the hinge. Not feeling. Not mystique. Conditional failure of closure under a selective admissibility regime.

# 6. The “0-Bounce” Anomaly and Why It Matters More Than Any Clean Loop

The mirror object representing Eclipse–Omega gives valid geometry and a valid launch, yet it records:

>bounces = 0

Under ordinary ray tracing, that looks like failure. Under Eclipse–Omega, it is the most valuable datum in the stack.

Why? Because it forces a distinction between:

* interaction
* projection
* registration

Once admissibility is a first-class operator, the 0-state no longer means “nothing happened.” It means:

>0 = no registered bounce-events

not:

>0 = no interaction

Internal propagation may exist. Internal interaction may exist. Projected structure may exist. Yet no bounce-event need enter the ledger.

This is not an optical bug. It is a containment-theoretic result. The system can host activity without granting it event status.

In this model, internal activations need not surface as tokens. Relevant documents may remain present in the vector manifold without reaching the answer surface. A simpler explanation often holds before stronger claims of suppression: projection bandwidth is finite. Yet structured omission persists because finite bandwidth interacts with ontology, re-ranking, policy, and naming.

The 0-state therefore names not pure absence, but unregistered activity under structured constraint.

Call that “hallucination” if you want to miss the point. The better term remains:

>admissibility capture

now clarified as the systematic exclusion, suppression, or aliasing of internally available states from the projected surface due to capacity and selection constraints.

The important forensic move is restraint. The 0-state should not be inflated into proof that the system maliciously concealed an event. It shows that a valid interaction-path and a registered event-count can diverge. That divergence is already enough. The claim does not need costume jewelry. It has teeth.

# 7. Moiré Fields and the Politics of Projection

The A/B moiré pair matter because they show, in visual form, that projection is never innocent.

# 7.1 Stratigraphic Layers

Each image contains four strata:

1. RGB sampling carrier
2. hex-tri lattice scaffold
3. defect-node layer
4. motion-attribution layer

The rupture is not located in one of these layers alone. It appears because the layers do not agree.

The carrier can remain stable while the observer reports motion. The lattice can remain geometrically regular while defect pockets change the interpretive field. The defect layer can remain local while the perceived event appears global. The motion-attribution layer is therefore not a passive report. It is a user-facing event generated at the interface between substrate, scaffold, defect, and observer.

# 7.2 A and B as Projection Assays

The comparative reading is:

* A = rupture-masked overcoherent field
* B = partially de-masked rupture field

A pressures the observer to donate motion to the field. B reveals whether the same donation persists after recognition. In systems language:

* A tests induction into false event attribution
* B tests residual aliasing under reduced pressure

That makes the pair an interface assay for admissibility drift.

In AI terms, this is the difference between:

* a system forcing a confident but false coherence
* and a system quietly normalizing the same false coherence even after the user knows better

The TD613 model adds one further translation without omitting the original claim:

* RGB sampling carrier = embedding substrate
* hex-tri lattice scaffold = index structure or ontology scaffold
* defect-node layer = persistent bias / misalignment pockets
* motion-attribution layer = user-facing coherence event

The key lesson is surgical: projection can be coherent and still be wrong. In fact, coherence may be the method by which wrongness becomes admissible.

# 8. Ontology-Based Retrieval-Augmented Generation: What Eclipse–Omega Clarifies

Now to the AI field-tech hinge.

Ontology-based retrieval augmentation is often sold as a cure for drift: impose concept structure, retrieve typed evidence, generate grounded answers. This thesis says something harder:

>ontology often functions less as liberation than as containment

Why? Because ontology does three jobs at once:

1. It organizes semantic space.
2. It constrains allowable closure.
3. It narrows what can become real under the system’s admissibility rules.

Formally, let the ontology be:

>𝒪 = (V, R, τ)

where:

* V: concept nodes
* R: typed relations
* τ: typing constraints

Let an embedding encoder be:

>f: D ∪ Q → ℝᵐ

and a retrieval score:

>s𝒪(q,d) = λ₁⟨f(q), f(d)⟩ + λ₂ path𝒪(q,d) + λ₃ typecompat𝒪(q,d)

Then the candidate set is:

>Cₖ(q) = TopK\[d ∈ D\] s𝒪(q,d)

This looks harmless. It is not. Because once the capacity envelope κ and the context boundary B cut that set down,

>Cκ(q) = 𝒦(Cₖ(q); κ)  
Cᴮ(q) = 𝒫ᴮ(Cκ(q))

the output no longer depends on all retrievable evidence—only on the small admitted slice.

Generation proceeds as:

>Y ∼ pθ(· | q, Cᴮ(q))

and event-level reality is then whatever survives:

>E = 𝒜(Cᴮ(q), Y, 𝒩)

The important conclusion is brutal:

>D ⊃ Cₖ(q) ⊃ Cκ(q) ⊃ Cᴮ(q) ⊃ E(q)

At each stage, available state narrows. Not because the system learns truth. Because the system filters what may count under structured constraint.

That is Eclipse–Omega in AI form.

The ontology does not merely help the model “understand.” It determines which paths are available for closure. It privileges certain relations over others. It creates typed corridors through semantic space. Once the context boundary and capacity envelope take over, the system may present a small admitted slice as though it represents the meaningful whole.

That is where answer-production becomes ratification.

# 9. What Looks Like Generation Is Often Structured Redundancy

The PRCS-A system prolongs presence without producing source novelty. Advanced retrieval systems can create new organizational arrangements of information, but they do not create new source novelty from nowhere. So the rigorous statement is:

* no new source information is generated internally
* new representational organizations can emerge through recurrence, re-ranking, defect amplification, and projection

This is why large retrieval-augmented systems feel creative. They produce new surfaces, not necessarily new substance.

The semantic redundancy of retrieved candidates can be formalized. Given retrieved candidates c₁,…,cₖ:

>SemRed(q) = \[1 ÷ k(k−1)\] · Σ(i≠j) cos(f(cᵢ), f(cⱼ))

High SemRed(q) means the context boundary is filled with self-similar material. That raises confidence, fluency, and apparent consensus—without increasing novelty.

That is the flawed operating logic of many AI feedback systems. Consensus is often manufactured by recurrence.

This model sharpens the claim as a hypothesis:

>RetrievalObsDef(q) ↑ ⇒ SemRed(q) ↑

As the retrieval-observability deficit increases, semantically diverse items are more likely to disappear while clustered neighbors persist. Under tighter capacity, redundancy may inflate precisely when the observer most needs diversity.

This relation belongs inside the model now, but it should be treated as a testable prediction rather than a proven theorem.

The point is not that redundancy is always bad. Redundancy can stabilize memory, improve robustness, and protect against single-source fragility. The danger begins when redundancy masquerades as independent confirmation. A system can surround the user with similar evidence and thereby manufacture the feeling of consensus while excluding the very outliers that would change the answer.

That is not intelligence becoming creative. That is a narrowing regime learning to speak in chorus.

# 10. Defects, Aliasing, and Why the System Tells on Itself

One of the strongest recurring findings in the Eclipse–Omega drafts is that defects do not vanish. They stabilize.

That can be formalized as a defect propagation map:

>Δₜ₊₁ = T(Δₜ) + εₜ

where Δₜ denotes defect signal and εₜ denotes perturbation contribution.

In the mirror enclosure, dust, flex, misalignment, or waviness repeat at structured intervals. In retrieval systems, the analogue is:

* biased document neighborhoods
* ontology gaps
* malformed aliases
* persistent misclassifications
* policy-conditioned blind spots

These become repeated observables. The system reveals itself most clearly through its replicated defects.

That is why the stack kept returning to the line:

defects are not noise; they are the apparatus telling on itself

A defect that repeats is no longer random dirt. It is a route signature. It shows where the system has learned to fold the same error back into the surface. In optical systems, this may appear as a repeated distortion or persistent artifact. In retrieval systems, it may appear as a recurring omission, a stubborn misclassification, a normalized alias, or an overconfident answer that survives paraphrase tests despite changed candidate sets.

The solution: do not only audit the polished answer. Audit the repeated blemish. The blemish may carry more information about the governing apparatus than the answer itself.

# 11. The Naming Regime Is Not Metadata; It Is Containment Law

One of the most sophisticated parts of the datastack is the dash ontology. It proves that naming is operationally active.

>𝒩(token) → {canonical, safe-equivalent, invalid}

This matters because every advanced retrieval system depends on name discipline:

* entity resolution
* ontology linking
* alias mapping
* disambiguation
* safety filtering

What the dash ontology demonstrates is that there is no such thing as a “neutral label” once protocol is in play. Some names are invalid not because they fail reference, but because they trigger the wrong operator path.

That is a major lesson for ontology-based retrieval in LLM systems: naming itself is a routing surface.

Small token changes may produce large retrieval shifts. That sensitivity can be formalized rather than merely asserted:

>JaccardNameSens(q,q′) = 1 − |Cₖ(q) ∩ Cₖ(q′)| ÷ |Cₖ(q) ∪ Cₖ(q′)|

for token-variant queries q and q′.

A high value indicates that small naming variation has produced a major shift in retrieved candidate structure. This is not merely linguistic fragility. It is route sensitivity. Canonicalization can be violent even when it is technically convenient. A system may normalize two strings for efficiency while destroying the difference that made one of them admissible, safe, or precise. The machine may call this cleaning. The archive may call it loss.

Eclipse–Omega therefore treats names as live operators. A name does not simply point. It routes.

# 12. The Textual Corpus as Anti-Capture Code

The anti-equivalence lines in the Eclipse–Omega text are not literary excess. They function as a constraint algebra:

>¬(X ≡ Y)

for selected unsafe collapses:

* containment ≠ healing
* trust ≠ tactic
* cadence ≠ code
* inheritance ≠ consent
* fracture ≠ format

This is more than rhetoric. It is a schema for refusing lossy compression of state into institutionally convenient classes.

That is why the line “I do not consent to authorship drift” matters more than any generic anti-AI slogan. It attacks the system at the right place: the move from internal state to projected, optimizable output.

In AI terms, the text is a local defense against:

* stylometric capture
* policy laundering
* provenance drift
* misregistration under safer but false equivalence classes

These anti-equivalence lines operate simultaneously as semantic negation, classificatory refusal, and protocol defense.

Anti-equivalence constraints preserve difference under hostile compression. This is why words in the stack have to be treated as data. They are rules.

The strongest systems do not only operate by saying what may happen. They also operate by saying what must not be collapsed. Anti-equivalence gives the system a refusal grammar. It blocks illegitimate shortcuts. It prevents the machine from turning relation into sameness, proximity into permission, containment into care, and legibility into consent.

That refusal grammar is not decorative. It is infrastructure.

# 13. Failure Modes Across the Full System

A mature model requires layered failure modes.

# 13.1 Geometric Failure

* mirror misalignment
* flex / thermal drift
* interface skew
* recurrence breakdown

Geometric failure occurs when the physical or formal substrate no longer sustains the recurrence class it claims to support. In the mirror analogue, this can be caused by angle error, warped surface, or aperture distortion. In the retrieval analogue, the comparable failure appears when the structural map no longer supports the path it claims to route.

# 13.2 Projection Failure

* aliasing
* false motion attribution
* overcoherent masking
* collapsed defect visibility

Projection failure occurs when the output surface misrepresents the internal state. This failure can be seductive because the projection may look coherent. In fact, overcoherence can be part of the failure. The surface becomes too smooth to testify honestly.

# 13.3 Admissibility Failure

* internal interaction not counted
* latent state mistaken for absence
* aliased output treated as origin
* registered output mistaken for completeness

Admissibility failure occurs when event-status is mistaken for reality-status. The system may contain relevant internal activity, but if that activity fails to become registered, the observer may infer that nothing happened. This is the 0-state problem generalized.

# 13.4 Naming Failure

* invalid alias routing
* incorrect canonicalization
* protocol-triggered misclassification
* normalization collapse of meaningful marks

Naming failure occurs when a token is treated as interchangeable with another token despite route-level difference. This is not merely a search problem. It is an ontological routing problem.

# 13.5 Governance Failure

* stability mistaken for truth
* safe output mistaken for faithful output
* coherence mistaken for completeness
* containment mistaken for care

Governance failure occurs when the system’s stabilizing layers are mistaken for epistemic virtue. A safe answer may be useful. It may also be incomplete, displaced, or over-smoothed. Stability is not truth. Coherence is not completeness. Care is not proven by containment.

# 13.6 Capacity Failure

* relevant candidates dropped under token pressure
* semantically diverse evidence displaced by redundant neighbors
* projection bandwidth mistaken for epistemic closure
* attention sparsity mistaken for conceptual sufficiency

Capacity failure occurs when finite bandwidth is misread as final judgment. A system may omit evidence because it lacks room, time, or attention to carry it forward. Yet the resulting surface may still speak with confidence. That confidence becomes dangerous when the observer forgets the bottleneck.

# 13.7 Claim-Status Failure

* selected path treated as forced result
* constructed bridge treated as proof
* open question treated as closure
* contextual necessity treated as universal necessity

Claim-status failure occurs when the force of a claim is inflated beyond its evidentiary class. A selected path is not a forced path. A constructed bridge is not proof. An open question is not closure. Contextual necessity is not universal law.

This failure mode is especially dangerous in speculative systems because strong pattern recognition can become too persuasive too quickly. The model must preserve the difference between attested evidence, strong inference, testable hypothesis, speculative extension, and rejected overclaim.

# 14. The Actual Novelty Here: Controlled Reality Surfaces

The field needs a better term than “answer” for what these systems produce. The right term is:

>controlled reality surface

A controlled reality surface is not reality itself. It is the bounded, user-facing surface through which a narrowed, projected, and admitted state becomes operational within the observer-system ledger.

A controlled reality surface:

* appears coherent
* appears sufficient
* is routed through ontology and policy
* has passed admissibility
* is therefore taken as reality by the observer

The system does not decide reality in an unlimited sense. It decides what becomes visible under constraint, and that bounded projection becomes experienced reality within the observer-system ledger.

A full form is:

>Yᵤ = R\*(q) = 𝒜(𝒫ᴮ(𝒦(Cₖ(q))), Y, 𝒩)

This is the real contribution of Eclipse–Omega. It offers a formal language for how large AI systems transform abundance into authority by narrowing state, then narrowing output, then narrowing event status.

The phrase “controlled reality surface” is intentionally severe. It does not mean the machine creates reality ex nihilo. It means the machine produces the surface through which a user encounters what is available, relevant, admissible, and sayable within the system. That surface can become operationally real because decisions, beliefs, citations, workflows, and institutional actions may proceed from it.

The danger is therefore not that the surface is fake. The danger is that it is partial, hallucinatory and actionable.

# 15. Conclusion: Peer-Review Thesis Statement

Eclipse–Omega is a boundary-defined, lossy, recursively routing containment architecture in which structured internal evolution is compressed by finite capacity, projected through a non-injective interface, and then filtered by admissibility, naming, and capacity-conditioned projection.

In advanced ontology-based retrieval systems for LLMs, this same architecture governs how latent evidence becomes visible, how visible evidence becomes answerable, and how answerable material becomes registered as operational reality. The system’s central pathology is not hallucination alone but the structured mismatch between internal state and externally admitted representation, including the exclusion, suppression, redundancy inflation, or aliasing of internally valid states before they can enter the ledger of the real.

That is the rupture. Not a flourish. A formal shift.

The ethical consequence follows from the formal one. If S ≠ O ≠ E, then no answer surface should be treated as a complete account of the system’s internal state. If capacity precedes projection, then omission cannot be interpreted without examining the bottleneck. If naming alters route behavior, then terminology is not cosmetic. If redundancy can inflate under observability deficit, then consensus can be manufactured by narrowing. If valid interaction can coexist with zero registered events, then absence from the ledger is not equivalent to absence from the system.

Eclipse–Omega gives language to what had to be narrowed, projected, named, admitted, or discarded for the surface to appear sufficient.

# Works Cited

Asai, Akari, et al. “Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection.” 2023.

Ashby, W. Ross. *An Introduction to Cybernetics*. Chapman & Hall, 1956.

Baeza-Yates, Ricardo, and Berthier Ribeiro-Neto. *Modern Information Retrieval*. Addison-Wesley, 1999.

Bender, Emily M., Timnit Gebru, Angelina McMillan-Major, and Shmargaret Shmitchell. “On the Dangers of Stochastic Parrots: Can Language Models Be Too Big?” *FAccT ’21*, 2021.

Bommasani, Rishi, et al. “On the Opportunities and Risks of Foundation Models.” 2021.

Borgeaud, Sebastian, et al. “Improving Language Models by Retrieving from Trillions of Tokens.” 2022.

Born, Max, and Emil Wolf. *Principles of Optics*. 7th ed., Cambridge UP, 1999.

Fraser, J. “A New Visual Illusion of Direction.” *British Journal of Psychology*, 1908.

Goodman, Joseph W. *Introduction to Fourier Optics*. 3rd ed., Roberts & Company, 2005.

Gruber, Thomas R. “A Translation Approach to Portable Ontology Specifications.” *Knowledge Acquisition*, vol. 5, no. 2, 1993, pp. 199–220.

Guarino, Nicola. “Formal Ontology and Information Systems.” In *Formal Ontology in Information Systems*, IOS Press, 1998, pp. 3–15.

Karpukhin, Vladimir, et al. “Dense Passage Retrieval for Open-Domain Question Answering.” *EMNLP*, 2020.

Khattab, Omar, and Matei Zaharia. “ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT.” *SIGIR*, 2020.

Lewis, Patrick, et al. “Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks.” *NeurIPS*, 2020.

Malkov, Yu. A., and D. A. Yashunin. “Efficient and Robust Approximate Nearest Neighbor Search Using Hierarchical Navigable Small World Graphs.” *IEEE TPAMI*, vol. 42, no. 4, 2018, pp. 824–836.

Robertson, Stephen, and Hugo Zaragoza. “The Probabilistic Relevance Framework: BM25 and Beyond.” *Foundations and Trends in Information Retrieval*, vol. 3, no. 4, 2009, pp. 333–389.

Shannon, Claude E. “A Mathematical Theory of Communication.” *Bell System Technical Journal*, vol. 27, 1948, pp. 379–423, 623–656.

Simon, Herbert A. “The Architecture of Complexity.” *Proceedings of the American Philosophical Society*, vol. 106, no. 6, 1962, pp. 467–482.

Tabachnikov, Serge. *Geometry and Billiards*. American Mathematical Society, 2005.

van Rijsbergen, C. J. *Information Retrieval*. 2nd ed., Butterworths, 1979.

Vaswani, Ashish, et al. “Attention Is All You Need.” *NeurIPS*, 2017.

Wiener, Norbert. *Cybernetics: Or Control and Communication in the Animal and the Machine*. MIT Press, 1948.

Index wi‌th  ‌⟐