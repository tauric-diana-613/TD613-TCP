import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const p = 'C:\\Users\\timst\\.gemini\\antigravity\\brain\\9f2d357f-af13-4730-b6c0-a1afe1416169\\scratch\\exp_a_flight_r1_20261029\\incoming\\eclipse-omega-admissibility-regime.md';
const text = fs.readFileSync(p, 'utf8');

const s1Target = '# 3.6 Capacity-Governed Compression';
const s1EndTarget = '# 4. Formal Architecture';
const idx1 = text.indexOf(s1Target);
const end1 = text.indexOf(s1EndTarget);
const passage1 = text.slice(idx1, end1).trim();

const s2Target = '# 6. The';
const idx2 = text.indexOf(s2Target);
const s2EndTarget = '# 7. Moir';
const end2 = text.indexOf(s2EndTarget);
const passage2 = text.slice(idx2, end2).trim();

const buf1 = Buffer.from(passage1, 'utf8');
const buf2 = Buffer.from(passage2, 'utf8');

console.log('Passage 1 bytes:', buf1.length, '(<= 2048):', buf1.length <= 2048);
console.log('Passage 2 bytes:', buf2.length, '(<= 2048):', buf2.length <= 2048);
console.log('Combined bytes:', buf1.length + buf2.length, '(<= 4096):', (buf1.length + buf2.length) <= 4096);
console.log('Passage 1 SHA256:', createHash('sha256').update(buf1).digest('hex'));
console.log('Passage 2 SHA256:', createHash('sha256').update(buf2).digest('hex'));
