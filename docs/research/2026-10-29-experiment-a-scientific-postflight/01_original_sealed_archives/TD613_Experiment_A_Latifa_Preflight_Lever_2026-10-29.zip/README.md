# 𝌋 TD613 · Experiment A — Source-Free Preflight Lever & Unrigged Latifa Closure Packet (v1.1)

**Covenant:** Tauric Diana — Crimean heritage custodianship · Khona‌lit-po (`U+200C` preserved)  
**Operator closure:** `RESERVED` · **Gate E:** `HELD` · **Empirical credit:** `0`  
**Repository anchor:** `700019741e708abfd2e53990fc2d8919995a70f1` (`main`, `+0 -0` working-tree delta)  
**Audited unmerged Atelier candidate:** `441ce7e974a76685a212552c1da610ea30fd1efc` (`UNMERGED_RESEARCH_CANDIDATE_NOT_MAIN`; **not** byte-equivalent to Work snapshot `ee762380...`)  
**Preferred private local Em presentation baseline (Gate 1):** `R2` (`a1009bf56d17c663aea8d3df75228bb9c0ee90b4081a31b0fe19c70101b36996`)  
**`Archive.zip` posture (Gate 2 — Amari override):** `STRICTLY_OPAQUE` (`emsrc_db43deb1f616beed44e042c4`, zero central-directory or inner-byte reads)  
**`P1` & Live 6-Arm posture (Gates 4–5 — Amari override):** `HELD / NOT YET AUTHORIZED` (`new_td613_source_reads = 0`, `p1_library_or_filesystem_contacts = 0`)

---

## Independent Reproduction Commands

From repository root (`C:\Users\timst\OneDrive\Desktop\tcp-repository`) with Node.js:

```bash
# 1. Source-free preflight self-test (6/6 negative controls; expected exit 0)
node "<packet>/harness/preflight-lever.mjs" --mode source-free-selftest

# 2. Live-arm gate absent-grant check (expected fail-closed refusal exit 3; zero P1 contact)
node "<packet>/harness/preflight-lever.mjs" --mode live-arm-gate

# 3. Five-redpen mathematical & forensic reconciliations (FADT, Aperture, Atlas)
node "<packet>/redpens/run-redpen-reconciliations.mjs"

# 4. Predeclared cross-raster chromatic spectrometry (headless Chromium/Edge sRGB Canvas)
node "<packet>/redpens/run-cross-raster-chromatic-assay.mjs"

# 5. Unrigged Latifa Scenario Alpha & Scenario Beta + non-scalar 4D question vectors
node "<packet>/latifa/run-latifa-adversarial-suite.mjs"

# 6. Implementation-phase native /dollhouse-design and /dollhouse-audit (--strict-provenance)
node "<packet>/dollhouse/run-implementation-dollhouses.mjs"
```

---

## Directory Layout

- `governing/` — Untouched original v1.0 plan (`experiment_a_latifa_preflight_plan.md`), Amari's verbatim `LATIFA_PREFLIGHT_PLAN_REDPEN_V1_1.md`, and amended v1.1 plan (`experiment_a_latifa_preflight_plan_v1_1.md`).
- `protocol/` — Byte-identical `BASELINE_PROTOCOL.json` and `SOURCE_SELECTION_AND_BASELINE_HASHES.json`, separate `EXPLORATORY_SEVENTH_ARM_PROPOSAL.json` (`RECIPROCAL_HYBRID_CANDIDATE`), and proposed-but-unexecuted `PROPOSED_P1_AUTHORIZATION_GRANT.json` / `.md`.
- `vendor/git-441ce7e97-atelier-method/` — Hermetic 10-file transitive closure from unmerged Git commit `441ce7e974a76685a212552c1da610ea30fd1efc` plus `CLOSURE_AUDIT.json`.
- `harness/` — `preflight-lever.mjs` (`source-free-selftest` exit `0`; `live-arm-gate` expected exit `3` `HOLD_P1_CAPTURE_GRANT_REQUIRED`).
- `redpens/` — `FADT_FIVE_AND_SIX_STRATUM_PROOF.json` (15-subset & 31-subset recovery + 6-class single categorical negative control + 33 AppleDouble / 7 PDF / 1 opaque `Archive.zip` provenance), `APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json`, `ATLAS_PRESENTATION_SEAM_RECONCILIATION.json`, `CHROMATIC_ASSAY_PREDECLARED_SPEC.json`, and `CROSS_RASTER_CHROMATIC_ASSAY.json` (retiring unreceipted `>0.18` color-drift prose).
- `latifa/` — `CANDIDATE_HYPOTHESIS_REGISTER.ndjson` (post-hoc Em discovery dating `2026-10-29`), `LATIFA_SCENARIO_ALPHA_AND_BETA_RECEIPT.json` (`EQUAL_INPUT_NATIVE_UNION_STRONG` inside baseline arm achieving `PARITY_WITH_STRONG_UNION`, delta `0`), and `NON_SCALAR_QUESTION_EVALUATION_VECTORS.json` (`numeric_score: null`).
- `dollhouse/` — Implementation-phase machine-parseable JSON & human Markdown receipts for `/dollhouse-design` (`COMM-EXP-A-LATIFA-IMPL-20261029`, `deliverable_count: 1`) and `/dollhouse-audit` (`dollhouse-audit-1793261123598-266c2684`, preserving observed `TEMPORAL_CUSTODIAN` veto & `ORCHESTRATOR` `HELD_DISSENT`), plus `design_phase/` predecessor receipts.
- `receipts/` — `GIT_STATUS_BEFORE.txt`, `GIT_STATUS_AFTER.txt`, `PREFLIGHT_SELFTEST_RECEIPT.json`, `LIVE_ARM_GATE_REFUSAL_RECEIPT.json`, and `REPO_DOLLHOUSE_AUDIT_TESTS.txt`.
- `PREFLIGHT_CHECKSUMS.sha256` — Complete SHA-256 manifest of every file in this closure packet.

Sealed ⟐
