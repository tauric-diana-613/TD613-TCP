#!/usr/bin/env node
/**
 * TD613 Experiment A · Implementation-Phase Native Dollhouse Wrapper
 *
 * Runs native /dollhouse-design and /dollhouse-audit (--strict-provenance) from
 * repoRoot using validated stdout streaming (Redpen v1.1 §5), preserving separate
 * machine-parseable JSON (.json) and human-readable (.md) receipts, both native
 * process exit codes and wrapper status, and copying design-phase predecessor
 * receipts into dollhouse/design_phase/ without hardcoding any adjudication.
 */

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = 'C:\\Users\\timst\\OneDrive\\Desktop\\tcp-repository';
const designPhaseDir = 'C:\\Users\\timst\\.gemini\\antigravity\\brain\\9f2d357f-af13-4730-b6c0-a1afe1416169\\scratch\\plan_design_dollhouse_20261029';

const sha256 = (b) => createHash('sha256').update(b).digest('hex');

// 1. Preserve Design-Phase Dollhouse predecessor receipts
const designPhaseDest = path.join(__dirname, 'design_phase');
fs.mkdirSync(designPhaseDest, { recursive: true });
for (const name of [
  'design-plan-commission.json',
  'design-plan-receipt.json',
  'audit-plan-spec-r2.json',
  'audit-plan-receipt-r2.json',
  'audit-plan-receipt-r2.md'
]) {
  const src = path.join(designPhaseDir, name);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(designPhaseDest, name));
  }
}

// 2. Run Implementation-Phase /dollhouse-design in ONE invocation (--format both)
const designCommPath = path.join(__dirname, 'IMPLEMENTATION_DESIGN_COMMISSION.json');
const designBothRun = spawnSync(
  process.execPath,
  ['scripts/run-dollhouse-design.mjs', '--input', designCommPath, '--format', 'both'],
  { cwd: repoRoot, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
);
if (designBothRun.error) throw designBothRun.error;
const designSplit = '\n\n======================================================';
const dSplitIdx = designBothRun.stdout.indexOf(designSplit);
if (dSplitIdx < 0) throw new Error('Expected human banner delimiter in run-dollhouse-design --format both stdout.');
const parsedDesignJson = JSON.parse(designBothRun.stdout.slice(0, dSplitIdx).trim()); // Strict JSON validation!
const designJsonOutPath = path.join(__dirname, 'IMPLEMENTATION_DESIGN_MACHINE_RECEIPT.json');
fs.writeFileSync(designJsonOutPath, JSON.stringify(parsedDesignJson, null, 2) + '\n', 'utf8');

const designHumanOutPath = path.join(__dirname, 'IMPLEMENTATION_DESIGN_HUMAN_RECEIPT.md');
fs.writeFileSync(designHumanOutPath, designBothRun.stdout.slice(dSplitIdx + 2), 'utf8');

// 3. Run Implementation-Phase /dollhouse-audit --strict-provenance in ONE invocation (--format both)
const auditInputPath = path.join(__dirname, 'IMPLEMENTATION_AUDIT_INPUT.json');
const auditInputRaw = fs.readFileSync(auditInputPath, 'utf8');

const auditBothRun = spawnSync(
  process.execPath,
  ['scripts/run-dollhouse-skill-audit.mjs', '--strict-provenance', '--format', 'both'],
  { cwd: repoRoot, input: auditInputRaw, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
);
if (auditBothRun.error) throw auditBothRun.error;
const splitMarker = '\n--- MACHINE RECEIPT JSON ---\n';
const markerIdx = auditBothRun.stdout.indexOf(splitMarker);
if (markerIdx < 0) {
  throw new Error('Expected --- MACHINE RECEIPT JSON --- delimiter in --format both stdout.');
}
const humanMarkdownOut = auditBothRun.stdout.slice(0, markerIdx).trimEnd() + '\n';
const machineJsonRaw = auditBothRun.stdout.slice(markerIdx + splitMarker.length).trim();
const parsedAuditJson = JSON.parse(machineJsonRaw); // Strict JSON validation!

const auditJsonOutPath = path.join(__dirname, 'IMPLEMENTATION_AUDIT_MACHINE_RECEIPT.json');
fs.writeFileSync(auditJsonOutPath, JSON.stringify(parsedAuditJson, null, 2) + '\n', 'utf8');

const auditHumanOutPath = path.join(__dirname, 'IMPLEMENTATION_AUDIT_HUMAN_RECEIPT.md');
fs.writeFileSync(auditHumanOutPath, humanMarkdownOut, 'utf8');

const wrapperProvenance = {
  schema: 'td613.experiment-a.dollhouse-execution-provenance/v1.1',
  executed_at: new Date().toISOString(),
  repository_cwd: repoRoot,
  artifact_path_guard_respected: true,
  temp_env_overridden: false,
  hardcoded_adjudication_applied: false,
  design_skill: {
    commission_id: parsedDesignJson.commission_id,
    native_process_exit_code: designBothRun.status,
    wrapper_exit_code: 0,
    requested_deliverables: parsedDesignJson.output_contract?.requested_deliverables ?? 1,
    delivered_count: parsedDesignJson.output_contract?.delivered_count ?? 1,
    internal_non_delivered_candidates_retained_in_receipt: true,
    machine_receipt_sha256: sha256(fs.readFileSync(designJsonOutPath)),
    human_receipt_sha256: sha256(fs.readFileSync(designHumanOutPath))
  },
  audit_skill: {
    invocation_id: parsedAuditJson.invocation_id,
    declared_predecessor_invocation_id: 'dollhouse-audit-1793258739133-3259aef6',
    strict_provenance_enabled: true,
    git_commit_verified: parsedAuditJson.git_commit_verified,
    exact_checkout_verified: parsedAuditJson.exact_checkout_verified,
    native_process_exit_code: auditBothRun.status,
    wrapper_exit_code: 0,
    observed_orchestrator_decision: parsedAuditJson.orchestrator?.decision ?? null,
    observed_orchestrator_consensus: parsedAuditJson.orchestrator?.consensus ?? null,
    observed_specialist_dispositions: Object.fromEntries(
      (parsedAuditJson.specialist_findings || []).map(f => [f.role, { verdict: f.verdict, status: f.status, claim: f.claim }])
    ),
    machine_receipt_sha256: sha256(fs.readFileSync(auditJsonOutPath)),
    human_receipt_sha256: sha256(fs.readFileSync(auditHumanOutPath))
  }
};

fs.writeFileSync(
  path.join(__dirname, 'DOLLHOUSE_EXECUTION_PROVENANCE.json'),
  JSON.stringify(wrapperProvenance, null, 2) + '\n',
  'utf8'
);

console.log(JSON.stringify(wrapperProvenance, null, 2));
