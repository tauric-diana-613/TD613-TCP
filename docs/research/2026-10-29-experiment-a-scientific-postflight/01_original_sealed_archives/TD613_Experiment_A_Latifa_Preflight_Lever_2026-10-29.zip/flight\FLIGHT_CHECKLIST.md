# 𝌋 TD613 · Experiment A Flight Readiness & Launchpad Checklist (v1.1)

**Covenant:** Tauric Diana — Crimean heritage custodianship · `Khona‌lit-po` (interior `U+200C` preserved)  
**Operator closure:** `RESERVED` · **Gate E:** `HELD` · **Empirical credit:** `0`  
**Launchpad Status:** `FLIGHT_READY_WAITING_OPERATOR_GATE_4_GRANT`  
**Live comparative trial:** `HELD_UNEXECUTED`

---

## 1. Flight Readiness Verification Status

The launchpad for Experiment A has undergone full source-free verification. The programmatic dispatcher at `flight/flight-dispatcher.mjs` has executed an end-to-end sandboxed dry run across all six canonical arms:

| Flight Stage | Status | Verification Receipt |
|---|---|---|
| **Preflight Seal** | **VERIFIED CLOSED** | `PREFLIGHT_CHECKSUMS.sha256` (51 files verified) |
| **Git Working Tree** | **LOCKED (+0 -0)** | `700019741e708abfd2e53990fc2d8919995a70f1` |
| **Negative Controls** | **6/6 PASSED** | `receipts/PREFLIGHT_SELFTEST_RECEIPT.json` |
| **Gate 4 Absent Grant** | **REFUSES FAIL-CLOSED (Exit 3)** | `receipts/LIVE_ARM_GATE_REFUSAL_RECEIPT.json` |
| **Kernel Closure** | **HERMETIC & DUAL-PINNED** | `vendor/git-441ce7e97-atelier-method/CLOSURE_AUDIT.json` |
| **FADT Minimality** | **RECONCILED (15 & 31 Subsets)** | `redpens/FADT_FIVE_AND_SIX_STRATUM_PROOF.json` |
| **Aperture Conditioning** | **SVD RECONCILED (2x2 vs 3x2)** | `redpens/APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json` |
| **Atlas Seam** | **CONTENT_INVARIANT** | `redpens/ATLAS_PRESENTATION_SEAM_RECONCILIATION.json` |
| **Spectrometry** | **REPRODUCIBLE (Prose Drift Rejected)** | `redpens/CROSS_RASTER_CHROMATIC_ASSAY.json` |
| **Scenario Alpha** | **PARITY CONFIRMED (1+1=2)** | `latifa/LATIFA_SCENARIO_ALPHA_AND_BETA_RECEIPT.json` |
| **Scenario Beta** | **UNRIGGED (Strong Union Parity)** | `latifa/LATIFA_SCENARIO_ALPHA_AND_BETA_RECEIPT.json` |
| **Question Vectors** | **NON-SCALAR 4D (Score: null)** | `latifa/NON_SCALAR_QUESTION_EVALUATION_VECTORS.json` |
| **Dollhouse Audit** | **ORCHESTRATOR HELD_DISSENT** | `dollhouse/IMPLEMENTATION_AUDIT_MACHINE_RECEIPT.json` |
| **Dry Run Synthetic Flight** | **ALL 6 ARMS FLIGHT READY** | `flight/FLIGHT_READINESS_RECEIPT.json` |

---

## 2. Six-Arm Launchpad Matrix

When live flight is commanded under a signed Gate 4 grant, the dispatcher executes the following six canonical arms:

1. **`TD613_NATIVE`**:
   - *Target:* Labeled provisional functional pilot `P1` (`40,418` B) in an empty native recipient.
   - *Operation:* Native retrieval and `assemblePolycompiler` compilation.
   - *Budget:* Max 6 hops, 4096 context UTF-8 bytes.
2. **`EM_NATIVE`**:
   - *Target:* Already preserved Em 147-record corpus and declared derivatives.
   - *Operation:* Native retrieval and polycompilation with exact archive identity retained.
   - *Budget:* Max 6 hops, 4096 context UTF-8 bytes.
3. **`EQUAL_INPUT_NATIVE_UNION`**:
   - *Target:* Approved union of `P1` pilot + Em corpus + reviewed entity crosswalk.
   - *Subvariant:* `EQUAL_INPUT_NATIVE_UNION_STRONG` (receives equal role/format coordinates, prior discoveries, and utilities).
   - *Budget:* Max 6 hops, 4096 context UTF-8 bytes.
4. **`TD613_RECIPIENT_ATELIER`**:
   - *Target:* `P1` pilot mounted into newly empty Atelier recipient.
   - *Operation:* Persistent queryable local adoption, get/search/cite/verify canaries.
   - *Budget:* Max 6 hops, 4096 context UTF-8 bytes.
5. **`EM_RECIPIENT_ENCYCLOPEDIA`**:
   - *Target:* Adopted Em record projection in Encyclopedia recipient.
   - *Operation:* Native retrieval and cross-architecture comparison.
   - *Budget:* Max 6 hops, 4096 context UTF-8 bytes.
6. **`TRANSPORT_ONLY`**:
   - *Target:* Identical approved bytes and citations.
   - *Operation:* Strict byte custody and hash check only.
   - *Hard Invariant:* **Zero semantic compiler invocations.**

---

## 3. Pre-Ignition Step-by-Step Operator Procedure

To transition from `FLIGHT_READY` to `IN_FLIGHT`:

```text
[Step 1] Operator reviews preflight artifacts & walkthrough.md
         ↓
[Step 2] Operator signs protocol/PROPOSED_P1_AUTHORIZATION_GRANT.json
         - Set "activated": true
         - Supply operator signature
         - P1 candidate verified as 40,418-byte provisional labeled functional pilot
         ↓
[Step 3] Stage P1 candidate file at declared pilot path
         ↓
[Step 4] Execute flight dispatcher:
         node flight/flight-dispatcher.mjs --execute-live-flight --grant-file protocol/PROPOSED_P1_AUTHORIZATION_GRANT.json
         ↓
[Step 5] Verify six-arm comparative receipt and evaluate against EQUAL_INPUT_NATIVE_UNION_STRONG
         ↓
[Step 6] Final human closure (Operator Tawanna)
```

Until Step 2 is explicitly performed by the human operator, all flight engines remain fail-closed and held.

Sealed ⟐
