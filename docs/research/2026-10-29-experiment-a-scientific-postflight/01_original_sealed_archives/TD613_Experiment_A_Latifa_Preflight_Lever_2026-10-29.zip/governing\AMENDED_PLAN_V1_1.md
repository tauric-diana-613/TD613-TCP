# 𝌋 Experiment A · Latifa / Wild Field Preflight Plan v1.1 (Amended per Redpen v1.1)

**Covenant**: Tauric Diana — Crimean heritage custodianship · `Khona‌lit-po` (interior `U+200C` preserved)  
**Preserved Predecessor Plan (v1.0)**: [experiment_a_latifa_preflight_plan.md](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/experiment_a_latifa_preflight_plan.md) (SHA-256 `f8f4c697c77b1c48ff17d4d0bd2fe21bf0d372784923c34783fde1ec99298366`, preserved intact)  
**Binding Redpen Incorporated**: [LATIFA_PREFLIGHT_PLAN_REDPEN_V1_1.md](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/exp_a_preflight_lever_20261029/governing/LATIFA_PREFLIGHT_PLAN_REDPEN_V1_1.md)  
**Repository Baseline**: `700019741e708abfd2e53990fc2d8919995a70f1` (`main`, clean `+0 -0`)  
**Unmerged Method Lineage**: `441ce7e974a76685a212552c1da610ea30fd1efc` (`origin/research/atelier-universal-v02-seed-20261025`, hermetically audited 10-file `ATELIER_METHOD` closure)  
**Posture**: `PREFLIGHT_PLAN_CONDITIONALLY_ACCEPTED · SOURCE_FREE_IMPLEMENTATION_GO · EXPERIMENT_A_REAL_SOURCE_GATE_HELD · GATE_E_HELD · EMPIRICAL_CREDIT_0 · OPERATOR_CLOSURE_RESERVED`

---

## 1. Resolved Gate 0–6 Authority Matrix (Operator + Amari Override Law Applied)

Per Operator Tawanna's contemporaneous directive (*deferring Gates 1–6 to Amari where Amari restricts or overrides*), the active execution boundaries are locked as follows:

| Gate | Resolved Disposition | Governing Effect in Present Implementation |
|---|---|---|
| **Gate 0** | **AUTHORIZED NOW (`SOURCE_FREE_IMPLEMENTATION_GO`)** | Construct and verify the private, source-free Experiment A preflight lever, negative controls, redpens, and implementation Dollhouses. Zero repo mutation; zero `P1` read. |
| **Gate 1** | **ADOPT `R2` AS PREFERRED PRIVATE LOCAL EM REFERENCE** | `R2` (`a1009bf56d17c663aea8d3df75228bb9c0ee90b4081a31b0fe19c70101b36996`) adopted locally; Em aesthetic acceptance and scientific promotion remain reserved. |
| **Gate 2** | **KEEP `Archive.zip` OPAQUE *(Amari Override Active)*** | **No** central-directory listing, extraction, or inner-byte disclosure of `emsrc_db43deb1f616beed44e042c4` (`Archive.zip`); use only already-admitted outer record attributes. Any deeper container inspection is recorded strictly as a *hypothetical permitted operation requiring a future scope-specific grant*. |
| **Gate 3** | **DUAL-IDENTITY SOURCE-FREE PREFLIGHT AUTHORIZED** | Execute source-free preflight against `main` (`7000197...`) engines and audited unmerged Git candidate `441ce7e97...` (`70b1ac1d...`, **not** `main`). Explicitly record non-equivalence to Work snapshot (`ee762380...`); missing Work-snapshot parity remains `HELD` and blocks dependent live scientific claims while permitting safe fixture tests. |
| **Gate 4** | **HELD / NOT YET AUTHORIZED *(Amari Override Active)*** | Zero `P1` read, materialization, or adoption. `live-arm-gate` tests the absent-grant path and must exit nonzero (`HOLD_P1_CAPTURE_GRANT_REQUIRED`) with `new_td613_source_reads = 0` and zero contact with `P1`. |
| **Gate 5** | **HELD / NOT YET AUTHORIZED *(Amari Override Active)*** | Matched 6-arm execution remains unexecuted pending Gate 4, matched baselines, exact permissions, and prospective freeze. `RECIPROCAL_HYBRID_CANDIDATE` stays separate. |
| **Gate 6** | **STANDING HOLDS CONFIRMED** | Gate E `HELD`, empirical credit `0`, Experiments B & C `UNSTARTED`, zero participant contact, zero Git push/merge, zero #405 deployment. |

---

## 2. Binding v1.1 Scientific & Architectural Amendments

### A. Experiment A, B, and C Completion & Dependency Law
- **Experiment A** compares the unchanged canonical 6 arms (`TD613_NATIVE`, `EM_NATIVE`, `EQUAL_INPUT_NATIVE_UNION`, `TD613_RECIPIENT_ATELIER`, `EM_RECIPIENT_ENCYCLOPEDIA`, `TRANSPORT_ONLY`—which never runs a semantic compiler) at equal spans, warrants, utility allowances, budgets, and reviewed crosswalks. Valid outcomes include `SUPPORTED_GAIN`, `SUPPORTED_PARITY_OR_NEGATIVE`, or `HELD_INDETERMINATE`; none automatically establishes independent emergence or creates a third Manifest.
- **Experiment B** (~20-file heterogeneous Em perturbation corpus) depends sequentially on Experiment A delivering a **valid, functioning, characterized baseline receiver and source/warrant continuity**—it does **not** logically require Experiment A to have positively demonstrated emergence. A rigorous **null result** in A with a valid receiver still permits B under a separate future authorization; a broken receiver/continuity hold in A blocks B until repaired and approved.
- **Experiment C** (separately consented human–AI encounter with Atilla and Ozy) remains completely separate and unstarted.

### B. Unrigged Scenario Beta (`EQUAL_INPUT_NATIVE_UNION_STRONG`)
- **Removed** `Scenario Beta demonstrates survival` as a guaranteed conclusion.
- **Flat 3-coordinate classifier** runs strictly as `DIAGNOSTIC_WEAK_FLAT_COMPARATOR` (diagnostic sanity check only).
- Added **`EQUAL_INPUT_NATIVE_UNION_STRONG`** *inside* the `EQUAL_INPUT_NATIVE_UNION` baseline arm (**not** as a 7th canonical arm), receiving the **exact same** records, outer metadata, candidate role/format coordinates, prior discoveries, reviewed crosswalk, eligible scientific utilities, counterbalanced presentation/order (`FORWARD` and `REVERSED`), `Archive.zip` opaque permissions, and compute/inference budgets as the `FADT_ATLAS_APERTURE` route.
- Added an explicit non-Dollhouse rival method (**`RIVAL_ENTROPIC_ABSTAINING_CLASSIFIER`**) within the baseline suite that is **permitted to propose missing coordinates and abstain**.
- Evaluates both the **147-record Em inventory** (explicitly classified as **post hoc development fixture**, not an independent prediction) and **matched held-out synthetic perturbation fixtures** under counterbalanced execution order, predeclaring four lawful outcomes: `SUPPORTED_ARCHITECTURAL_ADVANTAGE`, `PARITY_WITH_STRONG_UNION`, `FAILURE_INFERIOR_TO_STRONG_UNION`, and `HELD_POST_HOC_OR_INDETERMINATE`.

### C. `P1` Citation Record vs. Manuscript Identity Precision
- `81e4bc25cac1975c10a1347c1c3104c696cdb5f8f22023f1f2af9f25fdde7bf2` is pinned strictly as the SHA-256 of the **retained `SRC-P1` citation-record bytes** (`app/encyclopedia/reference/records/SRC-P1.json`, Git blob `fbcc01e666d5257ba9d6599cff3c6ba91455230f` at `7000197...`), **not** original manuscript bytes and **not** a Git commit SHA.
- `P1` (`40,418`-byte Library candidate `file_00000000e76c82308a97947d900f8752` / `libfile_267d1282fc6481918a07c2119b9c1f2a`, provisional functional pilot only under future grant; historical equivalence `HELD_UNVERIFIED`), `P2` (`23,586` B unselected fallback), and `P1C` (`41,126` B consumed distinct object) remain strictly distinct.

### D. FADT, Aperture, Atlas, Spectrometry & `LH-02` Precision
- **FADT**: Exact provenance for all `33` AppleDouble `._` sidecars, `7` unextracted PDFs, and `1` opaque `Archive.zip` (outer record attributes only per Gate 2); 15-subset (5-stratum) and 31-subset (6-stratum) proofs scoped strictly to the *declared feature vocabulary* alongside the required **6-class single categorical variable negative control**; magic header / filename presence never treated as proof of full extractability or authorial meaning.
- **Aperture**: Reconciled $2\times 2$ (`1.276420`, `0.548409`, $\kappa = 2.327497$) and $3\times 2$ (`1.631166`, `0.619917`, $\kappa = 2.631266$) operators + near-collinear ($\kappa = 3998.270413$) and temporally distinguishable ($\kappa = 6.777495$) countermodels; theoretical sensors strictly labeled `HYPOTHETICAL`.
- **Atlas**: `R1` $\to$ `R2` classified as `CONTENT_INVARIANT_PRESENTATION_TRANSFORMATION`; gauge equivalence is analogy only; hash checks vs. browser observation kept separate.
- **Spectrometry**: Predeclares exact JPEG/WebP SHA-256s, coordinate transforms, sRGB/ICC assumptions, registration, and metrics *before* measuring; rejects any color-drift claim that fails the reproducible assay without delaying the `P1`-source-free gate.
- **`LH-02` & Question Evaluation**: Dates `LH-02` honestly as post-hoc Em metadata discovery (`2026-10-29`); locks prospective schema only for unseen future `P1` / `B` episodes; evaluates questions via a non-scalar 4-component structural vector (`numeric_score: null`).

### E. Execution & Dollhouse Receipt Hygiene
- Captures machine-parseable JSON (`JSON.parse`-verified) into `.json` receipts and human markdown into `.md` receipts separately; records both CLI/wrapper and native process exit codes without hardcoding `PASS` or predetermining `HELD` independently of observed adjudication.
