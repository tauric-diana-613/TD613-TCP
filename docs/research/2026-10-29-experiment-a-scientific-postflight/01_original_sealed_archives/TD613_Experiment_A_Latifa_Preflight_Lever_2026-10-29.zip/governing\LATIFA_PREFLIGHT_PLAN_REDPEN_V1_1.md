# 𝌋 TD613 · Experiment A — Latifa Preflight Plan Redpen v1.1

**Status:** Original `experiment_a_latifa_preflight_plan.md` is accepted as a *design proposal with binding amendments*. **Implementation has not yet occurred.** Neither the P1 reverse-source grant nor the actual comparative six-arm experiment is activated by this document. Preserve original plan and this redpen separately.

**Covenant:** Tauric Diana · Khona‌lit-po · Operator closure RESERVED · Gate E HELD · Empirical credit 0.

## 1. Scientific target and completion criteria

The evolved **Experiment A** is a reciprocal encounter between independently empty receiving instruments and independently authored source corpora: Em Atelier research → Encyclopedia-derived receiver (transfer/retrieval already accepted), and TD613 Encyclopedia research → empty Atelier (P1 source-specific grant pending). Following lawful source acquisition, compare the **unchanged canonical six arms** with equal source spans, warrants, utility allowances, budgets and reviewed crosswalks: `TD613_NATIVE`, `EM_NATIVE`, `EQUAL_INPUT_NATIVE_UNION`, `TD613_RECIPIENT_ATELIER`, `EM_RECIPIENT_ENCYCLOPEDIA`, `TRANSPORT_ONLY`. The last arm never runs a semantic compiler. Keep `RECIPROCAL_HYBRID_CANDIDATE` as a separate exploratory seventh proposal. Completion of an experiment may yield supported gain, supported parity/negative finding, or appropriately HELD indeterminacy; none automatically demonstrates independent emergence or creates a third Manifest.

**Experiment B** is the separate approximately 20-file heterogeneous Em perturbation study, which challenges an established receiver's capacity for source-aware revision, contradiction detection, novel research-question formation, abstention and changed operations. B is sequentially dependent on A delivering an acceptably characterized and functioning baseline; B does **not** logically require A to have positively demonstrated emergence. If A fails to establish a valid receiver or source/warrant continuity, B cannot proceed *under its intended design* until repair/recharacterization and operator approval. If A produces a rigorous null result with a valid receiver, B may still test whether new perturbations alter the outcome under a separately authorized protocol. Experiment C is a separately consented human–AI research encounter involving Atilla and Ozy. No B/C admission, participant contact or frontispiece production here.

## 2. Binding correction: no rigged Scenario Beta

Retain Scenario Alpha as a parity/negative control. For **Scenario Beta**, the flat classifier may run only as a deliberately weak **diagnostic comparator**. Add a separate, strong `EQUAL_INPUT_NATIVE_UNION_STRONG` within the baseline arm, **not as a seventh canonical arm**. It must receive the same records, metadata, candidate role/format coordinates, prior discoveries, reviewed crosswalk, eligible scientific utilities, sequence/order opportunities, source permissions and compute/inference budgets as the FADT–Atlas–Aperture route. Include at least one rival method permitted to propose a missing coordinate and abstain. Counterbalanced presentation/order and matched held-out inputs should be used where feasible. Predeclare success, parity, failure and HELD outcomes; remove `Scenario Beta demonstrates survival` as a guaranteed conclusion. The already-inspected 147-record Em inventory is a **development fixture** (post hoc), not an independent future prediction. Never credit a capability difference caused solely by withholding a permitted operation from the strong baseline.

## 3. Frozen protocol, kernel identity and source identity

Read `BASELINE_PROTOCOL.json` **byte-identically**. Its canonical arms and six condition strings are binding. Budgets per arm from the supplied protocol: `conditions=6`, `candidate_relations=1`, `rival_interpretations=1`, `max_hops=6`, `context_passages_per_source=2`, `max_utf8_bytes_per_passage=2048`, `max_utf8_context_bytes_per_source=4096`, plus exactly matched reviewed spans; declare any exploratory deviation separately. Audit the source modules and transitive dependency closure at Git candidate `441ce7e974a76685a212552c1da610ea30fd1efc` before running source-free tests. The Work snapshot `atelier-semantic-polycompiler-v02.mjs` SHA `ee7623803552c26ba41554ed0d2b2e3fe89859f172d3209b38bf249ea1c6f9cc` and Git candidate module SHA beginning `70b1ac1d` are **not** byte-equivalent. Label tests by the actual module and verify equivalence only through independent executable parity tests; unexecuted Work equivalence remains HELD. A repository candidate at `441ce7…` is unmerged research, not `main`.

For P1, the `81e4bc25cac1975c10a1347c1c3104c696cdb5f8f22023f1f2af9f25fdde7bf2` hash belongs to the **retained SRC-P1 citation-record bytes**, not authenticated original-manuscript bytes or a demonstrated Git commit containing historical P1. The possible 40,418-byte Library file may be used only under a specific future authorization as a labeled **provisional functional pilot** until upstream historical equivalence is independently established. Do not substitute the distinct 41,126-byte P1C. P1, P2 and P1C source identities remain separate.

## 4. Wild Field redpen scope

FADT: supply exact source-role provenance for the 33 AppleDouble `._` sidecars, 7 unextracted PDFs and 1 ZIP container. Describe the 5/6-stratum recovery as necessary/minimal **within the declared feature vocabulary**, not globally minimal over all possible encodings. The 6-class categorical counterexample is a required negative control. Preserve support assumptions: the existence of a filename or magic header does not prove full extractability or authorial meaning.

Aperture: preserve correct, separately identified 2×2 and 3×2 operators, singular values and conditioning; include near-collinear and temporally distinguishable counterexamples. Label theoretical independent observations as **hypothetical** until externally witnessed.

Atlas: classify the R1→R2 relation as `CONTENT_INVARIANT_PRESENTATION_TRANSFORMATION`. Treat gauge equivalence as analogy only. Source hash verification and readable/browser observation are separate evidence types.

Raster: declare exact JPEG/WebP SHA-256 inputs, coordinate transforms, ICC/color assumptions, crop/registration procedure and metrics before measuring. A color-drift claim failing the reproducible assay must be rejected without delaying the independent P1-source-free gate.

LH-02 is **discovered on the already inspected Em metadata**. Date its development honestly. A future P1 or B held-out test may be prospectively locked only before that unseen evidence enters the research episode; preregistration does not erase the Em development history. Formalize a non-scalar question-evaluation vector and record competitors and falsifiers, without numeric scoring of humans or questions.

## 5. Preflight verification: distinguish executable from proposed

The current plan has undergone **design-phase** Dollhouse executions. The `source-free-selftest`, `live-arm-gate`, redpen scripts, Latifa scenarios, full implementation-phase Dollhouses and sealed lever packet are **planned, not yet executed**. Test the `live-arm-gate` no-grant path as an intentionally expected nonzero refusal `HOLD_P1_CAPTURE_GRANT_REQUIRED`. It must prove `new_td613_source_reads=0`, no source admission and no mutable receiver transition. It must not contact P1 to prove it refused P1.

Use a documented non-repository artifact location. For Dollhouse receipts, capture native JSON with an actual machine-parseable output format; don't write `--format human` into a `.json` extension and call it a machine receipt. If a CLI requires repo-local output, use validated stdout streaming or an explicitly allowed private external destination rather than bypassing the artifact path guard. Preserve both CLI/wrapper and native process exit codes, plus Orchestrator dissent. Don't hardcode a PASS or demand predetermined HELD status independently of its actual observed adjudication. Capture `git status` before and after and verify module/dataset SHA-256 closure. The operator receives one coherent preflight packet with internal design variants non-delivered, plus its internal evidence/receipts.

**Preflight pass criteria:** actual source-free lever program exists, exact canonical arm identities match frozen JSON, all six negative/warrant controls execute with expected results, strong baseline fairness is documented, source kernel identity gap explicitly handled, P1 absent-grant refusal behaves as required, candidate/source footprints remain unchanged, scientific role dissent survives, and an independently reproducible closure packet is produced. A passing preflight authorizes *consideration* of the one-time P1 grant, not automatic grant consumption or automatic full comparative run.

## 6. Single-batch Gate 0–6 recommendation

- **Gate 0: AUTHORIZE NOW**, subject to this redpen, for private, source-free construction, executable negative controls and implementation Dollhouses. No repository mutation and no P1 read.
- **Gate 1: ADOPT R2 AS PREFERRED PRIVATE LOCAL EM REFERENCE** at SHA `a1009bf56d17c663aea8d3df75228bb9c0ee90b4081a31b0fe19c70101b36996`. Em aesthetic approval and scientific promotion remain reserved.
- **Gate 2: KEEP `Archive.zip` OPAQUE**. No central directory listing, extraction or metadata disclosure beyond already admitted outer record attributes. If the structural proof needs more, record it as a hypothetical permitted inspection requiring a later scope-specific grant.
- **Gate 3: AUTHORIZE DUAL-IDENTITY SOURCE-FREE PREFLIGHT** with `main` engine closure and the separately verified, unmerged Git candidate utility; **do not** assert the Git utility is byte-equivalent to the Work snapshot. Missing parity blocks dependent live scientific claims, not safe exploratory fixture tests.
- **Gate 4: HELD / NOT YET AUTHORIZED** pending observed preflight packet and explicit source-specific P1 grant. A later operator may elect a 40,418-byte provisional labeled pilot without claiming historical equivalence.
- **Gate 5: HELD / NOT YET AUTHORIZED** pending Gate 4, matched baselines, exact source permissions and prospective test freeze. Proposed seventh hybrid is separate.
- **Gate 6: CONFIRM STANDING HOLDS**: Gate E HELD, empirical credit zero, Experiments B/C unstarted, no participant contact, no public/private Git push, merge or #405 deployment.

The operator may state all seven positions **in one contemporaneous message**. That fully authorizes present bounded Gate 0–3 work; it expressly does not delegate future Gate 4/5 actions without their separate source-specific prerequisites and authority.

## Stop state

At completion or an evidenced blocker: stop at `𝄐` with one closure packet, exact checksums, negative controls, scientific dissent, candidate hypotheses and proposed-but-unexecuted P1 grant. No new source acquisitions, releases, deployments, third Manifest claims, or automatic operator closure.

𝌋 **PREFLIGHT_PLAN_CONDITIONALLY_ACCEPTED · SOURCE_FREE_IMPLEMENTATION_GO · EXPERIMENT_A_REAL_SOURCE_GATE_HELD · OPERATOR_CLOSURE_RESERVED** · Sealed ⟐
