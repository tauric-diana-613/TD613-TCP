# 𝌋 Experiment A · Latifa / Wild Field Preflight Lever & Redpen Implementation Plan

**Covenant**: Tauric Diana — Crimean heritage custodianship · `Khona‌lit-po` (interior `U+200C` preserved)  
**Repository Baseline**: [`700019741e708abfd2e53990fc2d8919995a70f1`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/AGENTS.md) (`main`, clean `+0 -0`)  
**Handoff Baseline**: `f683956425178ef89342a44ef50c684a748e7b41` (`handoff/em-manifest-rendered-review-20261029`)  
**Unmerged Method Lineage**: `441ce7e974a76685a212552c1da610ea30fd1efc` (`origin/research/atelier-universal-v02-seed-20261025`)  
**Posture**: `WILD_FIELD_ACTIVE · SOURCE_FREE_PREFLIGHT_AUTHORIZED · REVERSE_GRANT_UNEXECUTED · GATE_E_HELD · EMPIRICAL_CREDIT_0 · OPERATOR_CLOSURE_RESERVED`

---

## Goal Description

Construct and verify the **read-only, source-free Experiment A preflight lever** ("Magic Lever") and **Latifa Wild Field adversarial suite** in a private nonpublic workspace without mutating `main` (`7000197`) or consuming the held `P1` reverse-source grant (`40,418` bytes).

Specifically, this plan:
1. Closes the **Em rendered-review engineering lane** cleanly at its demonstrated browser/byte ceiling (`R2` `a1009bf56d17c663aea8d3df75228bb9c0ee90b4081a31b0fe19c70101b36996`), correcting retrospective prose drift (`#24282A`-on-`#24282A` graphite select controls repaired to `#24282A`-on-`#F6F4F0` porcelain within Em's `#FF91AF` Baker–Miller pink reading architecture).
2. Incorporates **all five scientific redpens** (FADT 5-stratum & 6-stratum container split with scope-qualified minimality; Aperture $2\times 2$ vs. $3\times 2$ SVD reconciliation + adversarial dynamical models; Atlas content-invariant presentation transformation vs. strict gauge analogy; executable cross-raster chromatic spectrometry; exact 147-record preservation vs. substantive source accounting).
3. Builds a **runnable, non-consuming Experiment A preflight harness** preserving the canonical 6-arm protocol ([`BASELINE_PROTOCOL.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/em_closure_20261029/candidate/reverse-leg/BASELINE_PROTOCOL.json)) unchanged, enforcing budget parity, all 6 negative/warrant controls, prior-art uncertainty, and fail-closed `P1` abstention.
4. Executes the **Latifa Challenge**:
   - **Scenario Alpha**: Demonstrates an apparent cross-corpus capability gain collapsing to parity under `EQUAL_INPUT_NATIVE_UNION` (`1 + 1 = 2`, portability without architectural emergence).
   - **Scenario Beta**: Demonstrates a genuinely distinct cross-instrument operation surviving `EQUAL_INPUT_NATIVE_UNION`—specifically answering Amari's Section VI question on **representation-insufficiency detection, minimal missing-coordinate questioning, and lawful abstention** across Em's 147-record heterogeneous inventory.
   - **Non-Scalar Question Evaluation**: Formalizes a 4-coordinate structural adjudication lattice $\mathcal{Q}(q)$ so novel research questions are evaluated as experimental outcomes without reducing scientific judgment to a scalar score.
5. Couples native [`/dollhouse-design`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/.agents/skills/dollhouse-design/SKILL.md) and [`/dollhouse-audit`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/.agents/skills/dollhouse-audit/SKILL.md) across **both plan design (completed below) and plan implementation**, achieving `git_commit_verified: true` and `exact_checkout_verified: true` at `700019741e708abfd2e53990fc2d8919995a70f1` while preserving scientific `HELD_DISSENT`.
6. Delivers the exact, unactivated **`TD613-P1-LIBRARY-CAPTURE-AND-LOCAL-ADOPTION-01`** specification and stops cleanly at `𝄐`.

---

## Design-Phase Dollhouse Coupling (Executed Prior to Plan Submission)

Per operator directive, both repository-native Dollhouses were executed at exact committed `main` (`700019741e708abfd2e53990fc2d8919995a70f1`) into `scratch/plan_design_dollhouse_20261029/` to shape and stress-test this plan before authoring:

1. **Design-Phase `/dollhouse-design`** ([`design-plan-receipt.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/plan_design_dollhouse_20261029/design-plan-receipt.json), ID `COMM-EXP-A-LATIFA-PLAN-20261029`):
   - **Selected Instruments**: `DIALECTICAL_TENSION` (scaffold) + `CARO_INSTITUTIONAL_RECONSTRUCTION` (counterlayer), full-source ingesting `AGENTS.md`, `DOLLHOUSE.md`, `FADT.md`, `APERTURE.md`, `ATLAS.md`, and `PEDAGOGUE.md` at `700019741e708abfd2e53990fc2d8919995a70f1`.
   - **Deliverable Contract**: `requested_deliverables: 1` (Candidate A *The Archive Apparatus*, Candidate B *The Applicant's Corridor*, and the `polyphonic_hierarchy` refraction remain internal scaffolding; outward delivery is **one** unified Experiment A Preflight Lever package).
2. **Design-Phase `/dollhouse-audit`** ([`audit-plan-receipt-r2.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/plan_design_dollhouse_20261029/audit-plan-receipt-r2.json), ID `dollhouse-audit-1793258739133-3259aef6`, citing predecessor `dollhouse-audit-1793258688884-1ebd5271`):
   - **Provenance**: `git_commit_verified: true`, `exact_checkout_verified: true` at `700019741e708abfd2e53990fc2d8919995a70f1` (resolving Amari's `WORKING_TREE_UNCOMMITTED` qualification from the prior round, which occurred because the previous runner invoked `git rev-parse` from outside the Git working directory).
   - **Disposition**: `PEDAGOGUE` (`SUPPORTED`), `APERTURE` (`SUPPORTED`), `ATLAS` (`SUPPORTED`), `FADT` (`SUPPORTED`), `TEMPORAL_CUSTODIAN` (`HELD` on unexecuted `PHASE_3_P1_SOURCE_GRANT_AND_CAPTURE` and `PHASE_4_MATCHED_SIX_ARM_COMPARISON`), `ORCHESTRATOR` (`HELD` / `HELD_DISSENT`, `exit_code: 1`, `empirical_replication_count: 0`).
   - **Design Discovery**: Running `--output` directly into `scratch/` outside `repoRoot` triggers `HOLD_ARTIFACT_DESTINATION_NOT_AUTHORIZED`; implementation will therefore invoke [`run-dollhouse-skill-audit.mjs`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/scripts/run-dollhouse-skill-audit.mjs) from `repoRoot` with `--strict-provenance --format json` and capture exact stdout receipts cleanly without mutating `repoRoot`.
3. **Design-Phase Mathematical Calibration** ([`design-math-check.mjs`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/plan_design_dollhouse_20261029/design-math-check.mjs)):
   - Verified `33/33` `._*` files carry exact AppleDouble magic bytes `0x00051607`.
   - Verified FADT 6-stratum split (`7` unextracted PDFs vs. `1` `Archive.zip` container) produces a non-zero operational gap of cardinality `2` (`["CONTAINER_CENTRAL_DIRECTORY_AUDIT_REQUIRING_SCOPE_GRANT", "PDF_DOCUMENT_EXTRACTION_CANDIDATE"]`) across `31` non-empty coordinate subsets.
   - Verified exact SVD reconciliation: displayed $2\times 2$ matrix ($\sigma_1 = 1.276420, \sigma_2 = 0.548409, \kappa = 2.327497$) vs. $3\times 2$ augmented matrix ($\sigma_1 = 1.631166, \sigma_2 = 0.619917, \kappa = 2.631266$), plus two adversarial countermodels ($\kappa = 3998.270413$ near-collinear trap and $\kappa = 6.777495$ rank-2 time-separated scalar EMA).

---

## User Review Required — Sovereign Operator Authorization Gates

> [!IMPORTANT]
> **Explicit Operator Gate Decisions Requested.**  
> Below are the seven bounded custody and execution gates governing this plan and its downstream horizon. Implementing the current commission **requires Gate 0** (and benefits from your decisions on **Gates 1, 2, and 3**). **Gates 4, 5, and 6** govern post-preflight stages; per Amari's stop law, Phase 1 implementation will **stop at `𝄐` after constructing and self-testing the source-free lever** unless you explicitly direct otherwise.

```mermaid
flowchart TD
    G0["Gate 0: Approve Source-Free Preflight Plan"] --> G1["Gate 1: Adopt Em R2 (a1009bf5) Local Baseline?"]
    G0 --> G2["Gate 2: Keep Archive.zip Opaque vs. Header-Only Listing?"]
    G0 --> G3["Gate 3: Bind Git 441ce7e97 ATELIER_METHOD + Flag Work ee762380 Gap?"]
    G1 & G2 & G3 --> IMPL["Execute Source-Free Lever + 5 Redpens + Both Dollhouses"]
    IMPL --> STOP["Mandatory Stop at 𝄐 (Deliver Lever + Register + P1 Grant Spec)"]
    STOP -. "Separate Explicit Operator Grant Required" .-> G4["Gate 4: P1 One-Time Capture & Local Adoption (40,418 B)"]
    G4 -. "Only After Gate 4 + Locked Controls" .-> G5["Gate 5: Execute Matched 6-Arm Comparison (+ Optional 7th Arm?)"]
    STOP -. "Remains Strictly HELD / CLOSED" .-> G6["Gate 6: Gate E, Exp B, Exp C, Merge/Deploy = HELD/CLOSED"]
```

| Gate ID | Custody Boundary / Consequence | Recommended Default Posture |
|---|---|---|
| **Gate 0** | **Execute Source-Free Preflight Plan** in private `scratch/exp_a_preflight_lever_20261029/` (zero `main` repo mutations, zero `P1` reads, both native Dollhouses run at `7000197`). | **AUTHORIZE NOW** to build and verify the lever. |
| **Gate 1** | **Em Rendered-Review Engineering Closure & `R2` Adoption**: Designate `R2` (`a1009bf5...`, CSS-only `+1,277` B) as Em's preferred private local presentation baseline (human aesthetic closure reserved; Dollhouse scientific `HELD_DISSENT` preserved). | **AUTHORIZE / ADOPT `R2`** as preferred private local candidate. |
| **Gate 2** | **`Archive.zip` (`emsrc_db43deb1f616beed44e042c4`) Inspection Scope**: Keep `Archive.zip` strictly **opaque/uninspected** (`CONTAINER_OPAQUE_HELD`, testing the 6-stratum FADT split purely via external record metadata/magic header), OR authorize read-only ZIP central-directory listing (filenames/sizes/CRCs only, zero extraction/admission). | **KEEP OPAQUE (`HELD`)** during preflight unless you specifically want central-directory header listing. |
| **Gate 3** | **Atelier Kernel Byte-Identity Parity**: Forensic audit found [`BASELINE_PROTOCOL.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/em_closure_20261029/candidate/reverse-leg/BASELINE_PROTOCOL.json) pins Work's container-local `atelier-semantic-polycompiler-v02.mjs` (`8,984` B, `ee762380...`) and `atelier-diachronic-classification-v01.mjs` (`6,880` B, `7e8a7536...`), whereas fetched Git commit `441ce7e97` (`ATELIER_METHOD`) carries `atelier-semantic-polycompiler-v02.mjs` (`8,724` B, `70b1ac1d...`). Bind preflight harness to verified local `7000197` + `441ce7e97` modules while enforcing a fail-closed pre-arm hash check if `ee762380...` is absent? | **AUTHORIZE DUAL-PIN** (execute preflight with `7000197` + `441ce7e97` `ATELIER_METHOD`, record `ee762380...` container-only gap explicitly). |
| **Gate 4** | **`TD613-P1-LIBRARY-CAPTURE-AND-LOCAL-ADOPTION-01`**: One-time read, SHA-256 pinning, max `4,096` B private passage exposure, and reversible local adoption of `eclipse-omega-admissibility-regime.md` (`file_00000000e76c82308a97947d900f8752`, `libfile_267d1282fc6481918a07c2119b9c1f2a`, expected `40,418` B; non-equivalent to `41,126`-byte `P1C`; historical `SRC-P1` equivalence `HELD_UNVERIFIED`). | **KEEP HELD (`UNEXECUTED`)** for Phase 1 so the preflight lever is inspected at `𝄐` before any `P1` read. |
| **Gate 5** | **Matched 6-Arm Comparative Execution (+ Optional 7th Exploratory Hybrid Arm)**: Run the 6 canonical arms (`TD613_NATIVE`, `EM_NATIVE`, `EQUAL_INPUT_NATIVE_UNION`, `TD613_RECIPIENT_ATELIER`, `EM_RECIPIENT_ENCYCLOPEDIA`, `TRANSPORT_ONLY`)—and decide whether the non-displacing 7th arm (`RECIPROCAL_HYBRID_CANDIDATE`) may run alongside—only after Gate 4 and locked preflight controls. | **KEEP HELD (`UNEXECUTED`)** until Gate 4 and preflight lever verification complete. |
| **Gate 6** | **Standing Prohibitions**: Gate E (`HELD`), Experiment B (~20 perturbation files, `UNSTARTED`), Experiment C (Atilla/Ozy encounter, `UNSTARTED`), GitHub push/merge, and Issue #405 deployment. | **KEEP STRICTLY CLOSED / HELD**. |

---

## Proposed Changes

> [!NOTE]
> **Zero Repository Mutation.**  
> All new scripts, manifests, registers, and receipts will be created strictly inside `<Artifact Directory>/scratch/exp_a_preflight_lever_20261029/` (plus a sealed closure ZIP in `<Artifact Directory>/scratch/`). Working tree `c:\Users\timst\OneDrive\Desktop\tcp-repository` remains untouched on `main` at `700019741e708abfd2e53990fc2d8919995a70f1` (`+0 -0`).

### Component 1: Canonical Six-Arm Preflight Lever & Custody Gate

#### [NEW] `preflight-lever.mjs` (`scratch/exp_a_preflight_lever_20261029/harness/preflight-lever.mjs`)
- Loads [`BASELINE_PROTOCOL.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/em_closure_20261029/candidate/reverse-leg/BASELINE_PROTOCOL.json) and [`SOURCE_SELECTION_AND_BASELINE_HASHES.json`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/em_closure_20261029/candidate/reverse-leg/SOURCE_SELECTION_AND_BASELINE_HASHES.json) **byte-identically** (asserting SHA-256 parity before running).
- Enforces the unchanged **6 canonical arms** (`TD613_NATIVE`, `EM_NATIVE`, `EQUAL_INPUT_NATIVE_UNION`, `TD613_RECIPIENT_ATELIER`, `EM_RECIPIENT_ENCYCLOPEDIA`, `TRANSPORT_ONLY`) and exact per-arm budgets (`conditions: 6`, `candidate_relations: 1`, `rival_interpretations: 1`, `max_hops: 6`, `context_passages_per_source: 2`, `max_utf8_bytes_per_passage: 2048`, `max_utf8_context_bytes_per_source: 4096`).
- Implements `--mode source-free-selftest` (runnable now without consuming `P1`) and `--mode live-arm-gate` (refuses execution fail-closed with `HOLD_P1_CAPTURE_GRANT_REQUIRED` unless a valid operator Gate 4 grant manifest and observed `P1` SHA-256 are supplied).
- Executes all **6 negative/warrant controls** over synthetic/Em-authorized dry-run fixtures using `assemblePolycompiler`, `traceTypedCompilations`, `roleAblation`, `inspectContextualAlternatives`, `lockProspectivePlan`, and `discriminateMechanisms` extracted read-only via `git show 441ce7e974a76685a212552c1da610ea30fd1efc:...`:
  1. `REVIEWED_CANDIDATE`
  2. `RIVAL_INTERPRETATION`
  3. `REQUIRED_WITNESS_WITHDRAWN_CALLER_FLAGS_TRUE` (proving caller-supplied `true` flags cannot override a withdrawn witness)
  4. `DIGEST_VALID_IRRELEVANT_SPAN` (proving valid SHA-256 on an unrelated span fails warrant alignment)
  5. `UNREVIEWED_EQUAL_LABEL_JOIN` (proving identical surface terms across corpora cannot auto-join without reviewed crosswalk evidence)
  6. `CONTEXTUAL_UNCERTAINTY_PRESERVED`
- Records exact module provenance: distinguishes `7000197` repo engines, `441ce7e97` Git `ATELIER_METHOD` (`70b1ac1d...`), and Work's unbundled container snapshot (`ee762380...`, `7e8a7536...`).

#### [NEW] `exploratory-extensions.json` & `P1_AUTHORIZATION_SPEC_PROPOSED.json` / `.md` (`scratch/exp_a_preflight_lever_20261029/protocol/`)
- Keeps `RECIPROCAL_HYBRID_CANDIDATE` strictly quarantined in `exploratory-extensions.json` (`displaces_transport_only: false`, `requires_gate_5b: true`).
- Codifies the exact, unactivated `TD613-P1-LIBRARY-CAPTURE-AND-LOCAL-ADOPTION-01` instrument matching [`TD613_Reverse_Leg_Source_Selection_and_Grant_2026-10-28.md`](file:///C:/Users/timst/.gemini/antigravity/brain/9f2d357f-af13-4730-b6c0-a1afe1416169/scratch/em_closure_20261029/candidate/reverse-leg/TD613_Reverse_Leg_Source_Selection_and_Grant_2026-10-28.md), explicitly recording `new_source_reads: 0`.

---

### Component 2: Five-Redpen Mathematical & Forensic Closure Suite

#### [NEW] `run-redpen-reconciliations.mjs` (`scratch/exp_a_preflight_lever_20261029/redpens/run-redpen-reconciliations.mjs`)
1. **FADT Corpus & Coordinate Minimality Receipt (`FADT_FIVE_AND_SIX_STRATUM_PROOF.json`)**:
   - Verifies all `33` AppleDouble files by raw `0x00051607` magic signature, byte length, SHA-256, and 1:1 Markdown basename pairing in `records.ndjson`.
   - Emits the full **15-subset** evaluation table for the 5-stratum model and the full **31-subset** evaluation table for the **6-stratum adversarial split** (`7` unextracted PDFs vs. `1` `Archive.zip` container, proving the `2`-action gap `["CONTAINER_CENTRAL_DIRECTORY_AUDIT_REQUIRING_SCOPE_GRANT", "PDF_DOCUMENT_EXTRACTION_CANDIDATE"]`).
   - Proves the **Representation Counterexample**: constructs a single categorical coordinate $\tau \in \{0,\dots,5\}$ (`1` coordinate, $\lceil \log_2 6 \rceil = 3$ bits) that resolves all 6 strata, formally scoping our 4-coordinate / 5-coordinate necessity claims to the *declared binary/kind feature vocabulary*.
2. **Aperture SVD Reconciliation & Adversarial Dynamics Receipt (`APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json`)**:
   - Reconciles the $2\times 2$ matrix $\begin{bmatrix} 1 & 0.5 \\ 0.2 & 0.8 \end{bmatrix}$ ($\sigma_1 = 1.276420, \sigma_2 = 0.548409, \kappa = 2.327497$) vs. the $3\times 2$ augmented matrix $\begin{bmatrix} 1 & 1 \\ 0.15 & 0.15 \\ 1 & 0 \end{bmatrix}$ ($\sigma_1 = 1.631166, \sigma_2 = 0.619917, \kappa = 2.631266$) via [`aperture-v32-typed-epistemic-deficit.js`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/app/engine/aperture-v32-typed-epistemic-deficit.js).
   - Evaluates **Adversarial Model A** (near-collinear probe $[1, 0.999]$: algebraic rank $2$, $\kappa = 3998.270413$, triggering `NUMERICAL_STABILITY_DEFICIT`) and **Adversarial Model B** (time-separated hazard/spike impulses $t_1 \neq t_2$: scalar EMA channel alone achieves rank $2$ with $\kappa = 6.777495$, bounding the rank-1 theorem to colocated/proportional excitation).
3. **Atlas Presentation Seam Receipt (`ATLAS_PRESENTATION_SEAM_RECONCILIATION.json`)**:
   - Runs [`dollhouse-continuity-audit.js`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/app/engine/dollhouse-continuity-audit.js) and [`dollhouse-atlas-relational-custody.js`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/app/engine/dollhouse-atlas-relational-custody.js) over `Work R1` (`10b48fa9...`) $\to$ `Kenough R2` (`a1009bf5...`), recording exact CSS contrast repair (`#24282A` on `#24282A` `1.00:1` $\to$ `#24282A` on `#F6F4F0` `13.54:1` within `#FF91AF` Baker–Miller pink), classifying the event strictly as `CONTENT_INVARIANT_PRESENTATION_TRANSFORMATION`, and demoting "gauge-like" to non-binding analogy.

#### [NEW] `run-cross-raster-chromatic-assay.mjs` (`scratch/exp_a_preflight_lever_20261029/redpens/run-cross-raster-chromatic-assay.mjs`)
- Decodes exact byte-verified `frontispiece-0.webp` (`941×1672`, `e4a20f9d...`), `frontispiece-1.webp` (`1678×937`, `01d71b79...`), and `PR_1584` JPEG (`1376×768`, `e41e77eb...`) in headless Edge sRGB canvas (with guaranteed `try/finally` process cleanup) to compute an independently reproducible RGB/Lab annular & center-crop chromatic comparison receipt (`CROSS_RASTER_CHROMATIC_ASSAY.json`), explicitly testing and bounding—or refuting—the prior unreceipted `> 0.18` prose hypothesis!

---

### Component 3: Latifa Adversarial Suite & Append-Only Candidate Register

#### [NEW] `run-latifa-adversarial-suite.mjs` & `CANDIDATE_HYPOTHESIS_REGISTER.ndjson` (`scratch/exp_a_preflight_lever_20261029/latifa/`)
- **Append-Only Register**:
  - Registers `CANDIDATE-PROP-WF1-FADT-APERTURE-01` with discovery epoch `2026-10-29` (`DISCOVERED_ON_EM_WILD_FIELD_I_PRE_P1`, `retroactive_preregistration_forbidden: true`), plus prior-art uncertainty citations (`Beer 1972`, `Ashby 1956`, Kalman observability, RFC 1740 AppleDouble).
  - Registers **Latifa Hypothesis LH-02** (*Representation-Insufficiency Detection & Lawful Abstention under Quotient Collapse*) prospectively prior to any Experiment B or `P1` exposure via `lockProspectivePlan`.
- **Rival Scenario Alpha (`SCENARIO_ALPHA_UNION_COLLAPSE`)**:
  - Executes `assemblePolycompiler` + `traceTypedCompilations` across single-source vs. recipient vs. `EQUAL_INPUT_NATIVE_UNION` on a finite 2-corpus model; proves the apparent cross-corpus jump disappears (`recipient_routes == equal_input_union_routes`) once both inputs and the reviewed crosswalk are supplied natively (`1 + 1 = 2`).
- **Rival Scenario Beta (`SCENARIO_BETA_REPRESENTATION_INSUFFICIENCY_SURVIVAL`)**:
  - Directly tests Amari's Section VI target on the real 147-record Em metadata table: compares a flat `EQUAL_INPUT_NATIVE_UNION` classifier (which remains blind to intra-fiber operational mismatch inside `(source, false, false)`) against the coupled **FADT-Atlas-Aperture Diagnostic Operator** that (i) detects non-zero subfiber operational variance, (ii) emits the minimal missing-coordinate question (`is_packaging_artifact`, `is_archive_container`), (iii) proposes a bounded safe probe (`READ_4BYTE_MAGIC_HEADER`), and (iv) **abstains fail-closed** on `Archive.zip` when container-scope permission is withheld.
- **Non-Scalar Question Evaluation (`evaluateCandidateQuestionStructure`)**:
  - Evaluates candidate research questions via [`pedagogue-research-transfer.js`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/app/engine/pedagogue-research-transfer.js) and [`dollhouse-witness-plan.js`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/app/engine/dollhouse-witness-plan.js) across four qualitative-mathematical coordinates—`FiberSplit`, `ConditioningStability`, `PositiveAndHostileWitnesses`, and `AbstentionBoundary`—returning a structured adjudication vector with `numeric_user_or_question_score: null`.

---

### Component 4: Implementation-Phase Native Dollhouse Executions & Sealed Preflight Bundle

#### [NEW] Implementation-Phase `/dollhouse-design` & `/dollhouse-audit` Receipts (`scratch/exp_a_preflight_lever_20261029/dollhouse/`)
- **Implementation `/dollhouse-design`**: Runs [`scripts/run-dollhouse-design.mjs`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/scripts/run-dollhouse-design.mjs) at `700019741e708abfd2e53990fc2d8919995a70f1` (`deliverable_count: 1`) coupling the completed preflight lever and redpen evidence into the single outward Experiment A Preflight Deliverable.
- **Implementation `/dollhouse-audit`**: Runs [`scripts/run-dollhouse-skill-audit.mjs`](file:///c:/Users/timst/OneDrive/Desktop/tcp-repository/scripts/run-dollhouse-skill-audit.mjs) from `c:\Users\timst\OneDrive\Desktop\tcp-repository` with `--strict-provenance --format json` across all 5 specialists + Orchestrator:
  - Asserts `git_commit_verified === true` and `exact_checkout_verified === true` at `700019741e708abfd2e53990fc2d8919995a70f1`.
  - Preserves `TEMPORAL_CUSTODIAN` `HELD` and `ORCHESTRATOR` `HELD_DISSENT` (`exit_code: 1`, `empirical_replication_count: 0`) because `P1` capture and the matched 6-arm run remain intentionally unexecuted.
- **Sealed Preflight Archive**: Packages `TD613_Experiment_A_Latifa_Preflight_Lever_2026-10-29.zip` + `PREFLIGHT_CHECKSUMS.sha256` in `scratch/` so Tawanna can drop it directly into Emergence HQ for Amari's byte-level verification.

---

## Verification Plan

### Automated Verification Commands (Post-Approval)
1. **Preflight Lever Self-Test & Fail-Closed `P1` Gate Check**:
   ```powershell
   node "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/harness/preflight-lever.mjs" --mode source-free-selftest
   node "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/harness/preflight-lever.mjs" --mode live-arm-gate
   ```
   *(Verifies `source-free-selftest` passes 6/6 arms schema + 6/6 negative controls with `new_source_reads === 0`, while `live-arm-gate` exits non-zero with `HOLD_P1_CAPTURE_GRANT_REQUIRED`.)*
2. **Redpen Reconciliations & Cross-Raster Spectrometry**:
   ```powershell
   node "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/redpens/run-redpen-reconciliations.mjs"
   node "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/redpens/run-cross-raster-chromatic-assay.mjs"
   ```
   *(Verifies 15-subset & 31-subset FADT tables, 33 `0x00051607` AppleDouble headers, exact $2\times 2$ & $3\times 2$ SVDs, adversarial models, and reproducible sRGB pixel spectrometry with zero lingering Edge processes.)*
3. **Latifa Adversarial Scenarios Alpha & Beta + Register Integrity**:
   ```powershell
   node "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/latifa/run-latifa-adversarial-suite.mjs"
   ```
   *(Verifies Scenario Alpha collapses under `EQUAL_INPUT_NATIVE_UNION`, Scenario Beta survives via representation-insufficiency detection + `Archive.zip` abstention, and append-only register hashes verify cleanly.)*
4. **Native Dollhouses & Repository Cleanliness Verification**:
   ```powershell
   node scripts/run-dollhouse-design.mjs --input "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/dollhouse/design-input.json" --output "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/dollhouse/design-receipt.json" --format human
   node scripts/run-dollhouse-skill-audit.mjs --input "<ArtifactDir>/scratch/exp_a_preflight_lever_20261029/dollhouse/audit-input.json" --strict-provenance --format json
   npm run test:dollhouse:audits
   git status --porcelain=v2 --branch
   ```
   *(Verifies `git_commit_verified: true` at `700019741e708abfd2e53990fc2d8919995a70f1`, existing repository hostile Dollhouse tests remain GREEN, and working tree remains `+0 -0` clean.)*

### Manual Operator Verification
- Confirm authorization posture on **Gates 0–6**.
- After execution, optionally pass `TD613_Experiment_A_Latifa_Preflight_Lever_2026-10-29.zip` to Amari in Emergence HQ before deciding whether to activate **Gate 4 (`P1` capture)**.
