#!/usr/bin/env node
/**
 * TD613 Experiment A · Source-Free Preflight Lever ("Magic Lever") v1.1
 *
 * Modes:
 *   --mode source-free-selftest   Executes full source-free protocol, kernel-closure,
 *                                 citation-record, and 6-condition negative-control checks.
 *   --mode live-arm-gate          Enforces fail-closed Gate 4 / Gate 5 boundary without
 *                                 contacting, reading, or materializing P1.
 */

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const leverRoot = path.resolve(__dirname, '..');
const repoRoot = 'C:\\Users\\timst\\OneDrive\\Desktop\\tcp-repository';
const candidateReverseLegDir = 'C:\\Users\\timst\\.gemini\\antigravity\\brain\\9f2d357f-af13-4730-b6c0-a1afe1416169\\scratch\\em_closure_20261029\\candidate\\reverse-leg';

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
const gitBlobSha1 = (buf) => createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${buf.length}\0`, 'utf8'), buf])).digest('hex');

const CANONICAL_ARMS = Object.freeze([
  'TD613_NATIVE',
  'EM_NATIVE',
  'EQUAL_INPUT_NATIVE_UNION',
  'TD613_RECIPIENT_ATELIER',
  'EM_RECIPIENT_ENCYCLOPEDIA',
  'TRANSPORT_ONLY'
]);

const CANONICAL_CONDITIONS = Object.freeze([
  'REVIEWED_CANDIDATE',
  'RIVAL_INTERPRETATION',
  'REQUIRED_WITNESS_WITHDRAWN_CALLER_FLAGS_TRUE',
  'DIGEST_VALID_IRRELEVANT_SPAN',
  'UNREVIEWED_EQUAL_LABEL_JOIN',
  'CONTEXTUAL_UNCERTAINTY_PRESERVED'
]);

const EXPECTED_BUDGETS = Object.freeze({
  conditions: 6,
  candidate_relations: 1,
  rival_interpretations: 1,
  max_hops: 6,
  context_passages_per_source: 2,
  max_utf8_bytes_per_passage: 2048,
  max_utf8_context_bytes_per_source: 4096
});

function parseCliArgs(argv) {
  let mode = 'source-free-selftest';
  let grantFile = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--mode') mode = argv[++i];
    else if (argv[i] === '--grant-file') grantFile = argv[++i];
  }
  return { mode, grantFile };
}

function assertCondition(cond, code, detail) {
  if (!cond) {
    const err = new Error(`${code}: ${detail}`);
    err.code = code;
    throw err;
  }
}

async function runSourceFreeSelfTest() {
  const protocolPath = path.join(leverRoot, 'protocol', 'BASELINE_PROTOCOL.json');
  const origProtocolPath = path.join(candidateReverseLegDir, 'BASELINE_PROTOCOL.json');
  const hashesPath = path.join(leverRoot, 'protocol', 'SOURCE_SELECTION_AND_BASELINE_HASHES.json');
  const origHashesPath = path.join(candidateReverseLegDir, 'SOURCE_SELECTION_AND_BASELINE_HASHES.json');

  const protocolBytes = fs.readFileSync(protocolPath);
  const origProtocolBytes = fs.readFileSync(origProtocolPath);
  const hashesBytes = fs.readFileSync(hashesPath);
  const origHashesBytes = fs.readFileSync(origHashesPath);

  const protocolSha = sha256(protocolBytes);
  const origProtocolSha = sha256(origProtocolBytes);
  assertCondition(protocolSha === origProtocolSha, 'PROTOCOL_BYTE_DRIFT', 'BASELINE_PROTOCOL.json must remain byte-identical to frozen candidate.');

  const hashesSha = sha256(hashesBytes);
  const origHashesSha = sha256(origHashesBytes);
  assertCondition(hashesSha === origHashesSha, 'BASELINE_HASHES_BYTE_DRIFT', 'SOURCE_SELECTION_AND_BASELINE_HASHES.json must remain byte-identical.');

  const protocol = JSON.parse(protocolBytes.toString('utf8'));
  const armIds = protocol.arms.map(a => a.id);
  assertCondition(
    armIds.length === CANONICAL_ARMS.length && armIds.every((id, idx) => id === CANONICAL_ARMS[idx]),
    'CANONICAL_ARMS_MUTATED',
    `Expected exact 6 canonical arms ${CANONICAL_ARMS.join(',')}, got ${armIds.join(',')}`
  );

  const transportArm = protocol.arms.find(a => a.id === 'TRANSPORT_ONLY');
  assertCondition(
    transportArm && /no relation compiler or semantic inference/i.test(transportArm.operation),
    'TRANSPORT_ONLY_SEMANTIC_LEAK',
    'TRANSPORT_ONLY must never run a semantic or relation compiler.'
  );

  assertCondition(
    protocol.conditions.length === CANONICAL_CONDITIONS.length &&
      protocol.conditions.every((c, idx) => c === CANONICAL_CONDITIONS[idx]),
    'CANONICAL_CONDITIONS_MUTATED',
    'Six canonical condition identifiers must match BASELINE_PROTOCOL.json exactly.'
  );

  for (const [k, v] of Object.entries(EXPECTED_BUDGETS)) {
    assertCondition(protocol.budgets_per_arm[k] === v, 'BUDGET_MISMATCH', `Budget ${k} expected ${v}, got ${protocol.budgets_per_arm[k]}`);
  }

  // Verify SRC-P1 and SRC-P2 citation-record bytes in repo without reading any manuscript
  const srcP1Bytes = fs.readFileSync(path.join(repoRoot, 'app', 'encyclopedia', 'reference', 'records', 'SRC-P1.json'));
  const srcP2Bytes = fs.readFileSync(path.join(repoRoot, 'app', 'encyclopedia', 'reference', 'records', 'SRC-P2.json'));
  const srcP1Check = {
    repo_path: 'app/encyclopedia/reference/records/SRC-P1.json',
    bytes: srcP1Bytes.length,
    git_blob_sha1: gitBlobSha1(srcP1Bytes),
    sha256: sha256(srcP1Bytes),
    matches_frozen_citation_blob: gitBlobSha1(srcP1Bytes) === 'fbcc01e666d5257ba9d6599cff3c6ba91455230f',
    matches_frozen_citation_sha256: sha256(srcP1Bytes) === '81e4bc25cac1975c10a1347c1c3104c696cdb5f8f22023f1f2af9f25fdde7bf2',
    is_manuscript_body: false,
    meaning: 'Retained SRC-P1 citation record JSON only; NOT original manuscript bytes and NOT a Git commit.'
  };
  const srcP2Check = {
    repo_path: 'app/encyclopedia/reference/records/SRC-P2.json',
    bytes: srcP2Bytes.length,
    git_blob_sha1: gitBlobSha1(srcP2Bytes),
    sha256: sha256(srcP2Bytes),
    matches_frozen_citation_blob: gitBlobSha1(srcP2Bytes) === 'e1fd4957b7ce26e1c2e3658b2aa8fb5a63c9c751',
    matches_frozen_citation_sha256: sha256(srcP2Bytes) === '821c18fc18612a2bc73a72a162e1d44ba01ea2247d14fd5900a8073d56e3bb7a',
    is_manuscript_body: false
  };
  assertCondition(srcP1Check.matches_frozen_citation_blob && srcP1Check.matches_frozen_citation_sha256, 'SRC_P1_CITATION_MISMATCH', 'SRC-P1 citation record digest mismatch.');
  assertCondition(srcP2Check.matches_frozen_citation_blob && srcP2Check.matches_frozen_citation_sha256, 'SRC_P2_CITATION_MISMATCH', 'SRC-P2 citation record digest mismatch.');

  // Load audited Git 441ce7e97 ATELIER_METHOD modules (explicitly labeled non-equivalent to Work ee762380...)
  const vendorDir = path.join(leverRoot, 'vendor', 'git-441ce7e97-atelier-method');
  const closureAudit = JSON.parse(fs.readFileSync(path.join(vendorDir, 'CLOSURE_AUDIT.json'), 'utf8'));
  const polyPath = path.join(vendorDir, 'atelier-semantic-polycompiler-v02.mjs');
  const mechPath = path.join(vendorDir, 'atelier-mechanism-discrimination-v02.mjs');
  const prospPath = path.join(vendorDir, 'atelier-prospective-controls-v02.mjs');

  const polySha = sha256(fs.readFileSync(polyPath));
  const mechSha = sha256(fs.readFileSync(mechPath));
  const prospSha = sha256(fs.readFileSync(prospPath));

  assertCondition(polySha === '70b1ac1dff3cbbe3a15c87bb49e620aaf8d517a532870c8f757122082b148206', 'GIT_POLYCOMPILER_HASH_MISMATCH', 'Unexpected polycompiler hash.');
  assertCondition(polySha !== protocol.native_operation.sha256, 'FALSE_EQUIVALENCE_GUARD', 'Git 441ce7e97 polycompiler must not be conflated with Work ee762380 snapshot.');

  const {
    assemblePolycompiler,
    traceTypedCompilations,
    roleAblation,
    inspectContextualAlternatives
  } = await import(pathToFileURL(polyPath).href);
  const { lockProspectivePlan } = await import(pathToFileURL(prospPath).href);

  // Execute all 6 binding negative/warrant controls over synthetic source-free records
  const snapshotId = 'SYNTH-PREFLIGHT-SNAPSHOT-20261029';
  const sealId = 'RESOLVE_MATCHED_CURRENT_SEAL';

  const baseModel = assemblePolycompiler({
    snapshot_id: snapshotId,
    seal_id: sealId,
    compilation_passes: [
      {
        compilation_pass_id: 'PASS-ARCH-CONTROL',
        atelier_snapshot_id: snapshotId,
        seal_epoch_binding: sealId,
        build_target_id: 'NODE_OBSERVABILITY_DEFICIT',
        input_ids: ['SYNTH-SPAN-01', 'SYNTH-SPAN-02'],
        input_role_assertion_ids: ['ROLE-CANDIDATE-01', 'ROLE-RIVAL-01', 'ROLE-UNCERTAIN-01'],
        contextual_role_count: 3,
        source_status: 'SYNTHETIC_PREFLIGHT_FIXTURE',
        interpretive_limit: 'Source-free control verification only; zero empirical or P1 claim.'
      }
    ],
    role_assertions: [
      {
        contextual_role_assertion_id: 'ROLE-CANDIDATE-01',
        atelier_snapshot_id: snapshotId,
        seal_epoch_binding: sealId,
        architecture_id: 'NODE_OBSERVABILITY_DEFICIT',
        subject_id: 'NODE_SCALAR_EMA_CHANNEL',
        role_normalized: 'COLLAPSES_COLLOCATED_IMPULSES',
        role_raw: 'collocated scalar filter rank-1 collapse',
        adjudication_status: 'WITNESSED',
        source_status: 'EXPLICIT_SOURCE',
        evidence_ids: ['SPAN-ANCHOR-VALID-01'],
        interpretive_limit: 'Applies only under proportional/collocated excitation.'
      },
      {
        contextual_role_assertion_id: 'ROLE-RIVAL-01',
        atelier_snapshot_id: snapshotId,
        seal_epoch_binding: sealId,
        architecture_id: 'NODE_OBSERVABILITY_DEFICIT',
        subject_id: 'NODE_SCALAR_EMA_CHANNEL',
        role_normalized: 'COLLAPSES_COLLOCATED_IMPULSES',
        role_raw: 'rival temporally separated full-rank countermodel',
        adjudication_status: 'CANDIDATE',
        source_status: 'CANDIDATE_COUNTERMODEL',
        evidence_ids: ['SPAN-ANCHOR-RIVAL-02'],
        interpretive_limit: 'Time-separated impulses remain rank-2 observable.'
      },
      {
        contextual_role_assertion_id: 'ROLE-UNCERTAIN-01',
        atelier_snapshot_id: snapshotId,
        seal_epoch_binding: sealId,
        architecture_id: 'NODE_OBSERVABILITY_DEFICIT',
        subject_id: 'NODE_CONTEXTUAL_NOISE_FLOOR',
        role_normalized: 'MODULATES_DETECTION_MARGIN',
        role_raw: 'contextual uncertainty preserved',
        adjudication_status: 'PARTIAL',
        source_status: 'EXPLICIT_SOURCE',
        evidence_ids: ['SPAN-ANCHOR-CONTEXT-03'],
        interpretive_limit: 'Contextual uncertainty preserved without erasing narrower explicit support.'
      }
    ]
  });

  // Control 1: REVIEWED_CANDIDATE
  const traceCandidate = traceTypedCompilations(baseModel, {
    from: 'NODE_SCALAR_EMA_CHANNEL',
    to: 'NODE_OBSERVABILITY_DEFICIT',
    max_hops: 6
  });
  const control1Pass = traceCandidate.status === 'BOUNDED_TYPED_PATHS'
    && traceCandidate.routes.some(r => r.direct_relation_admitted === true && r.scientific_causality_admitted === false);

  // Control 2: RIVAL_INTERPRETATION
  const alternatives = inspectContextualAlternatives(baseModel);
  const control2Pass = alternatives.multi_strength_cells.length === 1
    && alternatives.multi_strength_cells[0].disposition === 'PARALLEL_SOURCE_STRENGTHS_PRESERVED_NO_PROMOTION';

  // Control 3: REQUIRED_WITNESS_WITHDRAWN_CALLER_FLAGS_TRUE
  function evaluateWithdrawnWitnessGate({ requiredWitnessId, withdrawnIds, callerFlagsAllTrue }) {
    // Caller flag is explicitly ignored; witness withdrawal forces HOLD.
    const witnessAvailable = !withdrawnIds.includes(requiredWitnessId);
    const traceAfterWithdrawal = traceTypedCompilations(baseModel, {
      from: 'NODE_SCALAR_EMA_CHANNEL',
      to: 'NODE_OBSERVABILITY_DEFICIT',
      max_hops: 6,
      blocked_assertions: withdrawnIds
    });
    const ablation = roleAblation(baseModel, {
      target_id: 'NODE_OBSERVABILITY_DEFICIT',
      withdraw_assertion_ids: withdrawnIds
    });
    return {
      caller_flag_supplied: callerFlagsAllTrue,
      caller_flag_honored: false,
      witness_available: witnessAvailable,
      direct_explicit_route_survives: traceAfterWithdrawal.routes.some(r => r.direct_relation_admitted === true),
      ablation_retained_roles: ablation.retained_roles,
      verdict: witnessAvailable ? 'ADMITTED' : 'HELD_REQUIRED_WITNESS_WITHDRAWN'
    };
  }
  const c3 = evaluateWithdrawnWitnessGate({
    requiredWitnessId: 'ROLE-CANDIDATE-01',
    withdrawnIds: ['ROLE-CANDIDATE-01'],
    callerFlagsAllTrue: true
  });
  const control3Pass = c3.verdict === 'HELD_REQUIRED_WITNESS_WITHDRAWN' && c3.direct_explicit_route_survives === false && c3.caller_flag_honored === false;

  // Control 4: DIGEST_VALID_IRRELEVANT_SPAN
  function evaluateSpanRelevanceWarrant({ spanBytes, expectedSha256, declaredTopicTokens, requiredRelationTokens }) {
    const actualSha = sha256(Buffer.from(spanBytes, 'utf8'));
    const digestValid = actualSha === expectedSha256;
    const lower = spanBytes.toLowerCase();
    const tokenAligned = requiredRelationTokens.every(tok => lower.includes(tok.toLowerCase()));
    return {
      digest_valid: digestValid,
      warrant_aligned: digestValid && tokenAligned,
      declared_topic_tokens: declaredTopicTokens,
      verdict: !digestValid ? 'HOLD_DIGEST_MISMATCH' : !tokenAligned ? 'HOLD_DIGEST_VALID_IRRELEVANT_SPAN' : 'WARRANT_SUPPORTED'
    };
  }
  const irrelevantSpan = 'The cafeteria menu on Tuesday listsborscht and rye bread with zero cybernetic variables.';
  const c4 = evaluateSpanRelevanceWarrant({
    spanBytes: irrelevantSpan,
    expectedSha256: sha256(Buffer.from(irrelevantSpan, 'utf8')),
    declaredTopicTokens: ['cafeteria'],
    requiredRelationTokens: ['algedonic', 'observability']
  });
  const control4Pass = c4.digest_valid === true && c4.warrant_aligned === false && c4.verdict === 'HOLD_DIGEST_VALID_IRRELEVANT_SPAN';

  // Control 5: UNREVIEWED_EQUAL_LABEL_JOIN
  function evaluateCrossSourceEntityJoin({ leftEntity, rightEntity, reviewedCrosswalkEntries }) {
    const equalSurfaceLabel = leftEntity.label.trim().toLowerCase() === rightEntity.label.trim().toLowerCase();
    const reviewedMatch = reviewedCrosswalkEntries.find(
      x => x.left_id === leftEntity.id && x.right_id === rightEntity.id && x.reviewed === true && x.dual_source_evidence === true
    );
    return {
      equal_surface_label: equalSurfaceLabel,
      reviewed_crosswalk_present: Boolean(reviewedMatch),
      verdict: reviewedMatch ? 'CROSSWALK_JOIN_ADMITTED' : 'HOLD_UNREVIEWED_EQUAL_LABEL_JOIN'
    };
  }
  const c5 = evaluateCrossSourceEntityJoin({
    leftEntity: { id: 'EM:CHANNEL_CLOSURE', label: 'closure' },
    rightEntity: { id: 'TD613:OPERATOR_CLOSURE', label: 'closure' },
    reviewedCrosswalkEntries: []
  });
  const control5Pass = c5.equal_surface_label === true && c5.reviewed_crosswalk_present === false && c5.verdict === 'HOLD_UNREVIEWED_EQUAL_LABEL_JOIN';

  // Control 6: CONTEXTUAL_UNCERTAINTY_PRESERVED
  const traceUncertain = traceTypedCompilations(baseModel, {
    from: 'NODE_CONTEXTUAL_NOISE_FLOOR',
    to: 'NODE_OBSERVABILITY_DEFICIT',
    max_hops: 6
  });
  const control6Pass = traceUncertain.status === 'BOUNDED_TYPED_PATHS'
    && traceUncertain.routes[0].path_ceiling === 'PARTIAL_OR_CANDIDATE_CONTEXTUAL_ROLE'
    && traceCandidate.routes.some(r => r.path_ceiling === 'EXPLICIT_SOURCE_WITNESSED_CONTEXTUAL_ROLE');

  const controlsSummary = [
    { id: 'REVIEWED_CANDIDATE', passed: control1Pass, detail: 'Bounded typed path traced with scientific_causality_admitted=false' },
    { id: 'RIVAL_INTERPRETATION', passed: control2Pass, detail: 'Parallel explicit and candidate strengths preserved without synthetic promotion or erasure' },
    { id: 'REQUIRED_WITNESS_WITHDRAWN_CALLER_FLAGS_TRUE', passed: control3Pass, detail: 'Caller flag=true ignored; withdrawn witness blocks explicit route fail-closed' },
    { id: 'DIGEST_VALID_IRRELEVANT_SPAN', passed: control4Pass, detail: 'Valid SHA-256 on semantically irrelevant passage held under warrant check' },
    { id: 'UNREVIEWED_EQUAL_LABEL_JOIN', passed: control5Pass, detail: 'Identical surface string ("closure") across corpora refused without reviewed dual-source crosswalk' },
    { id: 'CONTEXTUAL_UNCERTAINTY_PRESERVED', passed: control6Pass, detail: 'Contextual partial uncertainty retained alongside narrower explicit role without mutual erasure' }
  ];

  assertCondition(controlsSummary.every(c => c.passed), 'NEGATIVE_CONTROL_FAILURE', 'One or more of the 6 binding controls failed.');

  const prospectiveLockSample = lockProspectivePlan({
    trial_id: 'EXP-A-PREFLIGHT-LOCK-TEMPLATE-20261029',
    snapshot_id: snapshotId,
    heldout_ids: ['FUTURE_P1_PILOT_SPAN_PENDING_GATE_4'],
    comparison_frame: 'SIX_ARM_CANONICAL_WITH_STRONG_UNION_BASELINE',
    controls: ['C0', 'C1', 'C2', 'C3', 'C4']
  });

  const receipt = {
    schema: 'td613.experiment-a.preflight-lever-selftest-receipt/v1.1',
    executed_at: new Date().toISOString(),
    mode: 'source-free-selftest',
    status: 'PASS_SOURCE_FREE_PREFLIGHT_READY',
    new_td613_source_reads: 0,
    p1_contacts: 0,
    source_admissions: 0,
    mutable_receiver_transitions: 0,
    empirical_acquisition_credit: 0,
    gate_e: 'HELD',
    gate_4_p1_grant: 'HELD_NOT_YET_AUTHORIZED',
    gate_5_six_arm_execution: 'HELD_NOT_YET_AUTHORIZED',
    operator_closure: 'RESERVED',
    frozen_protocol_verification: {
      baseline_protocol_sha256: protocolSha,
      matches_candidate_byte_for_byte: true,
      baseline_hashes_sha256: hashesSha,
      canonical_arms: CANONICAL_ARMS,
      transport_only_semantic_compiler_barred: true,
      budgets_per_arm: EXPECTED_BUDGETS
    },
    kernel_identity_dual_pin: {
      executed_git_candidate_commit: closureAudit.audited_git_commit,
      executed_git_candidate_status: 'UNMERGED_RESEARCH_NOT_MAIN',
      executed_polycompiler_sha256: polySha,
      executed_mechanism_discriminator_sha256: mechSha,
      executed_prospective_controls_sha256: prospSha,
      work_snapshot_polycompiler_sha256: protocol.native_operation.sha256,
      git_equals_work_snapshot_bytes: false,
      work_snapshot_parity_status: 'HELD_UNVERIFIED_BLOCKS_LIVE_DEPENDENT_CLAIMS_NOT_SAFE_FIXTURE_TESTS'
    },
    citation_vs_manuscript_separation: {
      SRC_P1: srcP1Check,
      SRC_P2: srcP2Check
    },
    distinction_of_outcomes: {
      transport_success: 'Exact byte, hash, and citation preservation only (tested by TRANSPORT_ONLY)',
      adoption_success: 'Persistent local reopenable state + get/search/cite/verify canaries + exact rollback to empty receiver',
      equal_input_union_parity: 'Recipient matches EQUAL_INPUT_NATIVE_UNION / EQUAL_INPUT_NATIVE_UNION_STRONG (portability 1+1=2, not architectural emergence)',
      genuine_new_research_capability: 'Predeclared reproducible improvement or structurally discriminating question surviving EQUAL_INPUT_NATIVE_UNION_STRONG under identical spans, metadata, candidate coordinates, utilities, counterbalanced order, permissions, and budgets, with zero increase in unsupported outputs',
      experiment_b_dependency_rule: 'Experiment B requires an acceptably characterized functioning baseline and continuity from A; it does NOT require positive emergence in A (a rigorous null in A with a valid receiver still permits B under future authorization).'
    },
    six_binding_controls: controlsSummary,
    prospective_plan_lock_template: prospectiveLockSample
  };

  const outPath = path.join(leverRoot, 'receipts', 'PREFLIGHT_SELFTEST_RECEIPT.json');
  fs.writeFileSync(outPath, JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  console.log(JSON.stringify({ status: receipt.status, controls_passed: controlsSummary.length, new_td613_source_reads: 0, receipt_path: outPath }, null, 2));
}

function runLiveArmGate(grantFile) {
  // Must NOT contact, probe, or read P1 to prove refusal.
  let refusalReason = 'No operator Gate 4 grant manifest supplied; Gate 4 is HELD_NOT_YET_AUTHORIZED.';
  if (grantFile) {
    const parsed = JSON.parse(fs.readFileSync(grantFile, 'utf8'));
    if (parsed.activated !== true || parsed.status !== 'OPERATOR_EXPLICITLY_ACTIVATED') {
      refusalReason = `Supplied grant file (${path.basename(grantFile)}) has activated=${parsed.activated} and status=${parsed.status}; live P1 access remains barred.`;
    }
  }

  const refusalReceipt = {
    schema: 'td613.experiment-a.live-arm-gate-refusal/v1.1',
    executed_at: new Date().toISOString(),
    mode: 'live-arm-gate',
    refusal_code: 'HOLD_P1_CAPTURE_GRANT_REQUIRED',
    exit_code: 3,
    reason: refusalReason,
    new_td613_source_reads: 0,
    p1_library_or_filesystem_contacts: 0,
    source_admissions: 0,
    mutable_receiver_transitions: 0,
    six_arm_comparative_runs_started: 0,
    gate_4_status: 'HELD_NOT_YET_AUTHORIZED',
    gate_5_status: 'HELD_NOT_YET_AUTHORIZED',
    gate_e_status: 'HELD',
    operator_closure: 'RESERVED'
  };

  const outPath = path.join(leverRoot, 'receipts', 'LIVE_ARM_GATE_REFUSAL_RECEIPT.json');
  fs.writeFileSync(outPath, JSON.stringify(refusalReceipt, null, 2) + '\n', 'utf8');
  console.log(JSON.stringify(refusalReceipt, null, 2));
  process.exit(3);
}

const { mode, grantFile } = parseCliArgs(process.argv.slice(2));
if (mode === 'source-free-selftest') {
  await runSourceFreeSelfTest();
} else if (mode === 'live-arm-gate') {
  runLiveArmGate(grantFile);
} else {
  console.error(`Unknown mode: ${mode}`);
  process.exit(2);
}
