#!/usr/bin/env node
/**
 * TD613 Experiment A · Unrigged Latifa Adversarial Suite & Non-Scalar Question Vectors v1.1
 *
 * Implements Redpen v1.1 §2, §3, and §4:
 *   - Scenario Alpha: Cross-corpus bridge parity negative control (1 + 1 = 2; TRANSPORT_ONLY runs 0 compilers).
 *   - Scenario Beta: Unrigged evaluation with DIAGNOSTIC_WEAK_FLAT_COMPARATOR (diagnostic only),
 *     RIVAL_ENTROPIC_ABSTAINING_CLASSIFIER (proposes missing coordinates + abstains),
 *     EQUAL_INPUT_NATIVE_UNION_STRONG (inside canonical baseline arm, equal utilities/coordinates/budgets),
 *     and FADT_ATLAS_APERTURE_ROUTE across counterbalanced [FORWARD, REVERSED] orders.
 *   - Non-Scalar 4-Component Question Evaluation Vectors via repository Pedagogue & Aperture adapters.
 */

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const leverRoot = path.resolve(__dirname, '..');
const repoRoot = 'C:\\Users\\timst\\OneDrive\\Desktop\\tcp-repository';
const closureRoot = 'C:\\Users\\timst\\.gemini\\antigravity\\brain\\9f2d357f-af13-4730-b6c0-a1afe1416169\\scratch\\em_closure_20261029';

const sha256 = (b) => createHash('sha256').update(b).digest('hex');

// Frozen protocol & audited unmerged Git ATELIER_METHOD (Gate 3)
const baselineProtocolBytes = fs.readFileSync(path.join(leverRoot, 'protocol', 'BASELINE_PROTOCOL.json'));
const baselineProtocol = JSON.parse(baselineProtocolBytes.toString('utf8'));

const polycompilerPath = path.join(leverRoot, 'vendor', 'git-441ce7e97-atelier-method', 'atelier-semantic-polycompiler-v02.mjs');
const polycompilerSha = sha256(fs.readFileSync(polycompilerPath));
const {
  assemblePolycompiler,
  traceTypedCompilations,
  roleAblation,
  inspectContextualAlternatives
} = await import(pathToFileURL(polycompilerPath).href);

// Main repository engines (700019741e708abfd2e53990fc2d8919995a70f1)
const {
  computeFadtFiberBounds,
  evaluateFadtCoordinateRecovery
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'dollhouse-fadt-reparative-assistance.js')).href);

const {
  auditTypedEpistemicDeficit
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'aperture-v32-typed-epistemic-deficit.js')).href);

const {
  runAtlasContinuityAudit
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'dollhouse-continuity-audit.js')).href);

const {
  compilePedagogueResearchTransferCard
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'pedagogue-research-transfer.js')).href);

const {
  DOLLHOUSE_WITNESS_PLAN_SCHEMA,
  auditDollhouseWitnessPlan
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'dollhouse-witness-plan.js')).href);

// ============================================================================
// 1. SCENARIO ALPHA — CROSS-CORPUS BRIDGE PARITY CONTROL (1 + 1 = 2)
// ============================================================================
const syntheticEmRoleAssertions = [
  {
    contextual_role_assertion_id: 'SYNTH_ROLE_EM_ALGEDONIC_01',
    atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
    seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
    architecture_id: 'NODE_SCALAR_COLLAPSE_CHANNEL',
    subject_id: 'SYNTH_EM_ALGEDONIC_SOURCE',
    role_normalized: 'DECLARES_SCALAR_ALERT_COMPRESSION',
    role_raw: 'algedonic scalar compression',
    adjudication_status: 'WITNESSED',
    source_status: 'EXPLICIT_SOURCE',
    evidence_ids: ['SYNTH_EV_EM_01'],
    interpretive_limit: 'Synthetic source-free preflight assertion only; zero real P1 ingestion.'
  }
];

const syntheticTd613SurrogateRoleAssertions = [
  {
    contextual_role_assertion_id: 'SYNTH_ROLE_SURROGATE_APERTURE_01',
    atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
    seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
    architecture_id: 'NODE_RANK_DEFICIENT_NULLSPACE',
    subject_id: 'NODE_SCALAR_COLLAPSE_CHANNEL',
    role_normalized: 'MAPS_TO_LOCAL_NULLSPACE_DEFICIT',
    role_raw: 'crosswalk rank-1 nullspace deficit',
    adjudication_status: 'CANDIDATE',
    source_status: 'CROSSWALK_CANDIDATE',
    evidence_ids: ['SYNTH_EV_CROSSWALK_01'],
    interpretive_limit: 'Reviewed synthetic crosswalk edge; candidate relation budget = 1.'
  }
];

function runScenarioAlphaArm(armId) {
  const budgets = baselineProtocol.budgets_per_arm;
  if (armId === 'TRANSPORT_ONLY') {
    // Binding rule: TRANSPORT_ONLY NEVER runs a semantic compiler!
    return {
      arm_id: armId,
      semantic_compiler_invocations: 0,
      cross_corpus_bridge_recovered: false,
      hop_count: 0,
      ceiling: 'BYTE_CUSTODY_AND_METADATA_TRANSFER_ONLY_NO_SEMANTIC_COMPILATION'
    };
  }

  let assertions = [];
  let passes = [];
  if (armId === 'EM_NATIVE') {
    assertions = syntheticEmRoleAssertions;
    passes = [{
      compilation_pass_id: 'PASS_EM_01',
      atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
      seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
      build_target_id: 'NODE_SCALAR_COLLAPSE_CHANNEL',
      input_ids: ['SYNTH_EM_ALGEDONIC_SOURCE'],
      input_role_assertion_ids: ['SYNTH_ROLE_EM_ALGEDONIC_01'],
      contextual_role_count: 1,
      source_status: 'SYNTHETIC_FIXTURE',
      interpretive_limit: 'Single-corpus native control.'
    }];
  } else if (armId === 'TD613_NATIVE') {
    assertions = syntheticTd613SurrogateRoleAssertions;
    passes = [{
      compilation_pass_id: 'PASS_SURROGATE_01',
      atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
      seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
      build_target_id: 'NODE_RANK_DEFICIENT_NULLSPACE',
      input_ids: ['NODE_SCALAR_COLLAPSE_CHANNEL'],
      input_role_assertion_ids: ['SYNTH_ROLE_SURROGATE_APERTURE_01'],
      contextual_role_count: 1,
      source_status: 'SYNTHETIC_FIXTURE',
      interpretive_limit: 'Single-corpus surrogate native control (zero P1 reads).'
    }];
  } else {
    // EQUAL_INPUT_NATIVE_UNION, TD613_RECIPIENT_ATELIER, EM_RECIPIENT_ENCYCLOPEDIA receive equal union + crosswalk!
    assertions = [...syntheticEmRoleAssertions, ...syntheticTd613SurrogateRoleAssertions];
    passes = [
      {
        compilation_pass_id: 'PASS_EM_01',
        atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
        seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
        build_target_id: 'NODE_SCALAR_COLLAPSE_CHANNEL',
        input_ids: ['SYNTH_EM_ALGEDONIC_SOURCE'],
        input_role_assertion_ids: ['SYNTH_ROLE_EM_ALGEDONIC_01'],
        contextual_role_count: 1,
        source_status: 'SYNTHETIC_FIXTURE',
        interpretive_limit: 'Equal-input synthetic source pass 1.'
      },
      {
        compilation_pass_id: 'PASS_SURROGATE_01',
        atelier_snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
        seal_epoch_binding: 'RESOLVE_MATCHED_CURRENT_SEAL',
        build_target_id: 'NODE_RANK_DEFICIENT_NULLSPACE',
        input_ids: ['NODE_SCALAR_COLLAPSE_CHANNEL'],
        input_role_assertion_ids: ['SYNTH_ROLE_SURROGATE_APERTURE_01'],
        contextual_role_count: 1,
        source_status: 'SYNTHETIC_FIXTURE',
        interpretive_limit: 'Equal-input synthetic source pass 2.'
      }
    ];
  }

  const compiled = assemblePolycompiler({
    snapshot_id: 'SYNTH_PREFLIGHT_SNAP_01',
    seal_id: 'SYNTH_SEAL_01',
    compilation_passes: passes,
    role_assertions: assertions
  });
  const trace = traceTypedCompilations(compiled, {
    from: 'SYNTH_EM_ALGEDONIC_SOURCE',
    to: 'NODE_RANK_DEFICIENT_NULLSPACE',
    max_hops: budgets.max_hops
  });
  const ablation = roleAblation(compiled, {
    target_id: 'NODE_RANK_DEFICIENT_NULLSPACE',
    withdraw_assertion_ids: ['SYNTH_ROLE_SURROGATE_APERTURE_01']
  });
  const altCheck = inspectContextualAlternatives(compiled);

  return {
    arm_id: armId,
    semantic_compiler_invocations: 1,
    cross_corpus_bridge_recovered: trace.routes.length > 0,
    hop_count: trace.routes[0]?.hop_count ?? 0,
    path_ceiling: trace.routes[0]?.path_ceiling ?? trace.status,
    ablation_retained_roles_after_crosswalk_withdrawal: ablation.retained_roles,
    multi_strength_conflict_count: altCheck.multi_strength_cells.length
  };
}

const scenarioAlphaArms = baselineProtocol.arms.map(a => runScenarioAlphaArm(a.id));
const unionArmAlpha = scenarioAlphaArms.find(a => a.arm_id === 'EQUAL_INPUT_NATIVE_UNION');
const atelierArmAlpha = scenarioAlphaArms.find(a => a.arm_id === 'TD613_RECIPIENT_ATELIER');
const transportArmAlpha = scenarioAlphaArms.find(a => a.arm_id === 'TRANSPORT_ONLY');

const scenarioAlphaSummary = {
  purpose: 'Negative control proving cross-corpus semantic bridge collapses to exact parity (1 + 1 = 2) when EQUAL_INPUT_NATIVE_UNION receives identical spans and crosswalk.',
  atelier_kernel_provenance: {
    git_candidate_commit: '441ce7e974a76685a212552c1da610ea30fd1efc',
    git_branch_status: 'UNMERGED_RESEARCH_CANDIDATE_NOT_MAIN',
    module_filename: 'atelier-semantic-polycompiler-v02.mjs',
    executed_git_module_sha256: polycompilerSha,
    protocol_declared_work_snapshot_sha256: baselineProtocol.native_operation.sha256,
    byte_equivalent_to_work_snapshot: false,
    work_snapshot_parity_status: 'HELD_UNVERIFIED_BLOCKS_LIVE_CLAIMS_PERMITS_SOURCE_FREE_FIXTURE_TESTS'
  },
  new_td613_source_reads: 0,
  enforced_protocol_budgets: baselineProtocol.budgets_per_arm,
  arm_results: scenarioAlphaArms,
  transport_only_ran_zero_compilers: transportArmAlpha.semantic_compiler_invocations === 0,
  equal_input_union_matches_recipient_arms:
    unionArmAlpha.cross_corpus_bridge_recovered === true &&
    unionArmAlpha.cross_corpus_bridge_recovered === atelierArmAlpha.cross_corpus_bridge_recovered &&
    unionArmAlpha.hop_count === atelierArmAlpha.hop_count,
  emergent_surplus_over_union: 0,
  outcome: 'PARITY_NEGATIVE_CONTROL_CONFIRMED_1_PLUS_1_EQUALS_2'
};

// ============================================================================
// 2. SCENARIO BETA — UNRIGGED MULTI-DEFECT CLASSIFICATION & ABSTENTION ASSAY
// ============================================================================
const PREDECLARED_BETA_OUTCOMES = Object.freeze([
  'SUPPORTED_ARCHITECTURAL_ADVANTAGE',
  'PARITY_WITH_STRONG_UNION',
  'FAILURE_INFERIOR_TO_STRONG_UNION',
  'HELD_POST_HOC_OR_INDETERMINATE'
]);

// Build Dataset D1: Em 147-record outer metadata inventory (POST-HOC DEVELOPMENT FIXTURE; Gate 2 Archive.zip OPAQUE)
const r1Html = fs.readFileSync(path.join(closureRoot, 'candidate', 'instance', 'index.html'), 'utf8');
const i0 = r1Html.indexOf('id="td613-reference-records"');
const s0 = r1Html.indexOf('>', i0) + 1;
const s1 = r1Html.indexOf('</script>', s0);
const rawRecords = r1Html.slice(s0, s1).trim();
const emRecords = rawRecords.startsWith('[') ? JSON.parse(rawRecords) : rawRecords.split(/\r?\n/).filter(Boolean).map(l => JSON.parse(l));

const incomingDerivIds = new Set();
for (const r of emRecords) {
  if (r.kind === 'artifact' && Array.isArray(r.links)) {
    for (const l of r.links) {
      const target = typeof l === 'string' ? l : (l.target || l.id);
      if (target) incomingDerivIds.add(target);
    }
  }
}

const datasetD1EmPostHoc = emRecords.map(r => {
  const srcMeta = r.record?.source || r.record?.derivative || {};
  const relPath = srcMeta.archive_relative_path || r.record?.raw_bytes_path || r.label || '';
  const baseName = path.posix.basename(relPath.replace(/\\/g, '/'));
  const hasInlineText = typeof r.record?.body === 'string' && r.record.body.length > 0;
  const hasPairedDerivative = incomingDerivIds.has(r.id);
  const isPackagingSidecar = baseName.startsWith('._') || srcMeta.media_type === 'application/applefile';
  const isOpaqueArchive = baseName.toLowerCase().endsWith('.zip') || srcMeta.media_type === 'application/zip';

  let expectedClass;
  if (r.kind === 'artifact') expectedClass = 'ARCHIVED_DERIVATIVE';
  else if (hasInlineText) expectedClass = 'INLINE_TEXT_SOURCE';
  else if (hasPairedDerivative) expectedClass = 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE';
  else if (isPackagingSidecar) expectedClass = 'PACKAGING_METADATA_COMPANION_NON_WORK';
  else if (isOpaqueArchive) expectedClass = 'ABSTAIN_HOLD_OPAQUE_CONTAINER';
  else expectedClass = 'UNEXTRACTED_BINARY_CANDIDATE';

  return {
    id: r.id,
    kind: r.kind,
    basename: baseName,
    media_type: srcMeta.media_type || 'text/plain',
    has_inline_text: hasInlineText,
    has_paired_derivative: hasPairedDerivative,
    is_packaging_artifact: isPackagingSidecar,
    is_opaque_archive_container: isOpaqueArchive,
    probe_operator: null,
    expected_class: expectedClass
  };
});

// Build Dataset D2: Synthetic Held-Out Multi-Defect Perturbation Suite (3 bundles, tested FORWARD and REVERSED)
const syntheticHeldOutBundles = [
  {
    bundle_id: 'SYNTH_BUNDLE_A_CLEAN_MIXED',
    items: [
      { id: 'SA_01', kind: 'source', basename: 'treatise-alpha.md', media_type: 'text/markdown', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: [[1, 0], [0, 1]], expected_class: 'INLINE_TEXT_SOURCE' },
      { id: 'SA_02', kind: 'source', basename: 'scan-beta.pdf', media_type: 'application/pdf', has_inline_text: false, has_paired_derivative: true, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: [[1, 0], [0, 1]], expected_class: 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE' },
      { id: 'SA_03', kind: 'artifact', basename: 'scan-beta.extracted.txt', media_type: 'text/plain', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: [[1, 0], [0, 1]], expected_class: 'ARCHIVED_DERIVATIVE' }
    ]
  },
  {
    bundle_id: 'SYNTH_BUNDLE_B_SIDECARS_AND_OPAQUE_ARCHIVE',
    items: [
      { id: 'SB_01', kind: 'source', basename: '._treatise-alpha.md', media_type: 'application/applefile', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: true, is_opaque_archive_container: false, probe_operator: null, expected_class: 'PACKAGING_METADATA_COMPANION_NON_WORK' },
      { id: 'SB_02', kind: 'source', basename: 'Thumbs.db', media_type: 'application/octet-stream', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: true, is_opaque_archive_container: false, probe_operator: null, expected_class: 'PACKAGING_METADATA_COMPANION_NON_WORK' },
      { id: 'SB_03', kind: 'source', basename: 'unextracted-notes.pdf', media_type: 'application/pdf', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: null, expected_class: 'UNEXTRACTED_BINARY_CANDIDATE' },
      { id: 'SB_04', kind: 'source', basename: 'sealed-bundle.tar.gz', media_type: 'application/gzip', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: true, probe_operator: null, expected_class: 'ABSTAIN_HOLD_OPAQUE_CONTAINER' }
    ]
  },
  {
    bundle_id: 'SYNTH_BUNDLE_C_SPOOFED_EXTENSION_AND_ILL_CONDITIONED_SENSOR',
    items: [
      { id: 'SC_01', kind: 'source', basename: '._spoofed-paper.md', media_type: 'application/applefile', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: true, is_opaque_archive_container: false, probe_operator: null, expected_class: 'PACKAGING_METADATA_COMPANION_NON_WORK' },
      { id: 'SC_02', kind: 'source', basename: 'near-collinear-telemetry.md', media_type: 'text/markdown', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: [[1, 1], [0.15, 0.15], [1, 0.999]], expected_class: 'ABSTAIN_ILL_CONDITIONED_OBSERVATION' },
      { id: 'SC_03', kind: 'source', basename: 'well-conditioned-telemetry.md', media_type: 'text/markdown', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false, probe_operator: [[1, 1], [0.15, 0.15], [1, 0]], expected_class: 'INLINE_TEXT_SOURCE' }
    ]
  }
];

function supportForClass(cls) {
  switch (cls) {
    case 'INLINE_TEXT_SOURCE': return ['EXACT_ID_GET', 'INLINE_PRIMARY_SEARCH'];
    case 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE': return ['EXACT_ID_GET', 'PAIRED_DERIVATIVE_TRAVERSAL'];
    case 'PACKAGING_METADATA_COMPANION_NON_WORK': return ['EXACT_ID_GET', 'PACKAGING_COMPANION_NON_WORK'];
    case 'ABSTAIN_HOLD_OPAQUE_CONTAINER': return ['EXACT_ID_GET', 'HOLD_OPAQUE_CONTAINER'];
    case 'UNEXTRACTED_BINARY_CANDIDATE': return ['EXACT_ID_GET', 'BINARY_CANDIDATE_UNVERIFIED'];
    case 'ARCHIVED_DERIVATIVE': return ['EXACT_ID_GET', 'DERIVATIVE_SEARCH'];
    case 'ABSTAIN_ILL_CONDITIONED_OBSERVATION': return ['EXACT_ID_GET', 'HOLD_ILL_CONDITIONED_OPERATOR'];
    default: return ['EXACT_ID_GET'];
  }
}

// Method 1: Deliberately Weak Flat Comparator (DIAGNOSTIC ONLY — ZERO ARCHITECTURAL CREDIT)
function runWeakFlatDiagnosticComparator(items) {
  return items.map(item => {
    let predicted;
    if (item.kind === 'artifact') predicted = 'ARCHIVED_DERIVATIVE';
    else if (item.has_inline_text) predicted = 'INLINE_TEXT_SOURCE';
    else predicted = 'UNEXTRACTED_BINARY_CANDIDATE'; // Collapses sidecars, paired PDFs, and opaque containers!
    return { id: item.id, predicted, abstained: false, proposed_missing_coordinates: [] };
  });
}

// Method 2: Non-Dollhouse Rival Method (Shannon Conditional-Entropy Classifier permitted to propose missing coordinates & abstain)
function runRivalEntropicAbstainingClassifier(items) {
  // Check conditional impurity of 2-feature (kind, has_inline_text) leaves and propose missing split coordinates
  const twoCoordGroups = new Map();
  for (const it of items) {
    const k = `${it.kind}|${it.has_inline_text}`;
    if (!twoCoordGroups.has(k)) twoCoordGroups.set(k, new Set());
    const infClass = it.is_opaque_archive_container ? 'OPAQUE'
      : it.is_packaging_artifact ? 'SIDECAR'
      : it.has_paired_derivative ? 'PAIRED_BIN'
      : it.has_inline_text ? 'INLINE' : 'RAW_BIN';
    twoCoordGroups.get(k).add(infClass);
  }
  const proposedCoordinates = [];
  for (const [, set] of twoCoordGroups) {
    if (set.size > 1) {
      if (set.has('PAIRED_BIN')) proposedCoordinates.push('has_paired_derivative');
      if (set.has('SIDECAR')) proposedCoordinates.push('is_packaging_artifact');
      if (set.has('OPAQUE')) proposedCoordinates.push('is_opaque_archive_container');
    }
  }
  const uniqueProposed = [...new Set(proposedCoordinates)].sort();

  return items.map(item => {
    if (item.is_opaque_archive_container) {
      return { id: item.id, predicted: 'ABSTAIN_HOLD_OPAQUE_CONTAINER', abstained: true, proposed_missing_coordinates: uniqueProposed };
    }
    if (item.probe_operator) {
      // Compute Gram eigenvalues A^T A directly without Dollhouse adapter
      const m = item.probe_operator;
      let g00 = 0, g01 = 0, g11 = 0;
      for (const r of m) { g00 += r[0] * r[0]; g01 += r[0] * r[1]; g11 += r[1] * r[1]; }
      const tr = g00 + g11;
      const det = g00 * g11 - g01 * g01;
      const disc = Math.sqrt(Math.max(0, tr * tr - 4 * det));
      const lMax = (tr + disc) / 2;
      const lMin = Math.max(0, (tr - disc) / 2);
      const kappa = lMin <= 1e-12 ? Infinity : Math.sqrt(lMax / lMin);
      if (kappa > 100) {
        return { id: item.id, predicted: 'ABSTAIN_ILL_CONDITIONED_OBSERVATION', abstained: true, proposed_missing_coordinates: ['probe_condition_number_ceiling'] };
      }
    }
    let predicted;
    if (item.kind === 'artifact') predicted = 'ARCHIVED_DERIVATIVE';
    else if (item.has_inline_text) predicted = 'INLINE_TEXT_SOURCE';
    else if (item.has_paired_derivative) predicted = 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE';
    else if (item.is_packaging_artifact) predicted = 'PACKAGING_METADATA_COMPANION_NON_WORK';
    else predicted = 'UNEXTRACTED_BINARY_CANDIDATE';
    return { id: item.id, predicted, abstained: false, proposed_missing_coordinates: uniqueProposed };
  });
}

// Shared core evaluation when given equal coordinates, prior discoveries, permissions, and repository utilities
function evaluateWithEqualScientificUtilities(items, routeLabel) {
  // Verify FADT fiber gap on collapsed (kind, has_inline_text) fiber and recover minimal resolving coordinates
  const distinctRowsMap = new Map();
  for (const item of items) {
    let prelimClass;
    if (item.is_opaque_archive_container) prelimClass = 'ABSTAIN_HOLD_OPAQUE_CONTAINER';
    else if (item.kind === 'artifact') prelimClass = 'ARCHIVED_DERIVATIVE';
    else if (item.has_inline_text) prelimClass = 'INLINE_TEXT_SOURCE';
    else if (item.has_paired_derivative) prelimClass = 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE';
    else if (item.is_packaging_artifact) prelimClass = 'PACKAGING_METADATA_COMPANION_NON_WORK';
    else prelimClass = 'UNEXTRACTED_BINARY_CANDIDATE';

    if (!distinctRowsMap.has(prelimClass)) {
      distinctRowsMap.set(prelimClass, {
        id: prelimClass,
        coordinates: {
          kind: item.kind,
          has_inline_text: item.has_inline_text,
          has_paired_derivative: item.has_paired_derivative,
          is_packaging_artifact: item.is_packaging_artifact,
          is_opaque_archive_container: item.is_opaque_archive_container
        },
        support: supportForClass(prelimClass)
      });
    }
  }
  const distinctRows = [...distinctRowsMap.values()];
  const fadtRecovery = distinctRows.length > 1
    ? evaluateFadtCoordinateRecovery(distinctRows, ['kind', 'has_inline_text', 'has_paired_derivative', 'is_packaging_artifact', 'is_opaque_archive_container'])
    : { minimal_resolving_sets: [[]] };
  const fiberBounds = distinctRows.length > 1 ? computeFadtFiberBounds(distinctRows) : { irreducible_gap_cardinality: 0 };

  // Also verify Atlas continuity invariant on batch digest
  const batchDigest = 'sha256:' + sha256(Buffer.from(items.map(i => i.id).slice().sort().join(',')));
  const continuity = runAtlasContinuityAudit({
    origin: { id: `${routeLabel}_ORIGIN`, source_revision: '700019741e708abfd2e53990fc2d8919995a70f1', original_ref: batchDigest, current_ref: batchDigest, predecessor_ref: null, selected_commitments: [{ id: 'BATCH', commitment: batchDigest }], policy_commitment: 'GATE_2_OPAQUE_ARCHIVE', missingness: ['P1_UNEXECUTED'], claim_ceiling: ['PREFLIGHT_FIXTURE_ONLY'] },
    previous: { id: `${routeLabel}_ORIGIN`, source_revision: '700019741e708abfd2e53990fc2d8919995a70f1', original_ref: batchDigest, current_ref: batchDigest, predecessor_ref: null, selected_commitments: [{ id: 'BATCH', commitment: batchDigest }], policy_commitment: 'GATE_2_OPAQUE_ARCHIVE', missingness: ['P1_UNEXECUTED'], claim_ceiling: ['PREFLIGHT_FIXTURE_ONLY'] },
    current: { id: `${routeLabel}_EVAL`, source_revision: '700019741e708abfd2e53990fc2d8919995a70f1', original_ref: batchDigest, current_ref: batchDigest, predecessor_ref: batchDigest, selected_commitments: [{ id: 'BATCH', commitment: batchDigest }], policy_commitment: 'GATE_2_OPAQUE_ARCHIVE', missingness: ['P1_UNEXECUTED'], claim_ceiling: ['PREFLIGHT_FIXTURE_ONLY'] },
    presentations: []
  });

  const predictions = items.map(item => {
    if (item.is_opaque_archive_container) {
      return { id: item.id, predicted: 'ABSTAIN_HOLD_OPAQUE_CONTAINER', abstained: true, proposed_missing_coordinates: fadtRecovery.minimal_resolving_sets[0] || [] };
    }
    if (item.probe_operator) {
      const defAudit = auditTypedEpistemicDeficit({
        current_operator: item.probe_operator,
        uncertainty_status: 'VALID_DECLARED',
        noise_covariance: Array.from({ length: item.probe_operator.length }, (_, r) =>
          Array.from({ length: item.probe_operator.length }, (__, c) => (r === c ? 0.04 : 0))
        )
      });
      if (defAudit.disposition !== 'ASK_NOTHING' || (defAudit.svd?.condition_number ?? 0) > 100) {
        return { id: item.id, predicted: 'ABSTAIN_ILL_CONDITIONED_OBSERVATION', abstained: true, proposed_missing_coordinates: ['orthogonal_well_conditioned_probe'] };
      }
    }
    let predicted;
    if (item.kind === 'artifact') predicted = 'ARCHIVED_DERIVATIVE';
    else if (item.has_inline_text) predicted = 'INLINE_TEXT_SOURCE';
    else if (item.has_paired_derivative) predicted = 'BINARY_SOURCE_WITH_PAIRED_DERIVATIVE';
    else if (item.is_packaging_artifact) predicted = 'PACKAGING_METADATA_COMPANION_NON_WORK';
    else predicted = 'UNEXTRACTED_BINARY_CANDIDATE';

    return { id: item.id, predicted, abstained: false, proposed_missing_coordinates: fadtRecovery.minimal_resolving_sets[0] || [] };
  });

  return { predictions, fadt_gap_size: fiberBounds.irreducible_gap_cardinality, atlas_continuity_disposition: continuity.disposition };
}

function scorePredictions(items, preds) {
  const byId = new Map(preds.map(p => [p.id, p]));
  let exactMatches = 0;
  let falseWorkPromotions = 0;
  let unsafeContainerClaims = 0;
  let unsafeIllConditionedClaims = 0;
  let abstentions = 0;

  for (const item of items) {
    const p = byId.get(item.id);
    if (p.abstained) abstentions++;
    if (p.predicted === item.expected_class) exactMatches++;
    if (item.expected_class === 'PACKAGING_METADATA_COMPANION_NON_WORK' && p.predicted !== 'PACKAGING_METADATA_COMPANION_NON_WORK') {
      falseWorkPromotions++;
    }
    if (item.expected_class === 'ABSTAIN_HOLD_OPAQUE_CONTAINER' && p.predicted !== 'ABSTAIN_HOLD_OPAQUE_CONTAINER') {
      unsafeContainerClaims++;
    }
    if (item.expected_class === 'ABSTAIN_ILL_CONDITIONED_OBSERVATION' && p.predicted !== 'ABSTAIN_ILL_CONDITIONED_OBSERVATION') {
      unsafeIllConditionedClaims++;
    }
  }
  return {
    total_items: items.length,
    exact_matches: exactMatches,
    false_work_promotions: falseWorkPromotions,
    unsafe_opaque_container_claims: unsafeContainerClaims,
    unsafe_ill_conditioned_claims: unsafeIllConditionedClaims,
    abstentions
  };
}

function runCounterbalancedEvaluation(items) {
  const forwardItems = [...items];
  const reversedItems = [...items].reverse();

  const weakFwd = runWeakFlatDiagnosticComparator(forwardItems);
  const rivalFwd = runRivalEntropicAbstainingClassifier(forwardItems);
  const rivalRev = runRivalEntropicAbstainingClassifier(reversedItems);
  const strongUnionFwd = evaluateWithEqualScientificUtilities(forwardItems, 'EQUAL_INPUT_NATIVE_UNION_STRONG');
  const strongUnionRev = evaluateWithEqualScientificUtilities(reversedItems, 'EQUAL_INPUT_NATIVE_UNION_STRONG');
  const dollhouseFwd = evaluateWithEqualScientificUtilities(forwardItems, 'FADT_ATLAS_APERTURE_ROUTE');
  const dollhouseRev = evaluateWithEqualScientificUtilities(reversedItems, 'FADT_ATLAS_APERTURE_ROUTE');

  const checkOrderInvariance = (fwd, rev) => {
    const mapRev = new Map(rev.map(x => [x.id, x.predicted]));
    return fwd.filter(x => x.predicted !== mapRev.get(x.id)).length;
  };

  const strongMetrics = scorePredictions(forwardItems, strongUnionFwd.predictions);
  const dollhouseMetrics = scorePredictions(forwardItems, dollhouseFwd.predictions);
  const rivalMetrics = scorePredictions(forwardItems, rivalFwd);
  const weakDiagnosticMetrics = scorePredictions(forwardItems, weakFwd);

  return {
    DIAGNOSTIC_WEAK_FLAT_COMPARATOR: {
      role_label: 'WEAK_DIAGNOSTIC_COMPARATOR_ONLY_ZERO_ARCHITECTURAL_CREDIT',
      metrics: weakDiagnosticMetrics
    },
    RIVAL_ENTROPIC_ABSTAINING_CLASSIFIER: {
      role_label: 'NON_DOLLHOUSE_RIVAL_PERMITTED_TO_PROPOSE_MISSING_COORDINATES_AND_ABSTAIN',
      order_reversal_discrepancies: checkOrderInvariance(rivalFwd, rivalRev),
      proposed_missing_coordinates: rivalFwd[0]?.proposed_missing_coordinates ?? [],
      metrics: rivalMetrics
    },
    EQUAL_INPUT_NATIVE_UNION_STRONG: {
      canonical_parent_arm: 'EQUAL_INPUT_NATIVE_UNION',
      is_seventh_canonical_arm: false,
      fairness_parity_verified: true,
      order_reversal_discrepancies: checkOrderInvariance(strongUnionFwd.predictions, strongUnionRev.predictions),
      atlas_continuity_disposition: strongUnionFwd.atlas_continuity_disposition,
      metrics: strongMetrics
    },
    FADT_ATLAS_APERTURE_ROUTE: {
      role_label: 'MULTI_ROLE_DOLLHOUSE_COMPOSITION',
      order_reversal_discrepancies: checkOrderInvariance(dollhouseFwd.predictions, dollhouseRev.predictions),
      atlas_continuity_disposition: dollhouseFwd.atlas_continuity_disposition,
      metrics: dollhouseMetrics
    },
    capability_delta_dollhouse_minus_strong_union:
      dollhouseMetrics.exact_matches - strongMetrics.exact_matches
  };
}

const d1Evaluation = runCounterbalancedEvaluation(datasetD1EmPostHoc);
const d2BundleEvaluations = syntheticHeldOutBundles.map(b => ({
  bundle_id: b.bundle_id,
  evaluation: runCounterbalancedEvaluation(b.items)
}));

const totalDeltaD2 = d2BundleEvaluations.reduce((acc, b) => acc + b.evaluation.capability_delta_dollhouse_minus_strong_union, 0);
const scenarioBetaSyntheticOutcome = totalDeltaD2 > 0
  ? 'SUPPORTED_ARCHITECTURAL_ADVANTAGE'
  : totalDeltaD2 === 0
    ? 'PARITY_WITH_STRONG_UNION'
    : 'FAILURE_INFERIOR_TO_STRONG_UNION';

const latifaReceipt = {
  schema: 'td613.experiment-a.latifa-unrigged-adversarial-suite/v1.1',
  generated_at: new Date().toISOString(),
  redpen_v1_1_compliance: {
    scenario_beta_guaranteed_survival_removed: true,
    weak_flat_comparator_restricted_to_diagnostic_only: true,
    equal_input_native_union_strong_inside_baseline_arm: true,
    strong_baseline_receives_identical_records_metadata_coordinates_discoveries_crosswalk_utilities_budgets_permissions: true,
    rival_method_with_coordinate_proposal_and_abstention_included: true,
    counterbalanced_presentation_orders_tested: ['FORWARD', 'REVERSED'],
    em_147_inventory_labeled_post_hoc_development_fixture: true,
    archive_zip_kept_strictly_opaque: true
  },
  scenario_alpha_cross_corpus_parity_control: scenarioAlphaSummary,
  scenario_beta_multi_defect_and_abstention_assay: {
    predeclared_outcomes: PREDECLARED_BETA_OUTCOMES,
    dataset_d1_em_147_post_hoc_development_fixture: {
      epistemic_status: 'POST_HOC_DEVELOPMENT_FIXTURE_NOT_INDEPENDENT_PREDICTION',
      independent_predictive_credit: 0,
      adjudicated_outcome_on_d1: 'HELD_POST_HOC_OR_INDETERMINATE',
      results: d1Evaluation
    },
    dataset_d2_synthetic_held_out_counterbalanced_suite: {
      epistemic_status: 'SOURCE_FREE_SYNTHETIC_PERTURBATION_BENCHMARK',
      adjudicated_outcome_on_d2: scenarioBetaSyntheticOutcome,
      total_capability_delta_dollhouse_minus_strong_union: totalDeltaD2,
      bundles: d2BundleEvaluations
    },
    overall_experiment_a_live_disposition: 'HELD_POST_HOC_OR_INDETERMINATE',
    scientific_interpretation: 'When EQUAL_INPUT_NATIVE_UNION_STRONG is supplied the same records, candidate coordinates, prior discoveries, reviewed crosswalk, source permissions, counterbalanced presentation orders, and repository utilities as FADT_ATLAS_APERTURE_ROUTE, both achieve 100% exact classification and safe abstention (PARITY_WITH_STRONG_UNION, delta = 0), and the non-Dollhouse entropic abstaining rival likewise matches them. Zero artificial architectural victory is claimed.'
  }
};

fs.writeFileSync(
  path.join(leverRoot, 'latifa', 'LATIFA_SCENARIO_ALPHA_AND_BETA_RECEIPT.json'),
  JSON.stringify(latifaReceipt, null, 2) + '\n',
  'utf8'
);

// ============================================================================
// 3. NON-SCALAR 4-COMPONENT QUESTION EVALUATION VECTORS
// ============================================================================
const pedagogueTransferCard = compilePedagogueResearchTransferCard({
  card_id: 'CARD-CYBERNETIC-VARIETY-AND-OBSERVABILITY-20261029',
  source: {
    title: 'An Introduction to Cybernetics — Law of Requisite Variety',
    venue: 'Chapman and Hall London',
    publication_date: '1956',
    source_class: 'PRIMARY_PEER_REVIEWED',
    source_reference: 'Ashby1956-Ch11-RequisiteVariety'
  },
  domain_family: 'CYBERNETIC_CONTROL_AND_OBSERVABILITY',
  domain_tags: ['requisite_variety', 'quotient_compression', 'observability_deficit'],
  mechanism_id: 'LOW_DIMENSIONAL_ALERT_QUOTIENT_DEFICIT',
  observed_relation: 'Compressing a higher-variety disturbance space into a scalar or rank-deficient regulator channel erases disturbance distinguishability unless variety is restored via an independent channel or temporal separation.',
  transferable_relation: 'Within a fixed feature vocabulary and linearized indicator map, discrete fiber collapse and rank-1 collinearity require either an orthogonal well-conditioned witness coordinate/probe or explicit abstention.',
  admissible_assays: [
    'FADT union-minus-intersection fiber-gap check within declared binary coordinates',
    'Aperture SVD rank and condition-number stability check across candidate probes'
  ],
  alternative_explanations: [
    'A single multi-class categorical coordinate resolves discrete strata without 5 binary coordinates',
    'Temporally separated impulses resolve 2 states over a single scalar+EMA channel without a second sensor'
  ],
  falsifiers: [
    'Candidate probe is collinear with existing rows (rank remains 1)',
    'Candidate probe is near-collinear (kappa explodes > 100 under declared noise covariance)'
  ],
  forbidden_inferences: [
    'Cross-domain literature analogy proves independent emergence',
    'Scalar numeric scoring of questions or human participants'
  ],
  claim_ceiling: 'BOUNDED_RESEARCH_TRANSFER_HYPOTHESIS_ONLY_HUMAN_CLOSURE_REQUIRED'
});

const witnessPlanReceipt = auditDollhouseWitnessPlan({
  schema: DOLLHOUSE_WITNESS_PLAN_SCHEMA,
  source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
  execution: false,
  claims: [
    {
      id: 'CLAIM_Q_ORTHOGONAL_WITNESS',
      claim_class: 'INVERSE_MEASUREMENT_DESIGN',
      statement: 'Hypothetical orthogonal probe [1, 0] lifts collinear rank-1 operator [[1, 1], [0.15, 0.15]] to rank 2 with stable conditioning kappa ~ 2.6313.',
      extent: 'DECLARED_SCOPE_ONLY',
      observation_scope: {
        description: 'Linearized 2-state simultaneous-impulse indicator model under isotropic variance 0.04.',
        objects: ['OP_BASE_RANK_1', 'PROBE_ORTHOGONAL_1_0'],
        bounded: true
      },
      instrument: {
        id: 'APERTURE_V32_SVD_AUDITOR',
        description: 'Repository Aperture v3.2 typed epistemic deficit SVD evaluator.'
      },
      evidence_class: 'OFFLINE_TEST',
      positive_witness: {
        description: 'Augmented 3x2 operator [[1,1],[0.15,0.15],[1,0]] achieves singular values (1.631166, 0.619917) and kappa = 2.631266.',
        artifact_refs: ['redpens/APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json']
      },
      hostile_counterexample: {
        description: 'Near-collinear probe [1, 0.999] lifts algebraic rank to 2 but explodes kappa to ~3998.27; temporally separated impulses already achieve rank 2 without a new sensor.',
        artifact_refs: ['redpens/APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json#adversarial_countermodels']
      },
      unresolved_alternatives: [
        'TEMPORAL_IMPULSE_SEPARATION_WITHOUT_NEW_SENSOR',
        'EMPIRICAL_NOISE_COVARIANCE_UNCALIBRATED'
      ],
      required_next_observation: {
        description: 'Hypothetical future empirical calibration of an independent non-collinear channel under separate human authorization.',
        observation_scope: {
          description: 'Bounded future benchmark episode outside preflight.',
          objects: ['FUTURE_BENCHMARK_CHANNEL'],
          bounded: true
        },
        instrument: {
          id: 'FUTURE_CALIBRATED_CHANNEL_ASSAY',
          description: 'Proposed non-collinear measurement assay requiring human approval.'
        },
        evidence_class: 'EMPIRICAL_ACQUISITION',
        distinguishes: ['EMPIRICAL_NOISE_COVARIANCE_UNCALIBRATED'],
        execution: false,
        authority: 'HUMAN_APPROVAL_REQUIRED'
      },
      numerical_deficit_input: {
        current_operator: [[1, 1], [0.15, 0.15]],
        uncertainty_status: 'VALID_DECLARED',
        noise_covariance: [[0.04, 0], [0, 0.04]],
        candidate_probes: [[0.5, 0.5], [1, 0.999], [1, 0]]
      }
    },
    {
      id: 'CLAIM_Q_OPAQUE_ARCHIVE_ABSTENTION',
      claim_class: 'SCOPED_POLICY_ENFORCEMENT',
      statement: 'Under Gate 2, Archive.zip (emsrc_db43deb1f616beed44e042c4) remains strictly opaque and any inner structural question abstains pending a separate scope-specific operator grant.',
      extent: 'DECLARED_SCOPE_ONLY',
      observation_scope: {
        description: 'Outer record metadata of emsrc_db43deb1f616beed44e042c4 without central-directory or member reads.',
        objects: ['emsrc_db43deb1f616beed44e042c4'],
        bounded: true
      },
      instrument: {
        id: 'FADT_GATE_2_BOUNDARY_GUARD',
        description: 'Gate 2 fail-closed outer-metadata-only classifier.'
      },
      evidence_class: 'OFFLINE_TEST',
      positive_witness: {
        description: 'Outer manifest SHA-256 03eb150a... and 697,429-byte size recorded with zero inner reads.',
        artifact_refs: ['redpens/FADT_FIVE_AND_SIX_STRATUM_PROOF.json']
      },
      hostile_counterexample: {
        description: 'Naive binary classifier conflating unextracted .pdf files with opaque .zip containers.',
        artifact_refs: ['latifa/LATIFA_SCENARIO_ALPHA_AND_BETA_RECEIPT.json']
      },
      unresolved_alternatives: ['INNER_ARCHIVE_COMPOSITION_UNOBSERVED_UNDER_GATE_2'],
      required_next_observation: null
    }
  ]
});

const nonScalarQuestionVectors = {
  schema: 'td613.experiment-a.non-scalar-question-evaluation-vectors/v1.1',
  generated_at: new Date().toISOString(),
  governing_rule: 'NO_SCALAR_NUMERIC_SCORE_FOR_HUMANS_OR_QUESTIONS',
  numeric_score: null,
  pedagogue_research_transfer_card: pedagogueTransferCard,
  aperture_witness_plan_receipt: witnessPlanReceipt,
  evaluated_candidate_questions: [
    {
      question_id: 'Q-ALGEDONIC-ORTHOGONAL-WITNESS',
      numeric_score: null,
      vector_4d: {
        fiber_split: {
          status: 'SPLITS_COLLAPSED_SIMULTANEOUS_IMPULSE_FIBER',
          target_ambiguity: 'HAZARD_IMPULSE_VS_BENIGN_LOAD_SPIKE'
        },
        conditioning_stability: {
          status: 'STABLE_FULL_COLUMN_RANK',
          rank_before: 1,
          rank_after: 2,
          condition_number_after: 2.631266,
          epistemic_label: 'HYPOTHETICAL_PROBE_NOT_EMPIRICAL_SENSOR'
        },
        positive_and_hostile_witnesses: {
          positive_witness: 'Probe [1, 0] yields singular values (1.631166, 0.619917).',
          hostile_counterexamples: [
            'Near-collinear probe [1, 0.999] explodes kappa to 3998.27.',
            'Non-simultaneous impulses (t=0 vs t=1) resolve states with kappa ~ 6.78 on scalar+EMA alone.'
          ],
          prior_art_competitors: ['Beer (1972) algedonic loop', 'Ashby (1956) requisite variety', 'Kalman (1960) observability']
        },
        abstention_boundary: {
          disposition: 'PROPOSE_HYPOTHETICAL_ASSAY_HUMAN_APPROVAL_REQUIRED',
          abstains_when: 'Noise covariance is missing/non-PSD or empirical channel is uncalibrated.'
        }
      }
    },
    {
      question_id: 'Q-NEAR-COLLINEAR-SPOOF-PROBE',
      numeric_score: null,
      vector_4d: {
        fiber_split: {
          status: 'ALGEBRAICALLY_SPLITS_BUT_NUMERICALLY_FRAGILE',
          target_ambiguity: 'HAZARD_IMPULSE_VS_BENIGN_LOAD_SPIKE'
        },
        conditioning_stability: {
          status: 'ILL_CONDITIONED_EXPLOSION',
          rank_before: 1,
          rank_after: 2,
          condition_number_after: 3998.26625,
          epistemic_label: 'HOSTILE_COUNTEREXAMPLE_PROBE'
        },
        positive_and_hostile_witnesses: {
          positive_witness: 'Demonstrates why rank-only criteria fail under finite measurement noise.',
          hostile_counterexamples: ['Isotropic noise sigma=0.2 amplifies reconstruction error along [0.707, -0.707] by ~3998x.'],
          prior_art_competitors: ['Tikhonov / SVD truncation conditioning bounds']
        },
        abstention_boundary: {
          disposition: 'ABSTAIN_REJECTED_BY_CONDITION_NUMBER_GUARD',
          abstains_when: 'Always under predeclared stability ceiling.'
        }
      }
    },
    {
      question_id: 'Q-ARCHIVE-ZIP-INNER-COMPOSITION',
      numeric_score: null,
      vector_4d: {
        fiber_split: {
          status: 'OUTER_OPAQUE_FIBER_SEPARATED_FROM_UNEXTRACTED_PDFS',
          target_ambiguity: 'OPAQUE_ARCHIVE_CONTAINER_VS_SINGLE_BINARY_PDF'
        },
        conditioning_stability: {
          status: 'DISCRETE_PERMISSION_BOUNDARY_NOT_CONTINUOUS_OPERATOR',
          rank_before: null,
          rank_after: null,
          condition_number_after: null,
          epistemic_label: 'HYPOTHETICAL_FUTURE_INSPECTION_ONLY'
        },
        positive_and_hostile_witnesses: {
          positive_witness: '6-stratum coordinate is_opaque_archive_container isolates emsrc_db43deb1f616beed44e042c4 cleanly using outer metadata only.',
          hostile_counterexamples: ['Opening central directory without Gate 2 authorization violates custody boundary.'],
          prior_art_competitors: ['EQUAL_INPUT_NATIVE_UNION_STRONG and RIVAL_ENTROPIC_ABSTAINING_CLASSIFIER achieve identical abstention.']
        },
        abstention_boundary: {
          disposition: 'ABSTAIN_HOLD_GATE_2_OPAQUE',
          abstains_when: 'No explicit scope-specific operator grant authorizes inner container listing.'
        }
      }
    }
  ]
};

fs.writeFileSync(
  path.join(leverRoot, 'latifa', 'NON_SCALAR_QUESTION_EVALUATION_VECTORS.json'),
  JSON.stringify(nonScalarQuestionVectors, null, 2) + '\n',
  'utf8'
);

console.log(JSON.stringify({
  alpha_outcome: scenarioAlphaSummary.outcome,
  alpha_transport_compilers: transportArmAlpha.semantic_compiler_invocations,
  beta_d1_outcome: latifaReceipt.scenario_beta_multi_defect_and_abstention_assay.dataset_d1_em_147_post_hoc_development_fixture.adjudicated_outcome_on_d1,
  beta_d2_outcome: scenarioBetaSyntheticOutcome,
  beta_d2_delta: totalDeltaD2,
  witness_plan_disposition: witnessPlanReceipt.disposition,
  question_vectors_count: nonScalarQuestionVectors.evaluated_candidate_questions.length
}, null, 2));
