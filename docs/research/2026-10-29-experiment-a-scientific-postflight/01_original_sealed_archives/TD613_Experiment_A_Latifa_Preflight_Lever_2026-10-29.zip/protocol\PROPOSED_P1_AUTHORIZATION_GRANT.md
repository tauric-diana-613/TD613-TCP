# Proposed Source-Specific P1 Authorization (`TD613-P1-LIBRARY-CAPTURE-AND-LOCAL-ADOPTION-01`)

**Status**: `PROPOSED_UNEXECUTED · GATE_4_HELD · NEW_TD613_SOURCE_READS = 0`  
**Covenant**: Tauric Diana — Crimean heritage custodianship · `Khona‌lit-po` · Sealed `⟐`

## 1. Exact Target & Identity Boundaries
- **Target Object (`P1-LIBRARY-CAPTURE-PILOT-01`)**: `eclipse-omega-admissibility-regime.md` (`file_00000000e76c82308a97947d900f8752`, `libfile_267d1282fc6481918a07c2119b9c1f2a`), expected metadata length **40,418 bytes** (ceiling **65,536 bytes**, strict UTF-8).
- **Historical Equivalence (`HELD_UNVERIFIED`)**: Approving this pilot establishes a new exact content capture for a **labeled provisional functional pilot**; it does **not** certify equivalence to an unseen historical `P1` version.
- **`SRC-P1` Citation Record Distinction**: SHA-256 `81e4bc25cac1975c10a1347c1c3104c696cdb5f8f22023f1f2af9f25fdde7bf2` (Git blob `fbcc01e666d5257ba9d6599cff3c6ba91455230f` at `main` `700019741e708abfd2e53990fc2d8919995a70f1`) identifies the **retained `SRC-P1` citation JSON record only** (`app/encyclopedia/reference/records/SRC-P1.json`), **not** original manuscript bytes and **not** a Git commit containing historical `P1`.
- **Non-Substitutable Siblings**:
  - `P1C` (`P1C-OPERATOR-20261028-01`, **41,126 bytes**): distinct consumed object; never substituted or renewed.
  - `P2` (`file_00000000c578720cb029cae7ff4a7183` / `libfile_72a588974ce08191be606dc76dbaf06b`, **23,586 bytes**): unselected fallback; never auto-substituted by title or availability.

## 2. Exact Permissions Granted Only Upon Explicit Future Gate 4 Activation
1. **Object Fixation**: Bind strictly to `file_00000000e76c82308a97947d900f8752` and `libfile_267d1282fc6481918a07c2119b9c1f2a`; `HOLD` prior to access on any ambiguity.
2. **Single Capture & Digest Pin**: One materialization and one raw UTF-8 read (`expected = 40,418 B`, `max = 65,536 B`); zero automatic retries; pin all subsequent steps to the observed buffer SHA-256.
3. **Private Context Exposure Ceiling**: At most **2 passages**, $\le \mathbf{2,048}$ UTF-8 bytes per passage and $\le \mathbf{4,096}$ UTF-8 bytes total; labeled strictly as post-read exploratory judgment (never blind prediction); zero manuscript body text emitted into receipts.
4. **Reversible Nonpublic Recipient Adoption**: Import into newly provisioned empty local test instance `TD613-P1-CAPTURE-ATELIER-01` (`LOCAL_RESEARCH_IMPORT_UNVALIDATED`); verify `get`, `search`, `cite`, `verify` canaries across fresh process reopen and exact rollback to empty state.
5. **Disposable External Adapter**: At most two files (`pilot/td613-p1-local-adoption.mjs` and `.test.mjs`) outside all canonical source trees; never relabel real bytes as synthetic inside `RCP-2`/`RCP-2A`.
6. **Pre-Arm Parity Prerequisite**: Before claiming live 6-arm parity with Work's retained snapshot (`ee762380...`), either verify executable equivalence with `ee762380...` or obtain explicit operator election of the audited Git candidate (`441ce7e97...` / `70b1ac1d...`).
