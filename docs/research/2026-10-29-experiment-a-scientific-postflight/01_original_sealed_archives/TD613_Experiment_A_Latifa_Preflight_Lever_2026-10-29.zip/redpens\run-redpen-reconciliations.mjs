#!/usr/bin/env node
/**
 * TD613 Experiment A · Five-Redpen Mathematical & Forensic Reconciliations v1.1
 *
 * Enforces Gate 1 (R2 local reference), Gate 2 (Archive.zip strictly OPAQUE),
 * and Redpen v1.1 §3–§4 requirements across FADT, Aperture, Atlas, and Corpus.
 */

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const leverRoot = path.resolve(__dirname, '..');
const repoRoot = 'C:\\Users\\timst\\OneDrive\\Desktop\\tcp-repository';
const closureRoot = 'C:\\Users\\timst\\.gemini\\antigravity\\brain\\9f2d357f-af13-4730-b6c0-a1afe1416169\\scratch\\em_closure_20261029';

const sha256 = (b) => createHash('sha256').update(b).digest('hex');

const {
  computeMatrixSvd,
  auditTypedEpistemicDeficit
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'aperture-v32-typed-epistemic-deficit.js')).href);

const {
  computeFadtFiberBounds,
  evaluateFadtCoordinateRecovery
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'dollhouse-fadt-reparative-assistance.js')).href);

const {
  runAtlasContinuityAudit
} = await import(pathToFileURL(path.join(repoRoot, 'app', 'engine', 'dollhouse-continuity-audit.js')).href);

// ============================================================================
// 1. CORPUS & FADT FORENSIC RECONCILIATION (Gate 2: Archive.zip OPAQUE)
// ============================================================================
const recordsPath = path.join(closureRoot, 'em-corpus-transfer-20261028', 'instance', 'reference', 'records.ndjson');
const fallbackRecordsHtmlPath = path.join(closureRoot, 'candidate', 'instance', 'index.html');

let records = [];
if (fs.existsSync(recordsPath)) {
  records = fs.readFileSync(recordsPath, 'utf8').trim().split(/\r?\n/).filter(Boolean).map(l => JSON.parse(l));
} else {
  const html = fs.readFileSync(fallbackRecordsHtmlPath, 'utf8');
  const rawBlock = html.match(/<script[^>]*id="td613-reference-records"[^>]*>([\s\S]*?)<\/script>/)[1].trim();
  records = rawBlock.startsWith('[') ? JSON.parse(rawBlock) : rawBlock.split(/\r?\n/).filter(Boolean).map(l => JSON.parse(l));
}

// Build parent -> paired derivative map
const incomingDerivatives = new Map();
for (const r of records) {
  if (r.kind === 'artifact' && Array.isArray(r.links)) {
    for (const l of r.links) {
      const target = typeof l === 'string' ? l : (l.target || l.id);
      if (target) {
        if (!incomingDerivatives.has(target)) incomingDerivatives.set(target, []);
        incomingDerivatives.get(target).push(r.id);
      }
    }
  }
}

// Map corpus files on disk ONLY for non-Archive.zip AppleDouble 4-byte magic verification;
// Gate 2 strictly forbids opening, listing central directory, or extracting Archive.zip!
const corpusRoot = path.join(closureRoot, 'candidate', 'instance', 'corpus');
const diskBySha = new Map();
function indexCorpusFiles(dir) {
  if (!fs.existsSync(dir)) return;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      indexCorpusFiles(full);
    } else if (ent.name !== 'Archive.zip') {
      const buf = fs.readFileSync(full);
      diskBySha.set(sha256(buf), { full, magic4_hex: buf.subarray(0, 4).toString('hex'), bytes: buf.length });
    }
  }
}
indexCorpusFiles(corpusRoot);

const markdownSources = [];
const appleDoubleSidecars = [];
const pdfWithDerivatives = [];
const unpairedPdfs = [];
const unpairedArchiveContainers = [];
const archivedDerivatives = [];

for (const r of records) {
  const hasInlineBody = typeof r.record?.body === 'string' && r.record.body.length > 0;
  const srcMeta = r.record?.source || r.record?.derivative || {};
  const relPath = srcMeta.archive_relative_path || r.record?.raw_bytes_path || r.label || '';
  const baseName = path.posix.basename(relPath.replace(/\\/g, '/'));
  const recSha = srcMeta.sha256 || r.record?.sha256 || r.sha256 || null;
  const recBytes = srcMeta.byte_length ?? r.record?.bytes ?? r.bytes ?? null;
  const mediaType = srcMeta.media_type || null;
  const workRelation = r.record?.work_association?.relation || null;
  const companionSourceId = r.record?.work_association?.evidence?.companion_source_file_id || null;

  if (r.kind === 'artifact') {
    archivedDerivatives.push({
      id: r.id,
      label: r.label,
      parent_source_id: r.record?.parent_source_id || null,
      sha256: recSha,
      bytes: recBytes
    });
  } else if (r.kind === 'source') {
    if (hasInlineBody) {
      markdownSources.push({
        id: r.id,
        label: r.label,
        basename: baseName,
        archive_relative_path: relPath,
        media_type: mediaType,
        work_relation: workRelation,
        sha256: recSha,
        bytes: recBytes
      });
    } else if ((incomingDerivatives.get(r.id) || []).length > 0) {
      pdfWithDerivatives.push({
        id: r.id,
        label: r.label,
        basename: baseName,
        archive_relative_path: relPath,
        media_type: mediaType,
        work_relation: workRelation,
        sha256: recSha,
        bytes: recBytes,
        derivative_count: incomingDerivatives.get(r.id).length
      });
    } else if (baseName.startsWith('._')) {
      const diskInfo = recSha ? diskBySha.get(recSha) : null;
      appleDoubleSidecars.push({
        id: r.id,
        label: r.label,
        basename: baseName,
        target_markdown_basename: baseName.slice(2),
        archive_relative_path: relPath,
        media_type: mediaType,
        work_relation: workRelation,
        manifest_companion_source_file_id: companionSourceId,
        sha256: recSha,
        bytes: recBytes ?? diskInfo?.bytes ?? null,
        magic_signature_hex: diskInfo?.magic4_hex ?? null,
        is_verified_appledouble_00051607: diskInfo?.magic4_hex === '00051607'
      });
    } else if (baseName.toLowerCase().endsWith('.zip')) {
      // Gate 2: ONLY outer admitted record attributes! Zero inner/central-directory read!
      unpairedArchiveContainers.push({
        id: r.id,
        label: r.label,
        basename: baseName,
        archive_relative_path: relPath,
        outer_media_type: mediaType,
        work_relation: workRelation,
        outer_recorded_sha256: recSha,
        outer_recorded_bytes: recBytes,
        gate_2_posture: 'STRICTLY_OPAQUE_NO_CENTRAL_DIRECTORY_OR_INNER_READ_PERFORMED',
        hypothetical_future_operation: 'CENTRAL_DIRECTORY_OR_MEMBER_INSPECTION_REQUIRES_SEPARATE_SCOPE_SPECIFIC_OPERATOR_GRANT',
        independent_manuscript_interpretation_claimed: false
      });
    } else {
      unpairedPdfs.push({
        id: r.id,
        label: r.label,
        basename: baseName,
        archive_relative_path: relPath,
        media_type: mediaType,
        work_relation: workRelation,
        sha256: recSha,
        bytes: recBytes,
        support_caveat: 'Outer .pdf extension / record metadata does not certify full page/math extractability or authorial meaning.'
      });
    }
  }
}

// Pair each AppleDouble sidecar to its exact Markdown record
const mdByBase = new Map(markdownSources.map(m => [m.basename, m]));
for (const s of appleDoubleSidecars) {
  const match = mdByBase.get(s.target_markdown_basename);
  s.paired_markdown_record_id = match ? match.id : null;
}

// 5-Stratum Model (all 15 non-empty subsets)
const rows5Strata = [
  {
    id: 'TEXT_MANUSCRIPTS_33',
    coordinates: { kind: 'source', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'INLINE_PRIMARY_BODY_LEXICAL_SEARCH', 'PRIMARY_SOURCE_PROJECTION']
  },
  {
    id: 'PDF_WITH_DERIVATIVE_20',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: true, is_packaging_artifact: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PAIRED_DERIVATIVE_TRAVERSAL', 'PRIMARY_SOURCE_PROJECTION', 'BINARY_SOURCE_CANDIDATE_INSPECTION']
  },
  {
    id: 'APPLEDOUBLE_SIDECARS_33',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: true },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PRIMARY_SOURCE_PROJECTION', 'PACKAGING_COMPANION_CLASSIFICATION']
  },
  {
    id: 'UNPAIRED_SUBSTANTIVE_BINARIES_8',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PRIMARY_SOURCE_PROJECTION', 'BINARY_SOURCE_CANDIDATE_INSPECTION']
  },
  {
    id: 'ARCHIVED_DERIVATIVES_53',
    coordinates: { kind: 'artifact', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'INLINE_DERIVATIVE_BODY_LEXICAL_SEARCH', 'PARENT_SOURCE_CITATION_TRAVERSAL']
  }
];
const fadt5Recovery = evaluateFadtCoordinateRecovery(
  rows5Strata,
  ['kind', 'has_inline_text', 'has_paired_derivative', 'is_packaging_artifact']
);

// 6-Stratum Adversarial Split separating 7 unextracted PDFs from 1 opaque Archive.zip (all 31 non-empty subsets)
const rows6Strata = [
  {
    id: 'TEXT_MANUSCRIPTS_33',
    coordinates: { kind: 'source', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'INLINE_PRIMARY_BODY_LEXICAL_SEARCH', 'PRIMARY_SOURCE_PROJECTION']
  },
  {
    id: 'PDF_WITH_DERIVATIVE_20',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: true, is_packaging_artifact: false, is_opaque_archive_container: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PAIRED_DERIVATIVE_TRAVERSAL', 'PRIMARY_SOURCE_PROJECTION', 'CANDIDATE_PDF_EXTRACTION_UNVERIFIED_FIDELITY']
  },
  {
    id: 'APPLEDOUBLE_SIDECARS_33',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: true, is_opaque_archive_container: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PRIMARY_SOURCE_PROJECTION', 'PACKAGING_COMPANION_CLASSIFICATION']
  },
  {
    id: 'UNPAIRED_RESEARCH_PDFS_7',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PRIMARY_SOURCE_PROJECTION', 'CANDIDATE_PDF_EXTRACTION_UNVERIFIED_FIDELITY']
  },
  {
    id: 'OPAQUE_ARCHIVE_CONTAINER_1',
    coordinates: { kind: 'source', has_inline_text: false, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: true },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'PRIMARY_SOURCE_PROJECTION', 'HOLD_OPAQUE_CONTAINER_REQUIRES_FUTURE_SCOPE_GRANT']
  },
  {
    id: 'ARCHIVED_DERIVATIVES_53',
    coordinates: { kind: 'artifact', has_inline_text: true, has_paired_derivative: false, is_packaging_artifact: false, is_opaque_archive_container: false },
    support: ['EXACT_ID_GET', 'SHA256_VERIFY', 'METADATA_SEARCH', 'INLINE_DERIVATIVE_BODY_LEXICAL_SEARCH', 'PARENT_SOURCE_CITATION_TRAVERSAL']
  }
];
const fadt6Recovery = evaluateFadtCoordinateRecovery(
  rows6Strata,
  ['kind', 'has_inline_text', 'has_paired_derivative', 'is_packaging_artifact', 'is_opaque_archive_container']
);
const pdfVsZipFiberBounds = computeFadtFiberBounds([rows6Strata[3], rows6Strata[4]]);

// Required Negative Control: 6-Class Single Categorical Variable Counterexample
const rows6CategoricalControl = rows6Strata.map((row, idx) => ({
  id: row.id,
  coordinates: {
    stratum_categorical_code: `CLASS_${idx}_${row.id}`,
    redundant_constant: 'ALL_RECORDS'
  },
  support: row.support
}));
const categoricalNegativeControl = evaluateFadtCoordinateRecovery(
  rows6CategoricalControl,
  ['stratum_categorical_code', 'redundant_constant']
);

const fadtReceipt = {
  schema: 'td613.experiment-a.fadt-corpus-and-minimality-reconciliation/v1.1',
  generated_at: new Date().toISOString(),
  engine_source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
  corpus_accounting: {
    total_preserved_records: records.length,
    markdown_manuscripts_count: markdownSources.length,
    appledouble_metadata_companions_count: appleDoubleSidecars.length,
    appledouble_00051607_verified_count: appleDoubleSidecars.filter(s => s.is_verified_appledouble_00051607).length,
    appledouble_markdown_basename_paired_count: appleDoubleSidecars.filter(s => s.paired_markdown_record_id !== null).length,
    pdfs_with_paired_derivatives_count: pdfWithDerivatives.length,
    unextracted_pdfs_count: unpairedPdfs.length,
    opaque_archive_containers_count: unpairedArchiveContainers.length,
    archived_text_derivatives_count: archivedDerivatives.length,
    exact_sum_check:
      markdownSources.length +
      appleDoubleSidecars.length +
      pdfWithDerivatives.length +
      unpairedPdfs.length +
      unpairedArchiveContainers.length +
      archivedDerivatives.length
  },
  support_assumptions_and_limits: [
    'Presence of a filename extension (.pdf, .md, .zip) or 4-byte magic signature (00051607) does NOT prove full text/equation extractability or authorial meaning.',
    'Per Gate 2 (Amari override), Archive.zip (emsrc_db43deb1f616beed44e042c4) remained strictly OPAQUE: zero central-directory listing, extraction, or inner-byte inspection occurred.',
    'Coordinate necessity claims (4 coordinates for 5 strata; 5 coordinates for 6 strata) hold ONLY within the declared binary/kind feature vocabulary, NOT globally across arbitrary encodings.'
  ],
  provenance_tables: {
    appledouble_33_sidecars: appleDoubleSidecars,
    unextracted_7_pdfs: unpairedPdfs,
    opaque_1_archive_container: unpairedArchiveContainers
  },
  five_stratum_four_coordinate_proof: {
    scope: 'MINIMAL_WITHIN_DECLARED_4_FEATURE_VOCABULARY_ONLY',
    total_nonempty_subsets_evaluated: fadt5Recovery.total_evaluations,
    minimal_resolving_sets: fadt5Recovery.minimal_resolving_sets,
    all_15_subset_evaluations: fadt5Recovery.evaluations
  },
  six_stratum_adversarial_pdf_vs_zip_split: {
    scope: 'MINIMAL_WITHIN_DECLARED_5_FEATURE_VOCABULARY_ONLY',
    pdf_vs_zip_collapsed_fiber_gap: pdfVsZipFiberBounds,
    total_nonempty_subsets_evaluated: fadt6Recovery.total_evaluations,
    minimal_resolving_sets: fadt6Recovery.minimal_resolving_sets,
    all_31_subset_evaluations: fadt6Recovery.evaluations
  },
  single_categorical_variable_negative_control: {
    purpose: 'Refutes universal/encoding-independent coordinate-count minimality: 1 categorical variable with 6 values resolves all 6 operational strata.',
    total_nonempty_subsets_evaluated: categoricalNegativeControl.total_evaluations,
    minimal_resolving_sets: categoricalNegativeControl.minimal_resolving_sets,
    resolving_coordinate_cardinality: categoricalNegativeControl.minimal_resolving_sets[0].length,
    information_theoretic_lower_bound_bits: Math.ceil(Math.log2(rows6Strata.length)),
    evaluations: categoricalNegativeControl.evaluations
  }
};

fs.writeFileSync(
  path.join(leverRoot, 'redpens', 'FADT_FIVE_AND_SIX_STRATUM_PROOF.json'),
  JSON.stringify(fadtReceipt, null, 2) + '\n',
  'utf8'
);

// ============================================================================
// 2. APERTURE SVD RECONCILIATION & ADVERSARIAL DYNAMICAL MODELS
// ============================================================================
const opBaseRank1 = [[1, 1], [0.15, 0.15]];
const opDisplayed2x2 = [[1, 0.5], [0.2, 0.8]];
const opAugmented3x2 = [[1, 1], [0.15, 0.15], [1, 0]];
const opNearCollinear3x2 = [[1, 1], [0.15, 0.15], [1, 0.999]];
const opTemporallySeparated2x2 = [[1, 0], [0.15 * 0.85, 0.15]]; // Hazard at t=0, benign spike at t=1

const deficitAuditWithAdversarialProbes = auditTypedEpistemicDeficit({
  current_operator: opBaseRank1,
  uncertainty_status: 'VALID_DECLARED',
  noise_covariance: [[0.04, 0.0], [0.0, 0.04]],
  candidate_probes: [
    [0.5, 0.5],   // Redundant scalar filter (remains rank 1)
    [1.0, 0.999], // Adversarial near-collinear sensor (algebraic rank 2, conditioning explodes kappa ~ 3998.27)
    [1.0, 0.0]    // Hypothetical orthogonal witness (rank 2, well-conditioned kappa ~ 2.631266)
  ]
});

const apertureReceipt = {
  schema: 'td613.experiment-a.aperture-svd-reconciliation/v1.1',
  generated_at: new Date().toISOString(),
  engine_source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
  empirical_sensor_witnesses_claimed: 0,
  independent_sensor_epistemic_label: 'HYPOTHETICAL_MEASUREMENT_DESIGN_NOT_OBSERVED_EMPIRICAL_SENSOR',
  matrix_reconciliation_correction: {
    error_corrected: 'Prior post-compaction summary attached the 3x2 augmented singular values (1.631166, 0.619917, kappa=2.631266) to a distinct 2x2 matrix [[1, 0.5], [0.2, 0.8]]. Both matrices are here separately evaluated and reconciled.',
    base_collinear_2x2: {
      matrix: opBaseRank1,
      svd: computeMatrixSvd(opBaseRank1)
    },
    displayed_2x2_example: {
      matrix: opDisplayed2x2,
      svd: computeMatrixSvd(opDisplayed2x2)
    },
    earlier_augmented_3x2_example: {
      matrix: opAugmented3x2,
      epistemic_label: 'HYPOTHETICAL_THIRD_ROW_WITNESS',
      svd: computeMatrixSvd(opAugmented3x2)
    }
  },
  adversarial_countermodels: {
    near_collinear_conditioning_explosion: {
      description: 'Algebraic rank lifts from 1 to 2, refuting naive rank-only adequacy because numerical condition number explodes to ~3998.27.',
      matrix: opNearCollinear3x2,
      epistemic_label: 'HYPOTHETICAL_ILL_CONDITIONED_SENSOR',
      svd: computeMatrixSvd(opNearCollinear3x2)
    },
    temporally_separated_impulses_scalar_ema: {
      description: 'When hazard impulse occurs at t=0 and benign spike at t=1 (non-collocated in time), the two-step scalar/EMA trajectory alone achieves full rank 2 (kappa ~ 6.7775), bounding the rank-1 collapse strictly to simultaneous/proportional excitation.',
      matrix: opTemporallySeparated2x2,
      svd: computeMatrixSvd(opTemporallySeparated2x2)
    }
  },
  typed_epistemic_deficit_probe_ranking: deficitAuditWithAdversarialProbes
};

fs.writeFileSync(
  path.join(leverRoot, 'redpens', 'APERTURE_SVD_RECONCILIATION_AND_COUNTERMODELS.json'),
  JSON.stringify(apertureReceipt, null, 2) + '\n',
  'utf8'
);

// ============================================================================
// 3. ATLAS R1 -> R2 PRESENTATION SEAM RECONCILIATION
// ============================================================================
const r1Html = fs.readFileSync(path.join(closureRoot, 'candidate', 'instance', 'index.html'));
const r2Html = fs.readFileSync(path.join(closureRoot, 'candidate-r2-contrast-repaired', 'instance', 'index.html'));
const r1Str = r1Html.toString('utf8');
const r2Str = r2Html.toString('utf8');

const themeStartTag = '<style id="manifest-instance-theme">';
const r1Start = r1Str.indexOf(themeStartTag);
const r2Start = r2Str.indexOf(themeStartTag);
const r1End = r1Str.indexOf('</style>', r1Start) + '</style>'.length;
const r2End = r2Str.indexOf('</style>', r2Start) + '</style>'.length;

const prefixIdentical = r1Str.slice(0, r1Start) === r2Str.slice(0, r2Start);
const suffixIdentical = r1Str.slice(r1End) === r2Str.slice(r2End);

const atlasContinuity = runAtlasContinuityAudit({
  origin: {
    id: 'EM_ACCEPTED_COMPARATOR_b9e5e16b',
    source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
    original_ref: 'sha256:b9e5e16b2f73e940beaec544fc93610a11a62774aa6134871d7dfb9efb71912b',
    current_ref: 'sha256:b9e5e16b2f73e940beaec544fc93610a11a62774aa6134871d7dfb9efb71912b',
    predecessor_ref: null,
    selected_commitments: [{ id: 'CORPUS_147', commitment: 'sha256:a3504cc88cedbd37b1230afca3b11e9cf796b43f8968be9d9d3edf5dd8e7ee86' }],
    policy_commitment: 'EM_PRIVATE_LOCAL_RECEIVER_ZERO_GENERATED_CLAIMS',
    missingness: ['P1_REVERSE_SOURCE_UNEXECUTED', 'EMPIRICAL_REPLICATION_ABSENT'],
    claim_ceiling: ['FINITE_PRESERVATION_AND_PRESENTATION_ONLY']
  },
  previous: {
    id: 'WORK_R1_10b48fa9',
    source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
    original_ref: 'sha256:b9e5e16b2f73e940beaec544fc93610a11a62774aa6134871d7dfb9efb71912b',
    current_ref: 'sha256:10b48fa947158b8f16aedc8391a2fa56f101f008a275da2999ef507788a7ad03',
    predecessor_ref: 'sha256:b9e5e16b2f73e940beaec544fc93610a11a62774aa6134871d7dfb9efb71912b',
    selected_commitments: [{ id: 'CORPUS_147', commitment: 'sha256:a3504cc88cedbd37b1230afca3b11e9cf796b43f8968be9d9d3edf5dd8e7ee86' }],
    policy_commitment: 'EM_PRIVATE_LOCAL_RECEIVER_ZERO_GENERATED_CLAIMS',
    missingness: ['P1_REVERSE_SOURCE_UNEXECUTED', 'EMPIRICAL_REPLICATION_ABSENT'],
    claim_ceiling: ['FINITE_PRESERVATION_AND_PRESENTATION_ONLY']
  },
  current: {
    id: 'KENOUGH_R2_a1009bf5',
    source_revision: '700019741e708abfd2e53990fc2d8919995a70f1',
    original_ref: 'sha256:b9e5e16b2f73e940beaec544fc93610a11a62774aa6134871d7dfb9efb71912b',
    current_ref: 'sha256:a1009bf56d17c663aea8d3df75228bb9c0ee90b4081a31b0fe19c70101b36996',
    predecessor_ref: 'sha256:10b48fa947158b8f16aedc8391a2fa56f101f008a275da2999ef507788a7ad03',
    selected_commitments: [{ id: 'CORPUS_147', commitment: 'sha256:a3504cc88cedbd37b1230afca3b11e9cf796b43f8968be9d9d3edf5dd8e7ee86' }],
    policy_commitment: 'EM_PRIVATE_LOCAL_RECEIVER_ZERO_GENERATED_CLAIMS',
    missingness: ['P1_REVERSE_SOURCE_UNEXECUTED', 'EMPIRICAL_REPLICATION_ABSENT'],
    claim_ceiling: ['FINITE_PRESERVATION_AND_PRESENTATION_ONLY']
  },
  presentations: []
});

const atlasReceipt = {
  schema: 'td613.experiment-a.atlas-presentation-seam-reconciliation/v1.1',
  generated_at: new Date().toISOString(),
  relation_classification: 'CONTENT_INVARIANT_PRESENTATION_TRANSFORMATION',
  gauge_transformation_status: 'SUGGESTIVE_ANALOGY_ONLY_NOT_STRICT_PHYSICAL_GAUGE_INVARIANCE',
  why_not_strict_gauge: 'Strict gauge transformations preserve physical observables, whereas R1->R2 deliberately alters human-facing visual contrast observability while holding corpus/runtime bytes outside manifest-instance-theme invariant.',
  gate_1_status: 'R2_ADOPTED_AS_PREFERRED_PRIVATE_LOCAL_EM_REFERENCE_AESTHETIC_AND_SCIENTIFIC_RESERVED',
  separate_evidence_classes: {
    byte_and_hash_verification: {
      r1_sha256: sha256(r1Html),
      r2_sha256: sha256(r2Html),
      r1_bytes: r1Html.length,
      r2_bytes: r2Html.length,
      theme_block_byte_delta: r2Html.length - r1Html.length,
      prefix_outside_theme_byte_identical: prefixIdentical,
      suffix_outside_theme_byte_identical: suffixIdentical
    },
    browser_visual_observation_correction: {
      retired_erroneous_prose: 'Retires post-compaction prose describing R1 defect as white-on-white or R2 as slate-on-near-white.',
      verified_screenshot_and_computed_style_fact: 'Within Em Baker-Miller pink (#FF91AF) reading architecture, R1 Terms select controls rendered graphite text (#24282A) on graphite background (#24282A, 1.00:1) alongside low-contrast subtitles (#F6F4F0/#667078 on #FF91AF); R2 repairs select controls to graphite (#24282A) on porcelain (#F6F4F0, 13.54:1) and body/subtitle hierarchy to graphite (#24282A) on Baker-Miller pink (#FF91AF, 7.03:1).'
    }
  },
  atlas_continuity_audit_receipt: atlasContinuity
};

fs.writeFileSync(
  path.join(leverRoot, 'redpens', 'ATLAS_PRESENTATION_SEAM_RECONCILIATION.json'),
  JSON.stringify(atlasReceipt, null, 2) + '\n',
  'utf8'
);

console.log(JSON.stringify({
  corpus_total: fadtReceipt.corpus_accounting.total_preserved_records,
  appledouble_verified: fadtReceipt.corpus_accounting.appledouble_00051607_verified_count,
  appledouble_paired: fadtReceipt.corpus_accounting.appledouble_markdown_basename_paired_count,
  fadt_5_subsets: fadtReceipt.five_stratum_four_coordinate_proof.total_nonempty_subsets_evaluated,
  fadt_6_subsets: fadtReceipt.six_stratum_adversarial_pdf_vs_zip_split.total_nonempty_subsets_evaluated,
  categorical_control_min_coords: fadtReceipt.single_categorical_variable_negative_control.resolving_coordinate_cardinality,
  svd_2x2_kappa: apertureReceipt.matrix_reconciliation_correction.displayed_2x2_example.svd.condition_number,
  svd_3x2_kappa: apertureReceipt.matrix_reconciliation_correction.earlier_augmented_3x2_example.svd.condition_number,
  atlas_theme_delta_bytes: atlasReceipt.separate_evidence_classes.byte_and_hash_verification.theme_block_byte_delta,
  atlas_prefix_suffix_identical: prefixIdentical && suffixIdentical
}, null, 2));
