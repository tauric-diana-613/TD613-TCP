#!/usr/bin/env node
/**
 * TD613 Experiment A — Stage W0 Evidence Sealer
 *
 * Computes deterministic SHA-256 checksums for all W0 execution artifacts,
 * writes POSTFLIGHT_W0_CHECKSUMS.sha256, and creates the immutable sealed package:
 *   scratch/TD613_Experiment_A_Postflight_W0_Evidence_2026-10-29.zip
 */

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const w0Root = __dirname;
const scratchRoot = path.resolve(w0Root, '..');
const zipPath = path.join(scratchRoot, 'TD613_Experiment_A_Postflight_W0_Evidence_2026-10-29.zip');

const sha256 = (b) => createHash('sha256').update(b).digest('hex');

function getAllFiles(dir, base = '') {
  let results = [];
  const list = fs.readdirSync(dir, { withFileTypes: true });
  for (const item of list) {
    if (item.name === 'POSTFLIGHT_W0_CHECKSUMS.sha256') continue;
    const full = path.join(dir, item.name);
    const rel = base ? `${base}/${item.name}` : item.name;
    if (item.isDirectory()) {
      results = results.concat(getAllFiles(full, rel));
    } else if (item.isFile()) {
      results.push(rel);
    }
  }
  return results.sort();
}

console.log('[W0 Sealer] Collecting Stage W0 execution and verification artifacts...');
const allFiles = getAllFiles(w0Root);

const lines = [];
for (const rel of allFiles) {
  const full = path.join(w0Root, rel);
  const buf = fs.readFileSync(full);
  const hash = sha256(buf);
  lines.push(`${hash}  ${rel}`);
}

const checksumPath = path.join(w0Root, 'POSTFLIGHT_W0_CHECKSUMS.sha256');
fs.writeFileSync(checksumPath, lines.join('\n') + '\n', 'utf8');
console.log(`[W0 Sealer] Wrote ${lines.length} checksums to POSTFLIGHT_W0_CHECKSUMS.sha256`);

// Create ZIP using tar
console.log('[W0 Sealer] Creating sealed ZIP archive...');
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

const tarCmd = `tar -a -cf "${zipPath}" *`;
execSync(tarCmd, { cwd: w0Root, encoding: 'utf8' });

const zipStat = fs.statSync(zipPath);
const zipSha = sha256(fs.readFileSync(zipPath));

console.log('\n======================================================');
console.log('EXPERIMENT A STAGE W0 EVIDENCE SEALED');
console.log(`Archive: ${zipPath}`);
console.log(`Size: ${zipStat.size} bytes`);
console.log(`SHA-256: ${zipSha}`);
console.log(`Artifact count: ${lines.length + 1}`);
console.log('======================================================\n');
