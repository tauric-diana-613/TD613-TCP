# **Architecture and Implementation of a 128-Step Hybrid Tracker Engine in Mixxx**

The evolution of digital live performance has increasingly blurred the demarcation between traditional track-based DJing and real-time electronic music production. Open-source platforms, notably Mixxx, have historically relied on a paradigm of deck-based track mixing supplemented by one-shot or looping sample playback capabilities via an internal sampler engine. However, modern performance workflows demand dynamic, generative, and highly sequenced capabilities traditionally reserved for dedicated digital audio workstations or hardware grooveboxes.  
This report provides an exhaustive technical investigation into the architecture and design requirements necessary to embed a real-time, low-latency 128-step hybrid tracker sequencing engine directly into the Mixxx audio pipeline. The objective is to augment or replace traditional sampler and cue triggers with dynamic MIDI and step-based sequences. Achieving this requires solving multiple concurrent engineering challenges: adhering to strict real-time C++ audio engine constraints, modeling a memory-efficient data structure for multi-lane polyrhythmic tracking, managing dual-domain timing encompassing metric beats and absolute milliseconds, and providing a low-latency bidirectional programmatic interface suitable for autonomous generation agents and algorithmic scripts.

## **Architectural Analysis of Open-Source Tracker Paradigms**

To formulate a robust tracker architecture within the Mixxx ecosystem, it is critical to evaluate the design paradigms of existing open-source tracker implementations. Historically, tracker software represents musical data not as continuous piano rolls, but as discrete, time-quantized events arranged in vertical lanes and horizontal rows.

### **Legacy Formats: ProTracker and MilkyTracker**

Legacy tracker formats, such as MOD (ProTracker) and XM (FastTracker II), established the foundational matrix data structure for sequenced audio. These formats typically limit patterns to a fixed 64 rows, utilizing rigid columnar layouts to represent channels. A standard MOD file structures its pattern data sequentially, often utilizing strict 4-channel limits and relying on embedded instrument headers and sample data within a MOD\_HEADER struct. MilkyTracker, an open-source XM and MOD tracker, continues this legacy, supporting the FastTracker II architecture and providing a highly memory-efficient execution environment.  
While these formats are easily parsed, their architectural limitations—such as a lack of independent track lengths, rigid subdivisions, and the absence of native polymetric support—render them insufficient for modern generative workflows. Furthermore, libraries like libmodplug provide C/C++ implementations for playing back these legacy formats. However, integrating libmodplug directly into a modern DJ engine introduces complexities, as it is primarily designed to consume pre-compiled, static files rather than allowing real-time, per-step injection of events from external generative agents or algorithms.

### **SunVox Modular Architecture**

SunVox offers a highly optimized, contemporary approach to modular synthesis and tracking. The SunVox engine is decoupled from its graphical interface, allowing it to function as a lightweight library capable of generative and microtonal playback across multiple platforms.  
The SunVox data structure provides excellent architectural references for a modern tracker. SunVox files use an IFF-style (Interchange File Format) container, streaming chunks of data identified by 4-byte ASCII strings. Crucially, SunVox optimizes its internal pattern data by utilizing an 8-byte structure for each note event. This structure allows for extreme memory density and rapid execution during the audio callback. SunVox also supports "automation patterns" utilizing note data with a velocity of zero to target specific synthesizer parameters, an approach conceptually identical to modern parameter locks.

| Tracker Implementation | Core Data Structure | Row/Step Limitations | Execution Paradigm | Extensibility for Generative AI |
| :---- | :---- | :---- | :---- | :---- |
| **ProTracker (MOD)** | 4-channel fixed matrix, embedded MOD\_HEADER. | Fixed 64 rows per pattern. | Static file buffer playback. | Extremely Low; relies on pre-compiled rigid matrices. |
| **MilkyTracker (XM)** | Multi-channel matrix, instrument envelopes. | Highly rigid global step limits. | Static file buffer playback. | Low; not designed for real-time per-step external injection. |
| **SunVox** | IFF-style chunks, 8-byte per-note event struct. | Flexible, dynamic pattern lengths. | Modular DSP pipeline, library API. | High; API supports granular control, though requires C wrapper. |
| **Proposed Mixxx Tracker** | 16-byte lock-free aligned step struct, independent lanes. | 128 steps per lane, independent polyrhythms. | SPSC Lock-free FIFO into real-time thread. | Maximum; designed natively for JS/LLM bidirectional payload injection. |

### **Architectural Derivations for the Mixxx Engine**

Comparing these engines yields several uncompromising design imperatives for the Mixxx hybrid tracker. First, the sequence data must be cache-aligned, ideally using an 8-byte or 16-byte step structure, to ensure the real-time audio thread avoids cache misses during sequence parsing. Second, the engine must support independent lane lengths up to 128 steps rather than fixed global matrices, enabling true polyrhythms. Finally, the timing engine must decouple the step progression from fixed tracker ticks, instead tying it directly to Mixxx's floating-point beat distance metrics to ensure synchronization with the DJ performance.

## **Tracker Data Structure and Data-Oriented Design**

The core of the generative sequencing engine requires a data model capable of representing 128 steps per lane, with individual metric subdivisions reaching up to 1/64th notes. This data model must reside entirely in memory pre-allocated for the real-time audio thread. Heap allocations, such as new, malloc, or std::vector::push\_back, during the audio callback are strictly prohibited to avoid priority inversion and catastrophic audio dropouts.

### **Memory-Efficient Step Model**

To accommodate advanced sequencing techniques—such as parameter locks (p-locks), triggering probabilities, and micro-timing offsets—the step structure is designed using a strict 16-byte alignment. This alignment guarantees that two sequential steps fit precisely into a standard 32-byte CPU cache line, or four steps into a 64-byte cache line, maximizing memory throughput and preventing cache invalidation delays during the highly sensitive audio generation phase.

| Byte Offset | Field Name | Data Type | Description |
| :---- | :---- | :---- | :---- |
| 0x00 | command | uint8\_t | Command execution type (e.g., Note On, Note Off, P-Lock only, Skip). |
| 0x01 | note\_pitch | uint8\_t | Standard MIDI note value (0-127). |
| 0x02 | velocity | uint8\_t | Note velocity or gate intensity (0-127). |
| 0x03 | probability | uint8\_t | Percentage chance (0-100) of execution per sequencer pass. |
| 0x04 | condition\_mode | uint8\_t | Iteration logic (e.g., 1:4 executes only on the 1st iteration out of 4). |
| 0x05 | micro\_timing | int8\_t | Fractional offset for humanization (early or late execution). |
| 0x06 | plock\_target\_1 | uint16\_t | Parameter ID targeted by the primary parameter lock. |
| 0x08 | plock\_value\_1 | float | 32-bit floating point overriding the global parameter value. |
| 0x0C | plock\_target\_2 | uint16\_t | Parameter ID targeted by the secondary parameter lock. |
| 0x0E | plock\_value\_2 | uint16\_t | 16-bit generic value reserved for auxiliary locks or effect macros. |

A full 128-step lane using this structure requires exactly 2,048 bytes of contiguous memory. A comprehensive tracker pattern containing 16 independent lanes consumes exactly 32 kilobytes. This highly optimized data-oriented design fits comfortably within the Level 1 (L1) data cache of modern desktop and embedded processors, ensuring that the audio callback can iterate through the active steps of all 16 lanes with zero cache misses.

### **Parameter Locks and Conditional Trigs**

Parameter locks are fundamental to modern electronic music workflows, heavily popularized by hardware sequencers. A parameter lock allows a specific step in a sequence to temporarily override the global value of a parameter—such as filter cutoff, sample pitch, or decay time—exclusively for the duration of that step.  
In the traditional architecture of Mixxx, parameter manipulation relies on the ControlObject system. ControlObject instances utilize a thread-safe messaging queue to synchronize values between the Graphical User Interface (GUI), MIDI controllers, and the DSP engine. However, historical data indicates that ControlObject updates can be subject to livelocks or severe queue congestion under heavy modulation loads, leading to thread stalling and audio stuttering.  
Therefore, parameter locks within the tracker engine must bypass the ControlObject queue entirely. The EngineTracker must maintain a localized internal DSP state array. During the EngineObject::process() callback, the engine evaluates if the current step holds a valid plock\_target\_1. If a lock exists, the DSP calculation utilizes plock\_value\_1 instead of the baseline value retrieved from the global ControlObject. This localized memory fetch guarantees deterministic execution time.  
Conditional trigs dictate whether a step executes based on predefined logical boundaries. The probability field acts as a stochastic gate, rolling a pseudo-random number against the 0-100 threshold. The condition\_mode field implements deterministic iteration rules. Consequently, the tracker state must maintain an independent loop iteration counter per lane to correctly evaluate these conditions in real-time, resetting the counter when the lane loops.

## **Mixxx Audio Engine and Real-Time C++ Constraints**

Mixxx's audio engine operates on a highly modular architecture built upon the EngineObject interface. Components conforming to this interface implement a process() function that performs in-place digital signal processing on a shared audio buffer. Audio streams are grouped into EngineChannel objects, such as EngineDeck and EngineSampler, which are subsequently aggregated and routed into the main, booth, and headphone outputs by the EngineMixer.

### **The Real-Time Audio Callback**

The operating system's audio interface (e.g., PortAudio, JACK, CoreAudio) periodically triggers a callback requesting a specific number of audio frames. Operating within this callback imposes severe constraints:

> 1. **Non-Blocking Execution**: System calls, disk I/O, and waiting on traditional synchronization primitives like std::mutex or QMutex are strictly forbidden. Blocking the thread leads to priority inversion, resulting in the exhaustion of the audio buffer and subsequent audible dropouts.  
> 2. **Zero Allocation**: Heap allocations involve non-deterministic OS-level locks. Operations such as new, malloc, or dynamically resizing containers must be avoided.  
> 3. **Signal Isolation**: The engine thread may emit Qt signals to update the GUI state, but it cannot safely receive them, as event loop processing is entirely non-deterministic.

### **EngineTracker as an EngineChannel**

To integrate the tracker sequencer cleanly, a new C++ class designated EngineTracker must be created, inheriting directly from EngineChannel. This implementation mirrors the structural design of EngineSampler and EngineDeck. By extending EngineChannel, the tracker natively interfaces with Mixxx's routing infrastructure. This automatically grants the tracker access to Pre-Fader Listen (PFL) for headphone cueing, crossfader orientation, and the EngineEffectsManager for applying native Mixxx effects or external Audio Unit/VST plugins to the sequenced audio.  
Unlike the standard EngineSampler, which relies on an EngineBuffer to decode and resample static audio files, the EngineTracker must instantiate a pre-allocated array of lightweight, polyphonic synthesis voices and single-cycle sample players. These voices write directly to the CSAMPLE buffer provided during the process() execution.

## **Dual-Domain Timing Engine**

Generative sequencing requires highly robust timing mechanisms. The tracker must seamlessly support two distinct timing domains: metric subdivisions (BPM-synced musical ticks) and absolute time (millisecond intervals). This duality allows for standard metric sequencing alongside avant-garde polymetric and polyrhythmic generations.

### **Metric Timing and Sample-Accurate Synchronization**

Mixxx's internal synchronization architecture, governed by EngineSync and InternalClock, relies on a master beat distance metric. The EngineSync::notifyBeatDistanceChanged function broadcasts the progression of the master tempo in floating-point beats.  
Relying on GUI-thread timers (such as QTimer or JavaScript's setInterval) for sequence advancement is insufficient. These timers are subject to operating system scheduler jitter and cannot guarantee the microsecond accuracy required for professional audio. Instead, timing must be calculated explicitly within the audio callback thread by tracking the number of audio frames elapsed.  
During the EngineObject::process call, the tracker receives a buffer of CSAMPLE data alongside the bufferSize parameter (typically 256 to 1024 frames). The tracker increments its internal sample counter by this bufferSize\[span\_45\](start\_span)\[span\_45\](end\_span)\[span\_49\](start\_span)\[span\_49\](end\_span).

| Timing Domain | Resolution Target | Calculation Formula (Samples per Step) | Application |
| :---- | :---- | :---- | :---- |
| **Metric (1/64th Note)** | Master BPM Synchronized | (F\_s \\times 60\) / (\\text{BPM} \\times 16\) | Traditional beat-matched sequence playback. |
| **Metric (1/16th Note)** | Master BPM Synchronized | (F\_s \\times 60\) / (\\text{BPM} \\times 4\) | Standard techno/house grid sequencing. |
| **Absolute (Milliseconds)** | Hardware Clock Synchronized | (T\_{ms} \\times F\_s) / 1000 | Generative, unquantized, or ambient drone triggering. |

When the continuous sample counter crosses a defined step boundary, the corresponding step event is triggered. To support sub-buffer accuracy—preventing the quantization of triggers to the start of a buffer, which causes severe audible jitter—the engine calculates the exact index within the current buffer where the step falls. The generated audio for that step is then rendered into the CSAMPLE array starting precisely at that trigger index, ensuring sample-accurate precision regardless of audio driver latency or buffer size configurations.  
\#\#\# Absolute Millisecond Timing for Polymetry  
Absolute timing bypasses the Mixxx BPM engine entirely. The duration of a step is defined in absolute milliseconds (T\_{ms}), and the conversion to audio frames is static, decoupled from the master tempo. By maintaining independent frame accumulators for each of the 16 sequencer lanes, the engine natively supports polymetry. For instance, Lane 1 can cycle a 16-step sequence based on a metric 1/16th grid, while Lane 2 independently cycles a 7-step sequence based on a fixed 113-millisecond absolute interval.

## **Agentic Interface and Programmatic Connectivity**

A primary objective of this architecture is to enable autonomous generation agents—such as localized large language models (LLMs) or procedural generation scripts—to inject sequences into the engine dynamically.  
Mixxx utilizes a highly capable JavaScript engine (QJSEngine, having migrated from the legacy QScriptEngine) to parse hardware controller mappings, process MIDI/HID I/O, and execute advanced mapping logic via the ControllerMappingProcessor architecture. This JavaScript environment provides the optimal bridge between external generative agents and the internal C++ tracker.

### **Serialization Protocols: Bypassing JSON Overhead**

While JSON is the ubiquitous standard for REST APIs, it is fundamentally unsuited for low-latency, real-time audio systems. JSON parsing incurs significant CPU overhead and dynamic string allocation, both of which introduce unpredictable latency spikes. Furthermore, injecting complete 128-step patterns via LLM context windows requires a highly compressed token representation to remain efficient.  
The optimal serialization format for agent-engine communication is a specialized hexadecimal string encoding, functioning as a serialized binary byte array. For context, representing a single sequencer step in JSON format requires significant character overhead:  
{"cmd": 1, "note": 60, "vel": 100, "prob": 100, "cond": 0, "p1": 5, "v1": 0.5}  
The equivalent 16-byte structure proposed earlier can be represented in hexadecimal using exactly 32 continuous characters (e.g., 013C6464000005000000003F00000000).  
This highly dense hex-string payload can be transmitted by an external LLM, passed via local WebSockets or Open Sound Control (OSC) into the Mixxx JavaScript controller mapping layer, and decoded seamlessly into an ArrayBuffer or QByteArray. The JavaScript environment then pushes the byte array into a C++ proxy object linked directly to the real-time thread.

### **Thread Synchronization and SPSC Queues**

Because generative agents and JavaScript scripts execute in non-real-time threads (such as the main GUI thread or dedicated polling threads), transmitting sequence data into the EngineTracker requires specialized concurrency primitives to prevent blocking.  
The architecture must utilize a Single-Producer, Single-Consumer (SPSC) lock-free ring buffer (FIFO). The agentic JavaScript bridge acts as the producer, writing newly synthesized tracker patterns into the FIFO. The EngineTracker acts as the consumer, polling the FIFO during the process() callback. If a new pattern is available, the engine atomically swaps its active pattern pointer to the new data. To ensure cache coherency and memory visibility across CPU cores without utilizing blocking locks, the SPSC queue must rely on strict std::atomic operations with std::memory\_order\_acquire and std::memory\_order\_release memory fences. This prevents compiler optimization reordering and guarantees that the audio thread views the fully constructed tracker data structure before attempting playback.

## **Proposed C++ Class Architecture and Thread Separation Strategy**

To synthesize the operational requirements, the system must be separated into three distinct threading domains. This separation is paramount to protecting the audio callback's integrity while enabling rich programmatic interaction.

| Thread Domain | Responsibilities | Constraints and Characteristics |
| :---- | :---- | :---- |
| **GUI / Main Thread** | Qt rendering, global state management, overarching tracker configuration. | Cannot touch step data directly. Operates asynchronously. |
| **Agent I/O / JS Thread** | Hosts QJSEngine and ModularControllerMappingProcessor. Decodes Hex-strings to binary arrays. | Writes exclusively to the Lock-Free SPSC FIFO. May block for network I/O. |
| **Real-Time Audio Thread** | Executes OS audio callback (PortAudio/JACK). Reads SPSC FIFO, triggers TrackerVoice instances. | Zero allocations, zero blocking locks, deterministic execution only. |

### **Class Hierarchy and Interactions**

The implementation within the Mixxx codebase necessitates the creation of several tightly coupled, data-oriented classes.  
**1\. TrackerEvent (POD Struct)**

> * Provides the 16-byte representation of a single step.  
> * Contains bitfields for command execution, pitch, velocity, probability logic, and dual parameter locks.  
> * Must explicitly restrict padding to guarantee exactly 16 bytes.

**2\. TrackerPattern (Struct)**

> * Contains a two-dimensional array of TrackerEvent: \[16 lanes\]\[128 steps\].  
> * Holds structural metadata: laneLengths\[16\], timingMode\[16\], and baseBPM.  
> * Pre-allocated. Requires exactly 32 KB of continuous memory to guarantee cache locality.

**3\. TrackerVoice (Class)**

> * Inherits from EngineObject or implements a highly optimized, lightweight DSP interface.  
> * Represents a single polyphonic audio generator (sampler, fractional delay line, or oscillator) capable of rendering audio directly into the CSAMPLE buffer.

**4\. EngineTracker (Class)**

> * Inherits from EngineChannel (integrating it seamlessly into EngineMixer).  
> * Maintains an internal fixed-size array of TrackerVoice objects.  
> * Manages stateful tracking variables: laneSampleCounters\[16\] and laneIterationCounters\[16\].  
> * Contains an instance of SPSCQueue\<TrackerPattern\> for lock-free updates from the JS thread.  
> * Implements the core process(CSAMPLE\* pInOut, const std::size\_t bufferSize) method:  
  * *Step 1*: Poll the queue. If data exists, swap the active TrackerPattern pointer.  
  * *Step 2*: Calculate metric or absolute time progression based on bufferSize.  
  * *Step 3*: Iterate over lanes. If a step threshold is crossed, evaluate conditional logic and probability.  
  * *Step 4*: Extract parameter locks and update DSP coefficients for the targeted voice.  
  * *Step 5*: Trigger TrackerVoice generators.  
  * *Step 6*: Mix voice outputs into the pInOut buffer.

**5\. AgentBridgeProxy (Class)**

> * Inherits from QObject and acts as the C++ interface exposed to the QJSEngine via the new controller mapping system.  
> * Provides a commitPattern(const QByteArray& payload) slot, natively callable from JavaScript mapping scripts.  
> * Validates the incoming byte array, casts it into a TrackerPattern struct, and pushes it into the EngineTracker's lock-free SPSC queue.

## **Conclusion**

Embedding a 128-step hybrid tracker engine into Mixxx requires circumventing traditional DJ software programming paradigms in favor of rigorous, real-time data-oriented design. By adapting the cache-efficient structural paradigms of modern modular trackers like SunVox—and specifically avoiding the rigid matrices and file-bound limitations of legacy formats like MOD and XM—the architecture can provide high-resolution, polyrhythmic sequencing suitable for generative performance.  
The success of this integration hinges entirely on maintaining the sanctity of Mixxx's EngineObject processing constraints. Absolute thread separation is non-negotiable; therefore, communication between AI generative agents and the audio thread must flow strictly through a lock-free ring buffer, avoiding the inherent latency and livelock risks associated with the standard ControlObject system. Furthermore, by exposing a highly dense, hexadecimal serialization protocol to Mixxx's modernized JavaScript controller layer, external large language models and algorithmic scripts can stream complex, multi-lane sequences directly to the engine with negligible latency. This architectural synthesis provisions Mixxx to evolve beyond a playback medium into a fully scriptable, autonomous electronic music instrument.

#### **Works cited**

1\. Developer Guide Engine Player · mixxxdj/mixxx Wiki \- GitHub, https://github.com/mixxxdj/mixxx/wiki/Developer-Guide-Engine-Player/ab5ac907e664a76d749de2719c3ff683d6f1b41b 2\. Mixxx DJ Tutorial PDF | PDF | Equalization (Audio) | Disc Jockey \- Scribd, https://www.scribd.com/document/330480740/Mixxx-DJ-Tutorial-pdf 3\. Mixxx User Manual 2.5.0 Overview | PDF | Disc Jockey | Icon (Computing) \- Scribd, https://www.scribd.com/document/846125928/mixxx-manual-2-5-en 4\. mixxx/AGENTS.md at main \- GitHub, https://github.com/mixxxdj/mixxx/blob/main/AGENTS.md 5\. \[Portaudio\] Using PortAudio in C++ Question, https://portaudio.music.columbia.narkive.com/2ZzQEG6B/using-in-c-question 6\. SunVox File Format \- Radiant Voices 2.0.1.2.1.4.0 documentation, https://radiant-voices.readthedocs.io/en/latest/sunvox-file-format.html 7\. Sound Mixing \- Deku's Tree of Art, https://deku.gbadev.org/program/sound3.html 8\. New controller system · mixxxdj/mixxx Wiki \- GitHub, https://github.com/mixxxdj/mixxx/wiki/New-controller-system 9\. MilkyTracker | News, https://milkytracker.org/ 10\. xrepo \- Xmake, https://xrepo.xmake.io/mirror/packages/bsd.html 11\. Patchstorage | Discover & Showcase Your Patches, https://patchstorage.com/ 12\. ACE vs. SunVox Comparison \- SourceForge, https://sourceforge.net/software/compare/ACE-u-he-vs-SunVox/ 13\. SunVox library for developers \- WarmPlace.ru., https://warmplace.ru/soft/sunvox/sunvox\_lib.php 14\. Sunvox Tips and Tricks \- WarmPlace.ru, https://warmplace.ru/forum/viewtopic.php?t=1740 15\. Midi Clock Out · Issue \#14395 · mixxxdj/mixxx \- GitHub, https://github.com/mixxxdj/mixxx/issues/14395 16\. "Parameter Locks" modulator \- Community Wishlist \- Bitwish, https://bitwish.top/t/parameter-locks-modulator/270 17\. Elektron analog four mk2 manual | zZounds.com, https://cf3.zzounds.com/media/Product\_Manual-bbdf8eab85d6e0cedda9b8002b29e50e.pdf 18\. Elektron is taking over my studio \- Reddit, https://www.reddit.com/r/Elektron/comments/jxse4y/elektron\_is\_taking\_over\_my\_studio/ 19\. Revamped Control System · mixxxdj/mixxx Wiki · GitHub, https://github.com/mixxxdj/mixxx/wiki/Revamped-Control-System 20\. Playback goes choppy and stutters · Issue \#4981 · mixxxdj/mixxx \- GitHub, https://github.com/mixxxdj/mixxx/issues/4981 21\. Developer Guide Engine · mixxxdj/mixxx Wiki \- GitHub, https://github.com/mixxxdj/mixxx/wiki/Developer-Guide-Engine/5b167a9c53f562281d9610dba8bd45b7f2fd0e7f 22\. Four common mistakes in audio development | Hacker News, https://news.ycombinator.com/item?id=11907887 23\. Proceedings der Linux Audio Conference 2018, https://lac.linuxaudio.org/2018/pdf/LAC2018\_proceedings.pdf 24\. audio | MindMeister Mind map, https://www.mindmeister.com/213699337/audio 25\. Effects Framework · mixxxdj/mixxx Wiki \- GitHub, https://github.com/mixxxdj/mixxx/wiki/Effects-Framework 26\. 16.8. Changelog — Mixxx User Manual, https://manual.mixxx.org/2.4/en/chapters/appendix/changelog 27\. GitHub \- paralin/starred: List of my GitHub stars., https://github.com/paralin/starred 28\. GitHub \- Yuan-ManX/audio-development-tools: Audio Development Tools (ADT) is a project for advancing sound, speech, and music technologies, featuring components for machine learning, sound synthesis, speech and music generation, signal processing, game audio, digital audio workstations (DAWs), and more., https://github.com/Yuan-ManX/audio-development-tools 29\. A Comprehensive Framework to Replicate Process-level Concurrency Faults, https://digitalcommons.unl.edu/cgi/viewcontent.cgi?article=1182\&context=computerscidiss 30\. perlancar's blog | \#perl \#programming | Page 3 \- WordPress.com, https://perlancar.wordpress.com/page/3/ 31\. Achieving generic bliss with reflection in modern C++ \- OSSIA Score, https://ossia.io/posts/reflection/